"""
LAPT throughput measurement run on the real training hardware before committing to the full run plan. Measures samples/sec and
steps/sec from a short training run, then checks wall-clock time for
the full-run schedule (5 epochs) and a search-trial schedule across combined/xho-only/zul-only.

Uses a slice of real prepared data if LAPT_data/lapt_prepared/train exists,
otherwise falls back to synthetic random-token data of the same shape
(512-token blocks)

Usage in a Colab cell:
    !python lapt_throughput_check.py --model bert-base-multilingual-cased
    !python lapt_throughput_check.py --model xlm-roberta-base --lora true --lora-r 256

Run once per (backbone, full vs LoRA) combination. they have different
memory/compute profiles, so one throughput number doesn't predict another.
"""

import argparse
import os
import random

import torch
from datasets import Dataset, load_from_disk
from transformers import (
    AutoModelForMaskedLM,
    AutoTokenizer,
    DataCollatorForLanguageModeling,
    Trainer,
    TrainingArguments,
)


def str2bool(v):
    return str(v).lower() in ("true", "1", "yes")


def build_synthetic_dataset(tokenizer, n_examples=3000, block_size=512):
    """Random-token blocks shaped like real prepared LAPT data. Forward/
    backward FLOPs depend only on sequence length and batch size, not
    token content, so throughput measured here should transfer."""
    vocab_size = tokenizer.vocab_size
    data = {
        "input_ids": [
            [random.randint(0, vocab_size - 1) for _ in range(block_size)]
            for _ in range(n_examples)
        ]
    }
    return Dataset.from_dict(data)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="bert-base-multilingual-cased",
                     help="bert-base-multilingual-cased or xlm-roberta-base")
    ap.add_argument("--data-dir", default="LAPT_data/lapt_prepared/train",
                     help="Path to real prepared data, if it exists")
    ap.add_argument("--block-size", type=int, default=512)
    ap.add_argument("--batch-size", type=int, default=2,
                     help="Per-device batch size to test. Defaults small; "
                          "ramp up gradually (2, 4, 8...) while watching "
                          "VRAM with `rocm-smi`/`nvidia-smi` -- a full "
                          "forward+backward pass at seq_len=512 can exceed "
                          "consumer-GPU VRAM before Python catches the OOM.")
    ap.add_argument("--gradient-checkpointing", type=str2bool, default=True,
                     help="Recomputes activations during backward instead "
                          "of storing them, trading compute for lower peak "
                          "VRAM. On by default -- safety over speed here.")
    ap.add_argument("--steps", type=int, default=60,
                     help="Steps to measure over -- ~60 is enough for a "
                          "stable samples/sec reading past warmup")
    ap.add_argument("--lora", type=str2bool, default=False)
    ap.add_argument("--lora-r", type=int, default=256)
    args = ap.parse_args()

    print("=" * 60)
    print("Torch:", torch.__version__)
    print("CUDA available:", torch.cuda.is_available())
    if torch.cuda.is_available():
        print("GPU:", torch.cuda.get_device_name(0))
        print("BF16 supported:", torch.cuda.is_bf16_supported())
    print(f"Model: {args.model}  |  LoRA: {args.lora} (r={args.lora_r if args.lora else 'n/a'})")
    print(f"Batch size: {args.batch_size}  |  Measuring over {args.steps} steps")
    print("=" * 60)

    tokenizer = AutoTokenizer.from_pretrained(args.model)

    if os.path.exists(args.data_dir):
        print(f"\nUsing REAL prepared data from {args.data_dir}")
        ds = load_from_disk(args.data_dir)
        if len(ds) > 3000:
            ds = ds.select(range(3000))
        keep = [c for c in ds.column_names if c == "input_ids"]
        ds = ds.remove_columns([c for c in ds.column_names if c not in keep])
    else:
        print(f"\n{args.data_dir} not found -- using synthetic random-token "
              f"data (real hardware throughput, approximate data shape)")
        ds = build_synthetic_dataset(tokenizer, n_examples=3000, block_size=args.block_size)

    ds.set_format("torch")
    collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=True, mlm_probability=0.15)

    model = AutoModelForMaskedLM.from_pretrained(args.model)

    if args.lora:
        from peft import LoraConfig, get_peft_model
        lora_config = LoraConfig(
            r=args.lora_r,
            lora_alpha=args.lora_r * 2,
            target_modules=["query", "key", "value", "intermediate.dense", "output.dense"],
            lora_dropout=0.05,
            bias="none",
            task_type=None,  # peft has no native MASKED_LM task type
        )
        model = get_peft_model(model, lora_config)
        model.print_trainable_parameters()

    if torch.cuda.is_available():
        model = model.to("cuda")
        free_mem, total_mem = torch.cuda.mem_get_info()
        print(f"\nVRAM: {free_mem / 1e9:.1f} GB free / {total_mem / 1e9:.1f} GB total "
              f"(before this run starts allocating)")
        if total_mem < 16e9 and args.batch_size > 4:
            print(f"WARNING: batch_size={args.batch_size} on a GPU with "
                  f"{total_mem/1e9:.0f}GB total VRAM -- this crashed the "
                  f"machine at batch_size=16 last time. Strongly consider "
                  f"Ctrl+C now and re-running with a smaller --batch-size.")

    # /content only exists on Colab, fall back to a local temp dir otherwise
    if os.path.isdir("/content"):
        output_dir = "/content/throughput_check"
    else:
        import tempfile
        output_dir = os.path.join(tempfile.gettempdir(), "lapt_throughput_check")

    training_args = TrainingArguments(
        output_dir=output_dir,  # disposable scratch dir, not a real checkpoint location
        per_device_train_batch_size=args.batch_size,
        max_steps=args.steps,
        bf16=torch.cuda.is_available(),  # A100 native bf16, not fp16
        gradient_checkpointing=args.gradient_checkpointing,
        logging_steps=10,
        save_strategy="no",
        report_to="none",
        dataloader_drop_last=True,
    )

    trainer = Trainer(model=model, args=training_args, train_dataset=ds, data_collator=collator)

    print(f"\nRunning {args.steps} steps to measure real throughput...")
    result = trainer.train()

    samples_per_sec = result.metrics["train_samples_per_second"]
    steps_per_sec = result.metrics["train_steps_per_second"]

    print("\n" + "=" * 60)
    print("MEASURED THROUGHPUT")
    print("=" * 60)
    print(f"samples/sec: {samples_per_sec:.2f}")
    print(f"steps/sec:   {steps_per_sec:.2f}")

    print("\n--- Extrapolated wall-clock time for THIS model/method config ---")
    print("(run this script once per backbone x full/LoRA combo -- these numbers")
    print(" don't transfer between mBERT/XLM-R or between full/LoRA)")
    for label, n_examples in [
        ("combined, 5 epochs (~225K blocks)", 225_000 * 5),
        ("xho-only, 5 epochs (~120K blocks)", 120_000 * 5),
        ("zul-only, 5 epochs (~105K blocks)", 105_000 * 5),
        ("one search trial (~1.5K steps)", 1500 * args.batch_size),
    ]:
        hrs = n_examples / samples_per_sec / 3600
        print(f"  {label}: {hrs:.2f} hours")

    total_full_runs_hrs = sum(
        n / samples_per_sec / 3600
        for n in [225_000 * 5, 120_000 * 5, 105_000 * 5]
    )
    print(f"\n  Sum of all 3 language-scope full runs, THIS config only: {total_full_runs_hrs:.2f} hours")
    print("  Multiply by 4 (2 backbones x full/LoRA) for the full-run grand total.")


if __name__ == "__main__":
    main()
