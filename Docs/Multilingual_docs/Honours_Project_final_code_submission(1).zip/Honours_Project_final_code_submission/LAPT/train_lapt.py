"""
LAPT training script
full-parameter or LoRA continued pretraining for
mBERT / XLM-R on the isiXhosa/isiZulu combined-language corpus.

--output-dir is not auto-generated. pass one per run following the
results/LAPT_<backbone>_<full|lora>[_<lang>only] convention used by the
locked run commands at the bottom of this file (results/LAPT_mbert_full).

LOCKED PLAN:
  - Backbone models: bert-base-multilingual-cased (LOCAL), xlm-roberta-base (COLAB A100)
  - Methods: full LAPT and LoRA LAPT (r=256, attention + FFN targets), both
    backbones
  - 3 epochs, fixed hyperparameters: effective batch 256,
    LR 1e-4, Adam eps 1e-6, betas (0.9, 0.98), 6% linear warmup, weight
    decay 0.01
  - bf16 throughout

"""

import argparse
import json
import os
import random
import time

import torch
from datasets import load_from_disk
from transformers import (
    AutoModelForMaskedLM,
    AutoTokenizer,
    DataCollatorForLanguageModeling,
    Trainer,
    TrainerCallback,
    TrainingArguments,
)
from transformers.trainer_utils import get_last_checkpoint


def str2bool(v):
    return str(v).lower() in ("true", "1", "yes")


class DriveSnapshotCallback(TrainerCallback):
    """On every checkpoint save, copies model weights only to a fixed Drive path, overwriting the previous snapshot.
    Separate from the real optimizer-inclusive checkpoint so a full session loss still leaves something recoverable."""

    def __init__(self, drive_dir, tokenizer):
        self.drive_dir = drive_dir
        self.tokenizer = tokenizer

    def on_save(self, args, state, control, model=None, **kwargs):
        if self.drive_dir is None or model is None:
            return control
        try:
            os.makedirs(self.drive_dir, exist_ok=True)
            model.save_pretrained(self.drive_dir, safe_serialization=True)
            self.tokenizer.save_pretrained(self.drive_dir)
            print(f"[DriveSnapshotCallback] snapshot saved to {self.drive_dir}")
        except Exception as e:
            # non-fatal: a failed snapshot shouldn't kill training
            print(f"[DriveSnapshotCallback] snapshot failed (non-fatal): {e}")
        return control


def get_dir_size_gb(path):
    total = 0
    for dirpath, _, filenames in os.walk(path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            if os.path.exists(fp):
                total += os.path.getsize(fp)
    return total / 1e9


def build_model(model_name, use_lora, lora_r):
    model = AutoModelForMaskedLM.from_pretrained(model_name)
    if use_lora:
        from peft import LoraConfig, get_peft_model
        lora_config = LoraConfig(
            r=lora_r,
            lora_alpha=lora_r * 2,
            target_modules=["query", "key", "value", "intermediate.dense", "output.dense"],
            lora_dropout=0.05,
            bias="none",
            task_type=None,  # peft has no native MASKED_LM task type;
                              # target_modules covers attention + FFN on
                              # both backbones without touching the frozen
                              # MLM head
        )
        model = get_peft_model(model, lora_config)
        model.print_trainable_parameters()
    return model


def evaluate_per_language(trainer, eval_ds_with_lang):
    """Evaluates on the combined set and on each language subset
    separately."""
    import math

    results = {}
    combined = eval_ds_with_lang.remove_columns(
        [c for c in eval_ds_with_lang.column_names if c != "input_ids"]
    )
    combined.set_format("torch")
    metrics = trainer.evaluate(eval_dataset=combined)
    results["combined"] = {
        "eval_loss": metrics["eval_loss"],
        "perplexity": math.exp(metrics["eval_loss"]),
        "n_blocks": len(combined),
    }

    for lang in sorted(set(eval_ds_with_lang["language"])):
        subset = eval_ds_with_lang.filter(lambda ex: ex["language"] == lang)
        subset = subset.remove_columns([c for c in subset.column_names if c != "input_ids"])
        subset.set_format("torch")
        if len(subset) == 0:
            continue
        metrics = trainer.evaluate(eval_dataset=subset)
        results[lang] = {
            "eval_loss": metrics["eval_loss"],
            "perplexity": math.exp(metrics["eval_loss"]),
            "n_blocks": len(subset),
        }
    return results


def get_qualitative_examples(eval_ds_with_lang, tokenizer, n=10, seed=42):
    """Picks n held-out blocks and a maskable position in each, for
    before/after LAPT prediction comparison."""
    rng = random.Random(seed)
    n = min(n, len(eval_ds_with_lang))
    indices = rng.sample(range(len(eval_ds_with_lang)), n)
    examples = []
    for idx in indices:
        row = eval_ds_with_lang[idx]
        ids = row["input_ids"]
        candidate_positions = [i for i, t in enumerate(ids) if t not in tokenizer.all_special_ids]
        if not candidate_positions:
            continue
        pos = rng.choice(candidate_positions)
        examples.append({
            "input_ids": list(ids),
            "mask_position": pos,
            "language": row.get("language", "?"),
        })
    return examples


def predict_masked_token(model, tokenizer, input_ids, mask_position, device, k=5):
    ids = list(input_ids)
    original_token_id = ids[mask_position]
    ids[mask_position] = tokenizer.mask_token_id
    input_tensor = torch.tensor([ids]).to(device)
    model.eval()
    with torch.no_grad():
        logits = model(input_ids=input_tensor).logits
    probs = torch.softmax(logits[0, mask_position].float(), dim=-1)
    topk = torch.topk(probs, k)
    predictions = [
        (tokenizer.decode([tid]).strip(), round(float(p), 4))
        for tid, p in zip(topk.indices.tolist(), topk.values.tolist())
    ]
    original_str = tokenizer.decode([original_token_id]).strip()
    context_ids = [t for t in ids if t != tokenizer.pad_token_id][:60]
    context = tokenizer.decode(context_ids)
    return {"original": original_str, "top_k_predictions": predictions, "context_snippet": context}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True,
                     help="bert-base-multilingual-cased or xlm-roberta-base")
    ap.add_argument("--data-dir", default="LAPT_data/lapt_prepared",
                     help="Directory containing train/ and eval/ from lapt_prepare_data.py")
    ap.add_argument("--output-dir", required=True,
                     help="Where checkpoints, final/ model, and metrics get "
                          "saved. Convention: results/LAPT_<backbone>_"
                          "<full|lora>[_<lang>only], e.g. results/LAPT_mbert_full.")
    ap.add_argument("--lora", type=str2bool, default=False)
    ap.add_argument("--lora-r", type=int, default=256)
    ap.add_argument("--per-device-batch-size", type=int, required=True,
                     help="Hardware-specific -- see throughput table in this "
                          "file's docstring. Re-measure with "
                          "lapt_throughput_check.py for any new hardware.")
    ap.add_argument("--effective-batch-size", type=int, default=256,
                     help="Fixed control value, not searched")
    ap.add_argument("--epochs", type=float, default=3.0)
    ap.add_argument("--learning-rate", type=float, default=1e-4)
    ap.add_argument("--save-steps", type=int, default=200)
    ap.add_argument("--drive-snapshot-dir", default=None,
                     help="If set (Colab only), weights-only snapshots are "
                          "copied here on every save. Leave unset locally.")
    ap.add_argument("--n-qualitative-examples", type=int, default=10)
    ap.add_argument("--train-language", default=None, choices=[None, "xho", "zul"],
                     help="If set, trains on only this language's blocks "
                          "(for the cross-lingual transfer question). Eval "
                          "always stays on the full combined set with "
                          "per-language breakdown, to keep the transfer "
                          "signal visible.")
    args = ap.parse_args()

    if args.effective_batch_size % args.per_device_batch_size != 0:
        raise ValueError(
            f"effective_batch_size ({args.effective_batch_size}) must be "
            f"divisible by per_device_batch_size ({args.per_device_batch_size})"
        )
    grad_accum_steps = args.effective_batch_size // args.per_device_batch_size

    print("=" * 60)
    print(f"Model: {args.model}  |  LoRA: {args.lora} (r={args.lora_r if args.lora else 'n/a'})")
    print(f"Per-device batch: {args.per_device_batch_size}  |  Grad accum: {grad_accum_steps}  "
          f"|  Effective batch: {args.effective_batch_size}")
    print(f"Epochs: {args.epochs}  |  LR: {args.learning_rate}")
    print("=" * 60)

    os.makedirs(args.output_dir, exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"

    tokenizer = AutoTokenizer.from_pretrained(args.model)

    print("\nLoading prepared LAPT data...")
    train_ds = load_from_disk(os.path.join(args.data_dir, "train"))
    eval_ds = load_from_disk(os.path.join(args.data_dir, "eval"))  # keep `language` column
    print(f"Train blocks: {len(train_ds)}  |  Eval blocks: {len(eval_ds)}")

    if "language" not in eval_ds.column_names:
        raise ValueError(
            f"'{args.data_dir}/eval' has no `language` column (columns found: "
            f"{eval_ds.column_names}). This means it was built with an older "
            f"version of lapt_prepare_data.py, before per-language chunking was "
            f"added. Re-run: python lapt_prepare_data.py --input "
            f"LAPT_data/fineweb2_lapt_pool_final.jsonl --tokenizer {args.model} "
            f"--output-dir {args.data_dir} --block-size 512"
        )

    if args.train_language is not None:
        pre_filter_count = len(train_ds)
        train_ds = train_ds.filter(lambda ex: ex["language"] == args.train_language)
        print(f"Filtered train set to language={args.train_language}: "
              f"{pre_filter_count} -> {len(train_ds)} blocks "
              f"(eval stays on the FULL combined set -- this is what makes "
              f"cross-lingual transfer visible)")

    train_ds_for_trainer = train_ds.remove_columns(
        [c for c in train_ds.column_names if c != "input_ids"]
    )
    train_ds_for_trainer.set_format("torch")

    collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=True, mlm_probability=0.15)

    #This is the comparison point LAPT is evaluated against.
    print("\nEvaluating BASELINE (pre-LAPT) model...")
    baseline_model = AutoModelForMaskedLM.from_pretrained(args.model).to(device)
    baseline_args = TrainingArguments(
        output_dir=os.path.join(args.output_dir, "_baseline_eval_scratch"),
        per_device_eval_batch_size=args.per_device_batch_size,
        bf16=torch.cuda.is_available(),
        report_to="none",
    )
    baseline_trainer = Trainer(model=baseline_model, args=baseline_args, data_collator=collator)
    baseline_results = evaluate_per_language(baseline_trainer, eval_ds)
    print("Baseline results:", json.dumps(baseline_results, indent=2))

    qual_examples = get_qualitative_examples(eval_ds, tokenizer, n=args.n_qualitative_examples)
    before_predictions = [
        predict_masked_token(baseline_model, tokenizer, ex["input_ids"], ex["mask_position"], device)
        for ex in qual_examples
    ]

    del baseline_model, baseline_trainer
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    # fresh load. LoRA-wrap if requested
    model = build_model(args.model, args.lora, args.lora_r)
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)

    #the 6% warmup target is computed manually
    steps_per_epoch = len(train_ds_for_trainer) // (args.per_device_batch_size * grad_accum_steps)
    total_optimizer_steps = max(1, int(steps_per_epoch * args.epochs))
    warmup_steps = max(1, round(0.06 * total_optimizer_steps))
    print(f"\nComputed schedule: {steps_per_epoch} steps/epoch, "
          f"{total_optimizer_steps} total optimizer steps, "
          f"{warmup_steps} warmup steps (6%)")

    training_args = TrainingArguments(
        output_dir=args.output_dir,
        per_device_train_batch_size=args.per_device_batch_size,
        per_device_eval_batch_size=args.per_device_batch_size,
        gradient_accumulation_steps=grad_accum_steps,
        num_train_epochs=args.epochs,
        learning_rate=args.learning_rate,
        lr_scheduler_type="linear",
        warmup_steps=warmup_steps,   # 6% of total steps
        weight_decay=0.01,
        adam_beta1=0.9,
        adam_beta2=0.98,
        adam_epsilon=1e-6,
        bf16=torch.cuda.is_available(),
        save_strategy="steps",
        save_steps=args.save_steps,
        save_total_limit=2,          # keep last 2, for rollback if latest is corrupted
        eval_strategy="steps",
        eval_steps=args.save_steps,
        logging_steps=50,
        report_to="none",
        dataloader_drop_last=True,
    )

    callbacks = []
    if args.drive_snapshot_dir is not None:
        callbacks.append(DriveSnapshotCallback(args.drive_snapshot_dir, tokenizer))

    combined_eval_for_trainer = eval_ds.remove_columns(
        [c for c in eval_ds.column_names if c != "input_ids"]
    )
    combined_eval_for_trainer.set_format("torch")

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_ds_for_trainer,
        eval_dataset=combined_eval_for_trainer,
        data_collator=collator,
        callbacks=callbacks,
    )

    # auto-resume if output_dir already has a checkpoint
    last_checkpoint = None
    if os.path.isdir(args.output_dir):
        last_checkpoint = get_last_checkpoint(args.output_dir)
        if last_checkpoint:
            print(f"\nFound existing checkpoint -- resuming from {last_checkpoint}")

    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()
    t_start = time.time()

    train_result = trainer.train(resume_from_checkpoint=last_checkpoint)

    t_end = time.time()
    peak_mem_gb = torch.cuda.max_memory_allocated() / 1e9 if torch.cuda.is_available() else None

    #final perplexity and qualitative predictions on the same examples/positions as the baseline
    print("\nEvaluating final (post-LAPT) model...")
    final_results = evaluate_per_language(trainer, eval_ds)
    print("Final results:", json.dumps(final_results, indent=2))

    after_predictions = [
        predict_masked_token(model, tokenizer, ex["input_ids"], ex["mask_position"], device)
        for ex in qual_examples
    ]

    # clean non-checkpoint dir for the classifier fine-tuning stage to load
    final_dir = os.path.join(args.output_dir, "final")
    trainer.save_model(final_dir)
    tokenizer.save_pretrained(final_dir)
    checkpoint_size_gb = get_dir_size_gb(final_dir)

    metrics_report = {
        "config": {
            "model": args.model,
            "lora": args.lora,
            "lora_r": args.lora_r if args.lora else None,
            "per_device_batch_size": args.per_device_batch_size,
            "effective_batch_size": args.effective_batch_size,
            "epochs": args.epochs,
            "learning_rate": args.learning_rate,
            "train_language": args.train_language,
        },
        "resource_usage": {
            "wall_clock_seconds": t_end - t_start,
            "wall_clock_hours": round((t_end - t_start) / 3600, 3),
            "train_samples_per_second": train_result.metrics.get("train_samples_per_second"),
            "train_steps_per_second": train_result.metrics.get("train_steps_per_second"),
            "peak_gpu_memory_gb": peak_mem_gb,
            "total_params": total_params,
            "trainable_params": trainable_params,
            "trainable_pct": round(100 * trainable_params / total_params, 4),
            "final_checkpoint_size_gb": round(checkpoint_size_gb, 3),
        },
        "baseline_perplexity": baseline_results,
        "final_perplexity": final_results,
    }
    with open(os.path.join(args.output_dir, "metrics.json"), "w") as f:
        json.dump(metrics_report, f, indent=2)

    qualitative_report = []
    for ex, before, after in zip(qual_examples, before_predictions, after_predictions):
        qualitative_report.append({
            "language": ex["language"],
            "context": before["context_snippet"],
            "original_token": before["original"],
            "before_lapt_top5": before["top_k_predictions"],
            "after_lapt_top5": after["top_k_predictions"],
        })
    with open(os.path.join(args.output_dir, "qualitative_examples.json"), "w") as f:
        json.dump(qualitative_report, f, indent=2, ensure_ascii=False)

    print(f"\nDone. Results saved to {args.output_dir}")
    print(f"  metrics.json, qualitative_examples.json, final/ (model + tokenizer)")


if __name__ == "__main__":
    main()
