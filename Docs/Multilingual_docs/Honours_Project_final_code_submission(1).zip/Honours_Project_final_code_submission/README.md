# Honours_Project_Individual

Code for the Honours project "Detecting Machine-Generated Text in Low-Resource
South African Nguni Languages" (isiXhosa and isiZulu), 2026.

Builds a filtered FineWeb-2 corpus, splits it into a language-adaptive
pretraining (LAPT) pool and a reserved human-text pool, generates matched
machine-written counterparts with Gemma 3 4B IT, then LAPT-pretrains and
fine-tunes mBERT and XLM-R (full and LoRA) for MGT detection, compared
against a TF-IDF + logistic regression baseline.

## Setup

Install PyTorch **first and separately** — see the top of `requirements.txt`
for the correct command for your hardware (ROCm / CUDA / CPU); installing
plain `pip install torch` pulls the wrong build for GPU work. Then:

```
pip install -r requirements.txt --break-system-packages
```

(`--break-system-packages` is only needed on externally-managed Python
environments; drop it if you're in a venv.)

Colab notebooks (`colab_files/`) install their own dependencies inline and
don't need this file.

## Pipeline

Run in this order. Each stage names its main script(s); pass `-h` to any
script for its full set of flags, or read its module docstring for the
reasoning behind its defaults.

### 1. Corpus filtering
```
python create_dataset/filter_fineweb2.py
```
Filters raw FineWeb-2 (score/year, domain frequency + concentration cap,
minhash + exact dedup, length, prose-content), then splits the result into
`LAPT_data/fineweb2_lapt_pool.jsonl` and `LAPT_data/fineweb2_reserved_pool.jsonl`.

### 2. Machine-text generation
```
python create_dataset/generate_paired_dataset.py
```
Uses `create_dataset/gemma_generator.py` to generate a machine continuation
for each reserved-pool document, filters for quality (prompt artifacts,
repetition, copying, language via GlotLID), and writes
`LAPT_data/xho_paired.jsonl` / `LAPT_data/zul_paired.jsonl`.

Needs a GPU. `colab_files/fineweb2_generation_colab_pro.ipynb` (and the
`_test` variant, for a quick small-scale run) is the Colab equivalent,
generating into a Drive-based `PROJECT_DIR` instead — see its markdown
cells for setup.

### 3. Fold unused documents back, verify no leakage
```
python create_dataset/return_unused_to_lapt.py
python create_dataset/verify_no_lapt_overlap.py
```
Reserved-pool documents that were never accepted as a pair get added back
into the LAPT pool (they're still valid unlabelled text), written fresh as
`LAPT_data/fineweb2_lapt_pool_final.jsonl`. Then verify no document that
became a generation seed also ended up in the LAPT pool. If the URL-based
secondary check flags anything, `create_dataset/diagnose_url_overlap.py`
helps distinguish genuine leakage from harmless re-crawls of the same page.

### 4. Train/val/test split
```
python create_dataset/make_splits.py --paired LAPT_data/xho_paired.jsonl LAPT_data/zul_paired.jsonl
```
Splits at the pair level (grouped by seed_id, so a human/machine pair never
crosses splits) and independently per language, writing `finetuning_data/train.jsonl`,
`val.jsonl`, `test.jsonl`.

### 5. LAPT pretraining
```
python create_dataset/lapt_prepare_data.py --input LAPT_data/fineweb2_lapt_pool_final.jsonl --tokenizer <model> --output-dir LAPT_data/lapt_prepared --block-size 512
python LAPT/train_lapt.py --model <model> --data-dir LAPT_data/lapt_prepared --output-dir results/LAPT_<config>
```
Tokenizes and chunks the LAPT pool (mBERT and XLM-R need separate runs —
different, incompatible tokenizers), then runs full-parameter or LoRA
continued pretraining. `LAPT/train_lapt.py`'s docstring lists the locked
run commands for all four configs (mBERT/XLM-R x full/LoRA); cross-lingual
(xho-only/zul-only) runs use `--train-language`.
`LAPT/lapt_throughput_check.py` is worth running first on new hardware to
pick a safe batch size before committing to a full run.

mBERT was trained locally (ROCm/AMD); XLM-R on Colab A100 via
`colab_files/LAPT_train_colab.ipynb`, which embeds and runs the same
`lapt_prepare_data.py`/`train_lapt.py` scripts unmodified.

### 6. Baselines and classifier fine-tuning
```
python model_training/tfidf_baseline.py
python model_training/run_all_classifier_finetuning.py \
    --train-file finetuning_data/train.jsonl --val-file finetuning_data/val.jsonl --test-file finetuning_data/test.jsonl \
    --lapt-results-dir results --output-dir results_classifier
```
`tfidf_baseline.py` produces the word- and char-level TF-IDF + logistic
regression baselines (`results_tfidf/`). `run_all_classifier_finetuning.py`
drives `finetune_classifier_bohb.py` (BOHB-style hyperparameter search) over
every checkpoint from step 5 plus the two no-LAPT baselines — the full
20-run classifier matrix, into `results_classifier/`.

### 7. Consolidate results and statistics
```
python model_training/consolidate_results.py --classifier-dir results_classifier --tfidf-dir results_tfidf --output all_results.csv
python model_training/bootstrap_ci.py
python model_training/mcnemar_analysis.py
```
Builds the master results table, then bootstrap confidence intervals and
pairwise McNemar significance testing (Bonferroni-corrected) across the matrix.

### 8. Post-hoc confound and robustness checks
Each check builds (or strips) a test-set variant, then re-evaluates every
run from step 6 against it using `model_training/evaluate_on_subset.py`
(transformers) / `evaluate_tfidf_on_subset.py` (TF-IDF), driven across the
whole matrix by `run_all_length_matched_evals.py` (transformers) and
`run_all_tfidf_matched_evals.py` (TF-IDF) — both take any `--test-file`, not
just the length-matched one.

- **Length**: `model_training/build_length_matched_test.py`
- **Punctuation/formatting**: `model_training/strip_formatting_artifacts.py`
  (two stages: structural-only, then `--strip-core-punctuation`), evaluated
  via `model_training/run_all_robustness_checks.py` specifically
- **Repetition**: `model_training/detect_repetition.py`
- **Linguistic markers** (connectives/infinitives): first build the lexicon
  and diagnostic classifier —
  ```
  python language_check/extract_conjunctions_from_pos_corpus.py --xhosa-files <SADII files> --zulu-files <SADII files>
  python language_check/build_linguistic_marker_features.py
  python language_check/linguistic_marker_diagnostic_classifier.py
  python language_check/build_linguistic_marker_matched_subset.py
  ```
  then evaluate the matched subset the same way as the other checks. The
  SADII POS-annotated corpus these depend on isn't included in this repo.

### 9. Figures
```
python model_training/generate_graphs.py
```
Produces every figure from the results (comparison bars, bootstrap CI
forest plot, ROC curves, resource-efficiency scatter, probability
distributions, per-language comparison).

## Reference / appendix scripts

Not part of the pipeline above, but used for specific numbers reported in
the paper or for manual verification:

- `create_dataset/compute_token_counts.py` — document/token counts for the
  LAPT pool and each split (paper Table 3)
- `create_dataset/count_dataset_sizes.py`, `inspect_domain.py`,
  `scan_adult_content.py` — corpus inspection/verification tools used
  during filtering (see `filter_fineweb2.py`'s `DOMAIN_BLOCKLIST`)
- `language_check/find_codeswitch_examples.py` — pulls example
  code-switched sentences from the test set for manual inspection
