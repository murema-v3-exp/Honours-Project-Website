"""
Computes document and token counts for the LAPT pool and the train/
validation/test splits, tokenized with both mBERT's WordPiece tokenizer
and XLM-R's SentencePiece tokenizer.

Outputs one row per split (LAPT pool, train, validation, test, total)
with per-language document counts and total token counts per tokenizer.
Not split by language, to keep the table compact.

Usage:
    python compute_token_counts.py \
        --lapt-pool LAPT_data/fineweb2_lapt_pool_final.jsonl \
        --train finetuning_data/train.jsonl --val finetuning_data/val.jsonl --test finetuning_data/test.jsonl \
        --output-csv token_counts.csv
"""

import argparse
import json
from collections import defaultdict

from transformers import AutoTokenizer


def load_jsonl(path):
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def classify_language(value):
    v = str(value).strip().lower()
    if v.startswith("xho"):
        return "isiXhosa"
    if v.startswith("zul"):
        return "isiZulu"
    return "other"


def count_split(rows, wp_tokenizer, sp_tokenizer, language_field, text_field, batch_size=256):
    doc_counts = defaultdict(int)
    wp_total = 0
    sp_total = 0

    texts = [r.get(text_field, "") for r in rows]
    langs = [classify_language(r.get(language_field, "")) for r in rows]

    for lang in langs:
        doc_counts[lang] += 1

    # Batch for speed - tokenizing one doc at a time over tens of thousands
    # would be needlessly slow.
    for i in range(0, len(texts), batch_size):
        batch = texts[i:i + batch_size]
        wp_enc = wp_tokenizer(batch, add_special_tokens=False)
        sp_enc = sp_tokenizer(batch, add_special_tokens=False)
        wp_total += sum(len(ids) for ids in wp_enc["input_ids"])
        sp_total += sum(len(ids) for ids in sp_enc["input_ids"])
        if (i // batch_size) % 20 == 0:
            print(f"    ...tokenized {i + len(batch)}/{len(texts)} documents")

    return doc_counts, wp_total, sp_total


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lapt-pool", required=True, help="Raw LAPT pool JSONL (pre-chunking)")
    ap.add_argument("--train", required=True)
    ap.add_argument("--val", required=True)
    ap.add_argument("--test", required=True)
    ap.add_argument("--language-field", default="lang")
    ap.add_argument("--text-field", default="text")
    ap.add_argument("--wp-model", default="bert-base-multilingual-cased",
                     help="HF model name for the WordPiece tokenizer")
    ap.add_argument("--sp-model", default="xlm-roberta-base",
                     help="HF model name for the SentencePiece tokenizer")
    ap.add_argument("--output-csv", default="token_counts.csv")
    args = ap.parse_args()

    print(f"Loading tokenizers: {args.wp_model} (WordPiece), {args.sp_model} (SentencePiece)...")
    wp_tokenizer = AutoTokenizer.from_pretrained(args.wp_model)
    sp_tokenizer = AutoTokenizer.from_pretrained(args.sp_model)

    splits = {
        "LAPT pool": args.lapt_pool,
        "Train": args.train,
        "Validation": args.val,
        "Test": args.test,
    }

    results = {}
    for split_name, path in splits.items():
        print(f"\nProcessing {split_name} ({path})...")
        rows = load_jsonl(path)
        print(f"  {len(rows)} documents loaded")
        doc_counts, wp_total, sp_total = count_split(
            rows, wp_tokenizer, sp_tokenizer, args.language_field, args.text_field
        )
        results[split_name] = {
            "n_docs": len(rows),
            "xho_docs": doc_counts.get("isiXhosa", 0),
            "zul_docs": doc_counts.get("isiZulu", 0),
            "wp_tokens": wp_total,
            "sp_tokens": sp_total,
        }
        print(f"  isiXhosa: {doc_counts.get('isiXhosa', 0)} docs, "
              f"isiZulu: {doc_counts.get('isiZulu', 0)} docs")
        print(f"  WordPiece tokens: {wp_total:,}  |  SentencePiece tokens: {sp_total:,}")

    # Totals row
    total = {
        "n_docs": sum(r["n_docs"] for r in results.values()),
        "xho_docs": sum(r["xho_docs"] for r in results.values()),
        "zul_docs": sum(r["zul_docs"] for r in results.values()),
        "wp_tokens": sum(r["wp_tokens"] for r in results.values()),
        "sp_tokens": sum(r["sp_tokens"] for r in results.values()),
    }
    results["Total"] = total

    print("\n" + "=" * 90)
    print(f"{'Split':<12} {'isiXhosa':>10} {'isiZulu':>10} {'Total Docs':>12} "
          f"{'WordPiece Tok.':>16} {'SentencePiece Tok.':>20}")
    print("-" * 90)
    for split_name, r in results.items():
        print(f"{split_name:<12} {r['xho_docs']:>10,} {r['zul_docs']:>10,} {r['n_docs']:>12,} "
              f"{r['wp_tokens']:>16,} {r['sp_tokens']:>20,}")

    import csv
    with open(args.output_csv, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["split", "isixhosa_docs", "isizulu_docs", "total_docs",
                          "wordpiece_tokens", "sentencepiece_tokens"])
        for split_name, r in results.items():
            writer.writerow([split_name, r["xho_docs"], r["zul_docs"], r["n_docs"],
                              r["wp_tokens"], r["sp_tokens"]])
    print(f"\nSaved: {args.output_csv}")


if __name__ == "__main__":
    main()
