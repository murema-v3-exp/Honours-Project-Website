"""
Counts dataset sizes per language and total.

ASSUMPTIONS:
  - Files are JSONL or CSV.
  - Each LAPT pool record has a language field. Expected values look like "xho_Latn"/"zul_Latn" or "xho"/"zul"
  - Each reserved-pool/pair record has a seed_id field uniquely identifying a human/machine pair,
    and the same kind of language field. If your pairs file stores the
    human and machine texts as ONE row per pair, pairs are
    counted as len(rows). If instead your file stores TWO rows per pair
    (one human, one machine, sharing a seed_id), pass --two-rows-per-pair
    and the script will count unique seed_ids instead of raw row counts.
  - Split files are assumed to be one file per split
    (train/val/test), same schema as the reserved pool file.

If none of the candidate field names match what's actually in your file,
the script prints the first row's actual keys so you can see what to add
to the candidate lists below.

USAGE EXAMPLES:

  # LAPT pool only, one file per language
  python count_dataset_sizes.py \
      --lapt-pool-files lapt_pool_xho.jsonl lapt_pool_zul.jsonl

  # LAPT pool as a single combined file (language field distinguishes rows)
  python count_dataset_sizes.py --lapt-pool-files lapt_pool_combined.jsonl

  # Reserved pool / generated pairs, plus train/val/test splits
  python count_dataset_sizes.py \
      --lapt-pool-files lapt_pool_combined.jsonl \
      --reserved-pool-file reserved_pairs.jsonl \
      --split-files train.jsonl val.jsonl test.jsonl \
      --split-names train val test

  # If your pairs file has one row per text (human+machine separate rows)
  python count_dataset_sizes.py \
      --reserved-pool-file reserved_pairs.jsonl --two-rows-per-pair
"""

import argparse
import csv
import json
import os
import sys
from collections import Counter

LANGUAGE_FIELD_CANDIDATES = ["language", "lang", "language_code", "lang_code"]
SEED_ID_FIELD_CANDIDATES = ["seed_id", "seed", "pair_id", "document_id", "doc_id", "id"]


def load_rows(path):
    """Loads a .jsonl/.json or .csv file into a list of dicts."""
    if not os.path.exists(path):
        print(f"  ERROR: file not found: {path}")
        return None

    ext = os.path.splitext(path)[1].lower()
    rows = []
    try:
        if ext in (".jsonl", ".json"):
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    rows.append(json.loads(line))
        elif ext == ".csv":
            with open(path, newline="", encoding="utf-8") as f:
                rows = list(csv.DictReader(f))
        else:
            print(f"  ERROR: unrecognised extension '{ext}' for {path} -- expected .jsonl, .json, or .csv")
            return None
    except Exception as e:
        print(f"  ERROR reading {path}: {e}")
        return None

    return rows


def find_field(rows, candidates, field_purpose):
    """Returns the first candidate field name present in rows[0], or None."""
    if not rows:
        return None
    keys = set(rows[0].keys())
    for c in candidates:
        if c in keys:
            return c
    print(f"  WARNING: none of {candidates} found for {field_purpose}.")
    print(f"  Actual keys in first row: {sorted(keys)}")
    print(f"  -> Add the correct field name to the *_FIELD_CANDIDATES list at the top of this script.")
    return None


def classify_language(value):
    """Maps a raw language field value to 'xho', 'zul', or 'other',
    tolerant of both 'xho_Latn'/'zul_Latn' and 'xho'/'zul' conventions."""
    if value is None:
        return "unknown"
    v = str(value).strip().lower()
    if v.startswith("xho"):
        return "xho"
    if v.startswith("zul"):
        return "zul"
    return f"other ({value})"


def count_lapt_pool(paths):
    print("\n=== LAPT pool ===")
    total = 0
    lang_counts = Counter()
    for path in paths:
        print(f"\nLoading {path} ...")
        rows = load_rows(path)
        if rows is None:
            continue
        print(f"  {len(rows)} documents loaded")
        lang_field = find_field(rows, LANGUAGE_FIELD_CANDIDATES, "language")
        if lang_field is None:
            # can't break down by language, but still count the total
            total += len(rows)
            lang_counts["unknown"] += len(rows)
            continue
        for r in rows:
            lang_counts[classify_language(r.get(lang_field))] += 1
        total += len(rows)

    print("\nLAPT pool totals:")
    for lang, count in sorted(lang_counts.items()):
        print(f"  {lang}: {count} documents")
    print(f"  TOTAL: {total} documents")
    return total, lang_counts


def count_pairs(path, two_rows_per_pair, label):
    print(f"\n=== {label} ===")
    print(f"Loading {path} ...")
    rows = load_rows(path)
    if rows is None:
        return 0, Counter()

    lang_field = find_field(rows, LANGUAGE_FIELD_CANDIDATES, "language")

    if two_rows_per_pair:
        seed_field = find_field(rows, SEED_ID_FIELD_CANDIDATES, "seed_id / pair identifier")
        if seed_field is None:
            print("  Cannot deduplicate to pairs without a seed_id-like field -- "
                  "falling back to raw row count (this will be roughly 2x the true pair count).")
            n_pairs = len(rows)
            lang_counts = Counter(classify_language(r.get(lang_field)) for r in rows) if lang_field else Counter()
        else:
            seen_by_lang = {}
            for r in rows:
                seed = r.get(seed_field)
                lang = classify_language(r.get(lang_field)) if lang_field else "unknown"
                seen_by_lang.setdefault(lang, set()).add(seed)
            lang_counts = Counter({lang: len(ids) for lang, ids in seen_by_lang.items()})
            n_pairs = sum(lang_counts.values())
    else:
        n_pairs = len(rows)
        lang_counts = Counter(classify_language(r.get(lang_field)) for r in rows) if lang_field else Counter()

    print(f"\n{label} totals:")
    for lang, count in sorted(lang_counts.items()):
        print(f"  {lang}: {count} pairs")
    print(f"  TOTAL: {n_pairs} pairs")
    return n_pairs, lang_counts


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--lapt-pool-files", nargs="+", default=[],
                     help="One or more LAPT pool files (per-language or combined)")
    ap.add_argument("--reserved-pool-file", default=None,
                     help="File containing the reserved pool (all pairs before splitting)")
    ap.add_argument("--split-files", nargs="+", default=[],
                     help="Train/val/test split files, in the same order as --split-names")
    ap.add_argument("--split-names", nargs="+", default=[],
                     help="Names for each split file, e.g. train val test")
    ap.add_argument("--two-rows-per-pair", action="store_true",
                     help="Pass this if human and machine texts are stored as SEPARATE rows "
                          "sharing a seed_id, rather than one row per pair")
    args = ap.parse_args()

    if not args.lapt_pool_files and not args.reserved_pool_file and not args.split_files:
        print("Nothing to do -- pass at least one of --lapt-pool-files, "
              "--reserved-pool-file, or --split-files. Run with -h for usage examples.")
        sys.exit(1)

    if args.lapt_pool_files:
        count_lapt_pool(args.lapt_pool_files)

    if args.reserved_pool_file:
        count_pairs(args.reserved_pool_file, args.two_rows_per_pair, "Reserved pool (all pairs)")

    if args.split_files:
        if len(args.split_names) != len(args.split_files):
            print(f"WARNING: {len(args.split_files)} split files but {len(args.split_names)} names given; "
                  f"using generic names.")
            args.split_names = [f"split_{i}" for i in range(len(args.split_files))]

        print("\n=== Train/Val/Test splits ===")
        split_total = 0
        for path, name in zip(args.split_files, args.split_names):
            n, _ = count_pairs(path, args.two_rows_per_pair, f"Split: {name}")
            split_total += n
        print(f"\nSum across all provided splits: {split_total} pairs")


if __name__ == "__main__":
    main()
