"""
Diagnose URL-overlap severity:

Follow-up to verify_no_lapt_overlap.py finding URL overlap with zero id
overlap. consistent with CommonCrawl re-crawling the same URL at
different times. If the text is near-identical, that's real leakage. if it
differs substantially, it's just two snapshots of an evolving page.

Reports word-level Jaccard similarity per overlapping URL, so the actual
distribution is visible rather than guessed from a few examples.

Usage:
    python diagnose_url_overlap.py \\
        --lapt LAPT_data/fineweb2_lapt_pool_final.jsonl \\
        --paired LAPT_data/xho_paired.jsonl LAPT_data/zul_paired.jsonl
"""

import argparse
import json


def load_jsonl(path):
    rows = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    rows.append(json.loads(line))
    except FileNotFoundError:
        print(f"  ERROR: file not found: {path}")
        return None
    return rows


def jaccard_similarity(text_a, text_b):
    words_a = set(text_a.split())
    words_b = set(text_b.split())
    if not words_a and not words_b:
        return 1.0
    if not words_a or not words_b:
        return 0.0
    return len(words_a & words_b) / len(words_a | words_b)


def main():
    parser = argparse.ArgumentParser(description="Diagnose severity of URL overlap between LAPT and generated pairs")
    parser.add_argument("--lapt", default="LAPT_data/fineweb2_lapt_pool_final.jsonl")
    parser.add_argument("--paired", nargs="+", default=["LAPT_data/xho_paired.jsonl", "LAPT_data/zul_paired.jsonl"])
    parser.add_argument("--show", type=int, default=15, help="How many examples to print in detail")
    args = parser.parse_args()

    print(f"Loading LAPT pool: {args.lapt}")
    lapt = load_jsonl(args.lapt)
    if lapt is None:
        return
    print(f"  {len(lapt)} documents")

    lapt_by_url = {}
    for doc in lapt:
        url = doc.get("url")
        if url:
            lapt_by_url.setdefault(url, []).append(doc)

    print(f"\nLoading paired files: {args.paired}")
    all_paired = []
    for path in args.paired:
        rows = load_jsonl(path)
        if rows is None:
            return
        print(f"  {path}: {len(rows)} records")
        all_paired.extend(rows)

    # One record per url from the paired side is enough
    paired_human_by_url = {}
    for r in all_paired:
        if r.get("label") == "human" and r.get("url"):
            paired_human_by_url[r["url"]] = r

    overlap_urls = set(lapt_by_url.keys()) & set(paired_human_by_url.keys())
    print(f"\nOverlapping URLs: {len(overlap_urls)}")

    if not overlap_urls:
        print("Nothing to diagnose - no URL overlap found.")
        return

    similarities = []
    for url in overlap_urls:
        lapt_doc = lapt_by_url[url][0]  # if multiple, check the first
        paired_doc = paired_human_by_url[url]
        sim = jaccard_similarity(lapt_doc.get("text", ""), paired_doc.get("text", ""))
        similarities.append((url, sim, lapt_doc, paired_doc))

    similarities.sort(key=lambda x: -x[1])  # most similar first, worst leakage risk first

    print(f"\n{'='*70}")
    print("Similarity distribution (word-level Jaccard, 1.0 = identical text)")
    print(f"{'='*70}")
    high = sum(1 for _, s, _, _ in similarities if s >= 0.8)
    medium = sum(1 for _, s, _, _ in similarities if 0.3 <= s < 0.8)
    low = sum(1 for _, s, _, _ in similarities if s < 0.3)
    print(f"  >= 0.8 (near-identical - real leakage concern): {high}")
    print(f"  0.3-0.8 (partial overlap - worth a look):        {medium}")
    print(f"  < 0.3 (substantially different - likely fine):    {low}")

    print(f"\n{'='*70}")
    print(f"Top {min(args.show, len(similarities))} most similar (highest leakage risk first)")
    print(f"{'='*70}")
    for url, sim, lapt_doc, paired_doc in similarities[:args.show]:
        print(f"\nSimilarity: {sim:.2f}  |  {url}")
        print(f"  LAPT date={lapt_doc.get('date')}  id={lapt_doc.get('id')}")
        print(f"  Paired date={paired_doc.get('date')}")
        print(f"  LAPT text:   {lapt_doc.get('text','')[:150]!r}")
        print(f"  Paired text: {paired_doc.get('text','')[:150]!r}")

    print(f"\n{'='*70}")
    if high > 0:
        print(f"ACTION NEEDED: {high} URL(s) have near-identical text between LAPT "
              f"and the generated pairs - this is real leakage. These should be "
              f"removed from LAPT.")
    else:
        print("No near-identical overlaps found - the URL matches appear to be "
              "different content (e.g. an updated page re-crawled at a different "
              "time), not genuine leakage.")
    print(f"{'='*70}")


if __name__ == "__main__":
    main()
