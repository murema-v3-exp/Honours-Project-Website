"""
Baseline FineWeb-2 filtering pipeline: isiXhosa + isiZulu

Runs a chain of Arrow-native filters (score/year, domain, minhash, length,
prose-content, exact dedup), then switches to pandas for the final
LAPT/reserved split and per-domain capping

"""

import gc
import hashlib
import os
import re
from collections import Counter, defaultdict
from urllib.parse import urlparse

import pandas as pd
from datasets import load_dataset, concatenate_datasets, Dataset
from sklearn.model_selection import train_test_split


def stable_doc_id(language: str, fineweb_id: str) -> str:
    """
    Uses FineWeb-2's own native `id` (a UUID assigned per document at
    dataset-build time), documented as unique - simpler and more
    trustworthy than hashing url+date ourselves.
    """
    return f"{language}_{fineweb_id}"


# CONFIG
LANGUAGES = ["xho_Latn", "zul_Latn"]

MIN_LANGUAGE_SCORE = 0.95
MIN_YEAR = None
MAX_YEAR = 2021

MIN_DOMAIN_COUNT = 5

# Domains excluded EVERYWHERE (both LAPT and reserved pool), Currently:
#   - staffbull.msk.ru: English bot-spam mislabeled as isiXhosa by
#     FineWeb-2's language classifier with high confidence (0.95-0.997)
#     a language-ID failure the score threshold alone can't catch.
#   - mymemory.translated.net: translation-memory database dump
#   - pornomamki.ru, zu.urdolls.com, nakedbuildersneworleans.com:
#     confirmed adult content.
# Keyword matching only finds candidates, content is verified per-domain
# before adding here (e.g. myemptysexlife.com matched "sex" in its name
# but its content is unrelated SEO text, and was NOT added).
DOMAIN_BLOCKLIST = {
    "staffbull.msk.ru",
    "mymemory.translated.net",
    "pornomamki.ru",
    "zu.urdolls.com",
    "nakedbuildersneworleans.com",
    # Full videochat/video-chat family: confirmed adult webcam content
    # across multiple domains. Already excluded from the reserved pool via
    # the farm-shape regex (xh. prefix); listed here to also remove from LAPT.
    "xh.videochat.life", "xh.video-chat.love", "xh.videochat.si",
    "xh.videochat.world", "xh.videochat.cafe", "xh.videochat.bz",
    "xh.video-chat.cn", "xh.videochat.tv.br", "xh.videochat.date",
    "xh.videochat.mx", "xh.videochat.ph", "xh.video-chat.in",
    "xh.videochat.show",
}

# Domains excluded only from the reserved pool. Kept in LAPT. Explicit list + a farm-shape regex.
RESERVED_ONLY_EXCLUDE_EXPLICIT = {
    "jw.org",
    "biblesa.co.za",
    "xh.airbnb.com",     # abot 65% of raw isiXhosa domain-filtered docs on a
                          # real run - dominant MT-translated listing content
    "xh.airbnb.co.za",
}

FARM_DOMAIN_PREFIX_PATTERN = re.compile(r"^[a-z]{2,3}\.")


def is_farm_shaped(domain: str) -> bool:
    """
    Flags {2-3 letter prefix}.{root-domain} shaped subdomains - the pattern
    seen in auto-translate SEO networks (xh.martech.zone, zu.inditics.com).
    Doesn't catch legitimate language editions like isizulu.news24.com
    (7-letter prefix), but still worth spot-checking new output.
    """
    return bool(FARM_DOMAIN_PREFIX_PATTERN.match(domain))


MAX_MINHASH_CLUSTER_SIZE = 50    # set to None to disable
MIN_CHARS = 200

RESERVED_POOL_FRACTION = 0.1
RANDOM_SEED = 42

MAX_DOMAIN_SHARE_LAPT = 0.15 # cap the percentage of one domain to ~15\%
MAX_DOMAIN_SHARE_RESERVED = 0.15 

TOP_N_DOMAINS_TO_REPORT = 20
# Everything through Stage 7 (exact dedup) runs Arrow-native rather than
# converting to pandas early
# Raise NUM_PROC if you have RAM/disk headroom to spare. 1 is the safer default.
NUM_PROC = 1

DROP_BEFORE_PANDAS = ["top_langs"]  # unused columns, dropped before the final conversion

LAPT_OUTPUT_PATH = "./LAPT_data/fineweb2_lapt_pool.jsonl"
RESERVED_OUTPUT_PATH = "./LAPT_data/fineweb2_reserved_pool.jsonl"


# lightweight (Arrow-native) Diagnostics. single-column only, safe at full size
def report_year_split_ds(ds: Dataset, label: str) -> None:
    print(f"\n--- year distribution per language [{label}] ---")
    counts = defaultdict(Counter)
    for lang, date in zip(ds["language"], ds["date"]):
        counts[lang][date[:4]] += 1
    years = sorted({y for c in counts.values() for y in c})
    for lang in sorted(counts):
        row = {y: counts[lang].get(y, 0) for y in years}
        print(f"  {lang}: {row}")


def report_domain_split_ds(ds: Dataset, label: str, top_n: int = TOP_N_DOMAINS_TO_REPORT) -> None:
    print(f"\n--- domain distribution per language [{label}] ---")
    per_lang = defaultdict(Counter)
    for lang, domain in zip(ds["language"], ds["domain"]):
        per_lang[lang][domain] += 1
    for lang in sorted(per_lang):
        total = sum(per_lang[lang].values())
        print(f"\n[{lang}] total docs: {total} | unique domains: {len(per_lang[lang])}")
        for domain, cnt in per_lang[lang].most_common(top_n):
            print(f"  {domain:35s} {cnt}")


def report_final_counts(df: pd.DataFrame, label: str) -> None:
    print(f"\n--- final doc counts per language [{label}] ---")
    print(df["language"].value_counts())


def report_domain_split(df: pd.DataFrame, label: str, top_n: int = TOP_N_DOMAINS_TO_REPORT) -> None:
    print(f"\n--- domain distribution per language [{label}] ---")
    for lang, group in df.groupby("language"):
        print(f"\n[{lang}] total docs: {len(group)} | unique domains: {group['domain'].nunique()}")
        print(group["domain"].value_counts().head(top_n))


def report_reserved_exclusions(df: pd.DataFrame) -> pd.Series:
    flagged_mask = df["domain"].isin(RESERVED_ONLY_EXCLUDE_EXPLICIT) | df["domain"].apply(is_farm_shaped)
    flagged = df[flagged_mask]
    print(f"\n--- reserved-pool-only exclusion candidates ---")
    print(f"total flagged docs: {len(flagged)} / {len(df)} ({len(flagged) / len(df):.1%})")
    print(flagged.groupby("language").size())
    print("\nflagged domains (per language, by doc count):")
    for lang, group in flagged.groupby("language"):
        print(f"\n[{lang}]")
        print(group["domain"].value_counts().head(TOP_N_DOMAINS_TO_REPORT))
    return flagged_mask



# Stage 1: load + combine train/test per language

def load_combined_language(config_name: str) -> Dataset:
    train = load_dataset("HuggingFaceFW/fineweb-2", config_name, split="train")
    test = load_dataset("HuggingFaceFW/fineweb-2", config_name, split="test")
    combined = concatenate_datasets([train, test])
    print(f"[{config_name}] loaded: train={len(train)} test={len(test)} combined={len(combined)}")
    return combined



# Stage 2: language_score + year filter (Arrow-native)

def filter_score_and_year(ds: Dataset) -> Dataset:
    def _keep(example):
        if example["language_score"] < MIN_LANGUAGE_SCORE:
            return False
        if MIN_YEAR is not None or MAX_YEAR is not None:
            year = int(example["date"][:4])
            if MIN_YEAR is not None and year < MIN_YEAR:
                return False
            if MAX_YEAR is not None and year > MAX_YEAR:
                return False
        return True

    filtered = ds.filter(_keep, num_proc=NUM_PROC)
    print(f"  score+year filter: {len(ds)} -> {len(filtered)}")
    return filtered



# Stage 4: domain extraction (Arrow map) + frequency filtering (Arrow filter)

def extract_domain(url: str) -> str:
    netloc = urlparse(url).netloc
    if netloc.startswith("www."):
        netloc = netloc[4:]
    return netloc


def add_domain_column(ds: Dataset) -> Dataset:
    return ds.map(lambda ex: {"domain": extract_domain(ex["url"])}, num_proc=NUM_PROC)


def filter_domains(ds: Dataset) -> Dataset:
    domain_counts = Counter(ds["domain"])  # only domain strings loaded, not full rows

    keep_domains = {d for d, c in domain_counts.items() if c >= MIN_DOMAIN_COUNT}
    keep_domains -= DOMAIN_BLOCKLIST

    before = len(ds)
    before_unique = len(domain_counts)
    filtered = ds.filter(lambda ex: ex["domain"] in keep_domains, num_proc=NUM_PROC)
    after_unique = len(Counter(filtered["domain"]))
    print(f"  domain filter (min_count={MIN_DOMAIN_COUNT}, universal_blocklist={len(DOMAIN_BLOCKLIST)}): "
          f"{before} -> {len(filtered)}  ({before_unique} -> {after_unique} domains)")
    return filtered


# Stage 5: minhash cluster size filter (Arrow-native)

def filter_minhash_cluster(ds: Dataset) -> Dataset:
    if MAX_MINHASH_CLUSTER_SIZE is None:
        return ds
    before = len(ds)
    filtered = ds.filter(lambda ex: ex["minhash_cluster_size"] <= MAX_MINHASH_CLUSTER_SIZE, num_proc=NUM_PROC)
    print(f"  minhash cluster filter (max={MAX_MINHASH_CLUSTER_SIZE}): {before} -> {len(filtered)}")
    return filtered



# Stage 6: document length filter (Arrow-native)

def filter_length(ds: Dataset) -> Dataset:
    before = len(ds)
    filtered = ds.filter(lambda ex: len(ex["text"]) >= MIN_CHARS, num_proc=NUM_PROC)
    print(f"  length filter (min_chars={MIN_CHARS}): {before} -> {len(filtered)}")
    return filtered


# Stage 6b: prose-content filter (Arrow-native)
# Added after a manual review found a worlddebtclocks.com document made of
# auto-generated transaction codes ("UA1KA UA1KB UA1KC...") that nothing
# else in the pipeline caught.
#
# fraction of "words" that are code/id-like tokens. Threshold is 0.30 rather than the
# initial 0.15 because isiXhosa/isiZulu express numbers as hyphenated
# compounds which also mix letters and
# digits
MAX_CODE_LIKE_TOKEN_FRACTION = 0.30


def fraction_code_like_tokens(text: str) -> float:
    words = text.split()
    if not words:
        return 0.0

    def is_code_like(w):
        w_clean = w.strip(".,!?;:\"'()[]{}|-")
        if not w_clean:
            return False
        has_digit = any(c.isdigit() for c in w_clean)
        has_alpha = any(c.isalpha() for c in w_clean)
        return has_digit and has_alpha  # mixes letters+digit

    code_like = sum(1 for w in words if is_code_like(w))
    return code_like / len(words)


def filter_prose_content(ds: Dataset) -> Dataset:
    before = len(ds)
    filtered = ds.filter(
        lambda ex: fraction_code_like_tokens(ex["text"]) <= MAX_CODE_LIKE_TOKEN_FRACTION,
        num_proc=NUM_PROC,
    )
    print(f"  prose-content filter (max_code_like_fraction={MAX_CODE_LIKE_TOKEN_FRACTION}): "
          f"{before} -> {len(filtered)}")
    return filtered



# Stage 7: exact duplicate check via content hash (Arrow-native)


def dedup_exact(ds: Dataset) -> Dataset:
    ds = ds.map(
        lambda ex: {"text_hash": hashlib.md5(ex["text"].encode("utf-8")).hexdigest()},
        num_proc=NUM_PROC,
    )
    seen = set()
    keep_indices = []
    for i, h in enumerate(ds["text_hash"]):
        if h not in seen:
            seen.add(h)
            keep_indices.append(i)

    before = len(ds)
    deduped = ds.select(keep_indices).remove_columns(["text_hash"])
    dropped = before - len(deduped)
    print(f"  exact dedup: {before} -> {len(deduped)}  ({dropped} exact duplicates removed)")
    return deduped


# Stage 11: per-domain concentration cap on the LAPT pool (pandas)

def cap_domain_representation(df: pd.DataFrame, max_share: float = MAX_DOMAIN_SHARE_LAPT,
                               seed: int = RANDOM_SEED, max_iter: int = 20):
    """
    Per language, caps any single domain at max_share of that language's
    final (post-cap) doc count. Returns (kept_df, overflow_df); overflow is not discarded.

    Iterates rather than capping once
    """
    overflow_all = []
    for _ in range(max_iter):
        kept_parts = []
        overflow_parts = []
        for lang, lang_group in df.groupby("language"):
            lang_total = len(lang_group)
            cap_n = int(lang_total * max_share)
            for domain, domain_group in lang_group.groupby("domain"):
                if len(domain_group) > cap_n:
                    kept = domain_group.sample(n=cap_n, random_state=seed)
                    overflow = domain_group.drop(kept.index)
                    kept_parts.append(kept)
                    overflow_parts.append(overflow)
                else:
                    kept_parts.append(domain_group)
        new_df = pd.concat(kept_parts, ignore_index=True) if kept_parts else df.iloc[0:0].copy()
        if overflow_parts:
            overflow_all.append(pd.concat(overflow_parts, ignore_index=True))
        if len(new_df) == len(df):
            break  # converged, another pass wouldn't remove anything more
        df = new_df

    kept_df = df
    overflow_df = pd.concat(overflow_all, ignore_index=True) if overflow_all else df.iloc[0:0].copy()
    return kept_df, overflow_df



# Stage 9-10: reserved-only exclusion + stratified LAPT/reserved split (pandas)


def ensure_unique_ids(df: pd.DataFrame) -> pd.DataFrame:
    """
    Verifies FineWeb-2's native `id` is actually unique per language in
    THIS data (documented as unique by HuggingFace, but worth checking
    rather than trusting blindly). Disambiguates only the colliding rows
    (appends a url+date hash suffix) rather than crashing the pipeline.
    """
    df = df.copy()
    dup_mask = df.duplicated(subset=["language", "id"], keep=False)
    n_dupes = dup_mask.sum()

    if n_dupes == 0:
        print(f"  id uniqueness check: OK - all {len(df)} (language, id) pairs unique")
        return df

    print(f"  id uniqueness check: FOUND {n_dupes} rows with duplicate (language, id) - "
          f"disambiguating (FineWeb-2's id is documented as unique, but verifying "
          f"beats trusting blindly). Affected rows get a url+date suffix appended "
          f"to their id so downstream seed_id stays unique regardless.")

    def disambiguate(row):
        if not dup_mask.loc[row.name]:
            return row["id"]
        suffix = hashlib.md5(f"{row['url']}|{row['date']}".encode("utf-8")).hexdigest()[:8]
        return f"{row['id']}_{suffix}"

    df["id"] = df.apply(disambiguate, axis=1)

    # If disambiguation still left duplicates (identical id, url and date),
    # fall back to a running counter so the pipeline still completes.
    still_dup = df.duplicated(subset=["language", "id"], keep=False)
    if still_dup.sum() > 0:
        print(f"  still {still_dup.sum()} duplicates after url+date disambiguation - "
              f"applying a final positional-suffix fallback to guarantee uniqueness.")
        counters = {}
        def final_fallback(row):
            if not still_dup.loc[row.name]:
                return row["id"]
            key = (row["language"], row["id"])
            counters[key] = counters.get(key, 0) + 1
            return f"{row['id']}_{counters[key]}"
        df["id"] = df.apply(final_fallback, axis=1)

    assert df.duplicated(subset=["language", "id"], keep=False).sum() == 0, \
        "id uniqueness could not be guaranteed - this should not be reachable"
    return df


def split_lapt_reserved(df: pd.DataFrame):
    df = ensure_unique_ids(df)

    flagged_mask = df["domain"].isin(RESERVED_ONLY_EXCLUDE_EXPLICIT) | df["domain"].apply(is_farm_shaped)
    always_lapt = df[flagged_mask]
    eligible_for_reserved = df[~flagged_mask]

    print(f"  always-LAPT (flagged, excluded from reserved): {len(always_lapt)}")
    print(f"  reserved-eligible before domain cap: {len(eligible_for_reserved)}")

    # Cap the reserved-eligible pool by domain before sampling
    print(f"\n  applying per-domain RESERVED cap (max_share={MAX_DOMAIN_SHARE_RESERVED})...")
    reserved_eligible_capped, lapt_domain_overflow = cap_domain_representation(
        eligible_for_reserved, max_share=MAX_DOMAIN_SHARE_RESERVED
    )
    print(f"  reserved-eligible after cap: {len(reserved_eligible_capped)} "
          f"(overflow redirected to LAPT: {len(lapt_domain_overflow)})")

    target_reserved_n = int(len(df) * RESERVED_POOL_FRACTION)
    if target_reserved_n >= len(reserved_eligible_capped):
        raise ValueError(
            f"Requested reserved pool size ({target_reserved_n}) exceeds domain-capped "
            f"eligible docs ({len(reserved_eligible_capped)}). Lower RESERVED_POOL_FRACTION, "
            f"loosen the exclusion criteria, or raise MAX_DOMAIN_SHARE_RESERVED."
        )

    reserved_df, lapt_eligible_remainder = train_test_split(
        reserved_eligible_capped,
        train_size=target_reserved_n,
        stratify=reserved_eligible_capped["language"],
        random_state=RANDOM_SEED,
    )

    lapt_df_uncapped = pd.concat(
        [lapt_eligible_remainder, always_lapt, lapt_domain_overflow], ignore_index=True
    )

    print(f"\n  pre-cap lapt={len(lapt_df_uncapped)} reserved={len(reserved_df)}")

    print(f"\n  applying per-domain LAPT cap (max_share={MAX_DOMAIN_SHARE_LAPT})...")
    lapt_df, _lapt_overflow_discarded = cap_domain_representation(lapt_df_uncapped, max_share=MAX_DOMAIN_SHARE_LAPT)
    print(f"  post-cap lapt: {len(lapt_df_uncapped)} -> {len(lapt_df)}")

    # Assigned here so it survives future reordering/rebalancing of this pool.
    reserved_df = reserved_df.copy()
    reserved_df["seed_id"] = reserved_df.apply(
        lambda row: stable_doc_id(row["language"], row["id"]), axis=1
    )

    print("\n  reserved pool language breakdown:")
    print(reserved_df["language"].value_counts())
    print("  lapt pool language breakdown (post-cap):")
    print(lapt_df["language"].value_counts())
    return lapt_df, reserved_df


def main():
    per_language_filtered = []

    for config_name in LANGUAGES:
        print(f"\n=== {config_name} ===")
        ds = load_combined_language(config_name)
        ds = filter_score_and_year(ds)
        per_language_filtered.append(ds)

    print("\n=== combining languages ===")
    ds = concatenate_datasets(per_language_filtered)
    del per_language_filtered
    gc.collect()
    print(f"combined across languages: {len(ds)}")

    report_year_split_ds(ds, label="post score+year filter")

    print("\n=== domain extraction ===")
    ds = add_domain_column(ds)

    print("\n=== domain filtering (universal) ===")
    ds = filter_domains(ds)
    gc.collect()

    report_domain_split_ds(ds, label="post domain filter")

    print("\n=== minhash cluster filtering ===")
    ds = filter_minhash_cluster(ds)

    print("\n=== length filtering ===")
    ds = filter_length(ds)
    gc.collect()

    print("\n=== prose-content filtering ===")
    ds = filter_prose_content(ds)
    gc.collect()

    print("\n=== exact dedup ===")
    ds = dedup_exact(ds)
    gc.collect()

    report_year_split_ds(ds, label="final filtered set")
    report_domain_split_ds(ds, label="final filtered set")

    cols_to_drop = [c for c in DROP_BEFORE_PANDAS if c in ds.column_names]
    if cols_to_drop:
        ds = ds.remove_columns(cols_to_drop)

    print(f"\n=== converting to pandas (final size: {len(ds)} rows) ===")
    df = ds.to_pandas()
    del ds
    gc.collect()

    report_final_counts(df, label="final filtered set")

    print("\n=== reserved-pool-only exclusion review ===")
    report_reserved_exclusions(df)

    print("\n=== splitting LAPT vs reserved pool + capping LAPT domain concentration ===")
    lapt_df, reserved_df = split_lapt_reserved(df)
    del df
    gc.collect()

    # Reserved pool doubles as the human-written class later.
    reserved_df = reserved_df.copy()
    reserved_df["label"] = "human"

    print("\n=== domain distribution AFTER cap (LAPT pool) ===")
    report_domain_split(lapt_df, label="lapt pool, post-cap")

    print("\n=== domain distribution (reserved pool) ===")
    report_domain_split(reserved_df, label="reserved pool, post-cap")

    os.makedirs(os.path.dirname(LAPT_OUTPUT_PATH), exist_ok=True)
    lapt_df.to_json(LAPT_OUTPUT_PATH, orient="records", lines=True, force_ascii=False)
    reserved_df.to_json(RESERVED_OUTPUT_PATH, orient="records", lines=True, force_ascii=False)

    print(f"\nSaved: {LAPT_OUTPUT_PATH}, {RESERVED_OUTPUT_PATH}")


if __name__ == "__main__":
    main()