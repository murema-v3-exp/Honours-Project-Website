"""
Gemma 3 4B IT text generation wrapper.

Loads the model once at import time; call generate_text(prompt) to sample
a continuation. dtype/device are picked automatically per backend.
"""

import os
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

MODEL_ID = "google/gemma-3-4b-it"

# Env override takes priority otherwise taken from whether torch is a HIP (ROCm) build.
_BACKEND_OVERRIDE = os.environ.get("GEMMA_BACKEND", "auto").lower()
if _BACKEND_OVERRIDE == "rocm":
    IS_ROCM = True
elif _BACKEND_OVERRIDE == "cuda":
    IS_ROCM = False
else:
    IS_ROCM = torch.version.hip is not None

if torch.cuda.is_available():
    device = torch.device("cuda")
else:
    device = torch.device("cpu")

# Gemma 3 has a confirmed float16 overflow bug: intermediate activations
# exceed fp16's ~65504 max, producing NaN logits straight from the forward
# pass (verified via torch.isnan(logits).any()), regardless of decoding
# strategy, prompt or language. bfloat16 has float32's exponent range and
# doesn't overflow here, so it's used unconditionally on CUDA - T4 lacks
# bf16 tensor cores but still runs it correctly in software (just slower).
#
# ROCm still uses float16 here since bf16 hasn't been verified on that
# hardware against this specific issue.
TORCH_DTYPE = torch.float16 if IS_ROCM else torch.bfloat16

print(f"Using device: {device}")
if torch.cuda.is_available():
    print(f"  GPU: {torch.cuda.get_device_name(0)}")
    print(f"  Backend: {'ROCm' if IS_ROCM else 'CUDA'}")
print(f"  dtype: {TORCH_DTYPE}")

tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)

model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID,
    torch_dtype=TORCH_DTYPE,
    device_map="auto",
)

# Gemma's chat/IT format ends turns with <end_of_turn>, which
# tokenizer.eos_token_id (typically <eos>) doesn't cover on its own.
_eos_ids = [tokenizer.eos_token_id]
_end_of_turn_id = tokenizer.convert_tokens_to_ids("<end_of_turn>")
if _end_of_turn_id is not None and _end_of_turn_id != tokenizer.unk_token_id:
    _eos_ids.append(_end_of_turn_id)


def generate_text(prompt, max_new_tokens=260, min_new_tokens=60, temperature=0.8, top_p=0.95):
    """
    Returns the generated continuation as a string, or "" if generation
    failed. Callers should treat an empty string the same as
    any other rejected sample.
    """
    messages = [
        {"role": "user", "content": prompt}
    ]

    try:
        inputs = tokenizer.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=True,
            return_tensors="pt",
            return_dict=True,
        ).to(model.device)

        with torch.no_grad():
            outputs = model.generate(
                input_ids=inputs["input_ids"],
                attention_mask=inputs["attention_mask"],
                max_new_tokens=max_new_tokens,
                min_new_tokens=min_new_tokens,
                # Guards against the model picking "stop" as its first token.
                # 60 matches this pipeline's MIN_GENERATED_WORDS.
                eos_token_id=_eos_ids,
                pad_token_id=tokenizer.eos_token_id,
                do_sample=True,
                temperature=temperature,
                top_p=top_p,
            )

        generated = outputs[0][inputs["input_ids"].shape[1]:]

        return tokenizer.decode(generated, skip_special_tokens=True).strip()

    except Exception as e:
        # log and let the caller treat "" like any other rejected sample.
        print(f"[generate_text] generation failed, skipping sample: {e}")
        try:
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except Exception:
            # A "device-side assert triggered" CUDA error corrupts the CUDA
            # context for the rest of the session.
            print("[generate_text] CUDA context appears corrupted (device-side assert). "
                  "Restart the runtime (Runtime > Restart session) and re-run the setup "
                  "cells before continuing - further calls will keep failing otherwise.")
        return ""
