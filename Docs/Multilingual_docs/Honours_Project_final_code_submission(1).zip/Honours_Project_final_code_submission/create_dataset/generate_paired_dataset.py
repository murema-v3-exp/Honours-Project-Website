import os
import json
import random
import re
from collections import Counter

from gemma_generator import generate_text
from glotlid_verify import is_correct_language, detect_language
from quality_filters import check_quality



# Configuration

NUM_SAMPLES = 120  # accepted PAIRS per language 

LANGUAGES = ["xho", "zul"]

LANG_CODES = {
    "xho": "xho_Latn",
    "zul": "zul_Latn",
}

RESERVED_POOL_PATH = "./LAPT_data/fineweb2_reserved_pool.jsonl"

RANDOM_SEED = 42

# Context fed to Gemma, in words.
CONTEXT_WORD_RANGE = (40, 100)

# Human continuation length, in words
CONTINUATION_WORD_RANGE = (70, 150)

# A document needs at least this many words to guarantee a valid split
# under the ranges above
MIN_TOTAL_WORDS = 260

MIN_GENERATED_WORDS = 60  # reject generations shorter than this


# Prompt Templates

PROMPT_TEMPLATES = {

    "xho": """
You are a native isiXhosa speaker.

Below is the beginning of a document.

<context>
{context}
</context>

Continue this document naturally, in the same style and format as the context.

Requirements:

- Write ONLY in isiXhosa.
- Do NOT copy any sentences from the context.
- Do NOT simply restate or rephrase information already given in the
  context - introduce new, specific details that advance the topic,
  narrative, or argument.
- Do NOT translate.
- Do NOT explain what you are doing.
- Do NOT include the word "Translation".
- If the context reads like a list, article, or promotional page, continue in
  that same format - headings, lists, or other formatting are fine if they
  fit naturally as a continuation.
- Produce natural, fluent isiXhosa.
- Length: approximately 70-150 words.

Continuation:
""",

    "zul": """
You are a native isiZulu speaker.

Below is the beginning of a document.

<context>
{context}
</context>

Continue this document naturally, in the same style and format as the context.

Requirements:

- Write ONLY in isiZulu.
- Do NOT copy any sentences from the context.
- Do NOT simply restate or rephrase information already given in the
  context - introduce new, specific details that advance the topic,
  narrative, or argument.
- Do NOT translate.
- Do NOT explain what you are doing.
- Do NOT include the word "Translation".
- If the context reads like a list, article, or promotional page, continue in
  that same format - headings, lists, or other formatting are fine if they
  fit naturally as a continuation.
- Produce natural, fluent isiZulu.
- Length: approximately 70-150 words.

Continuation:
"""
}



# Helpers

def load_reserved_pool(language):
    """
    Loads seed candidates from the already-filtered reserved pool JSONL
    not raw FineWeb-2.
    """
    docs = []
    with open(RESERVED_POOL_PATH, "r", encoding="utf-8") as f:
        for line in f:
            record = json.loads(line)
            if record.get("language") == language:
                docs.append(record)
    return docs


# Simple punctuation-based sentence splitter.
SENTENCE_SPLIT_PATTERN = re.compile(r"(?<=[.!?])\s+")


def split_sentences(text):
    text = text.strip()
    if not text:
        return []
    return [s for s in SENTENCE_SPLIT_PATTERN.split(text) if s]


def take_sentences_within_range(sentences, min_words, max_words):
    """
    Greedily accumulates whole sentences until the word
    count falls within [min_words, max_words]. Slightly overshooting
    max_words to reach min_words is accepted.
    """
    accumulated = []
    word_count = 0
    for sentence in sentences:
        accumulated.append(sentence)
        word_count += len(sentence.split())
        if word_count >= min_words:
            break

    if word_count < min_words:
        return None

    return " ".join(accumulated), word_count


def split_context_and_continuation(text, rng):
    """
    Splits one document into (context, human_continuation) at sentence
    boundaries.
    """
    sentences = split_sentences(text)
    if not sentences:
        return None

    context_min, context_max = CONTEXT_WORD_RANGE
    context_sentences = []
    word_count = 0
    split_idx = 0

    for i, sentence in enumerate(sentences):
        sentence_words = len(sentence.split())
        if word_count + sentence_words > context_max and word_count >= context_min:
            break
        context_sentences.append(sentence)
        word_count += sentence_words
        split_idx = i + 1
        if word_count >= context_max:
            break

    if word_count < context_min:
        return None  # not enough sentences to build a minimal context

    remaining_sentences = sentences[split_idx:]
    if not remaining_sentences:
        return None

    result = take_sentences_within_range(remaining_sentences, *CONTINUATION_WORD_RANGE)
    if result is None:
        return None

    human_continuation, _ = result
    context = " ".join(context_sentences)
    return context, human_continuation


def trim_generated_to_sentence_boundary(generated_text):
    """
    Gemma's output can end mid-sentence. Trims to
    the last complete sentence within the target range
    """
    sentences = split_sentences(generated_text)
    if not sentences:
        return None
    result = take_sentences_within_range(sentences, MIN_GENERATED_WORDS, CONTINUATION_WORD_RANGE[1])
    if result is None:
        return None
    trimmed_text, _ = result
    return trimmed_text



# Generation Function

def generate_paired_samples(language):

    print("\n" + "=" * 60)
    print(f"Generating {language.upper()} paired samples")
    print("=" * 60)

    print(f"Loading reserved pool candidates for '{language}'...")
    docs = load_reserved_pool(language)
    print(f"  {len(docs)} candidate documents available")

    rng = random.Random(RANDOM_SEED)
    rng.shuffle(docs)

    accepted_pairs = []

    filtered_length = 0
    rejected_generation_length = 0
    rejected_quality = Counter()
    rejected_language = 0

    for seed_index, doc in enumerate(docs):

        if len(accepted_pairs) >= NUM_SAMPLES:
            break

        split = split_context_and_continuation(doc["text"], rng)
        if split is None:
            filtered_length += 1
            continue

        context, human_continuation = split

        prompt = PROMPT_TEMPLATES[language].format(context=context)
        raw_generated = generate_text(prompt)

        generated = trim_generated_to_sentence_boundary(raw_generated)
        if generated is None:
            rejected_generation_length += 1
            continue

        quality_ok, quality_reason = check_quality(generated, context)
        if not quality_ok:
            rejected_quality[quality_reason] += 1
            print(f"Rejected (quality: {quality_reason})")
            continue

        if not is_correct_language(generated, LANG_CODES[language]):
            rejected_language += 1
            detected = detect_language(generated)[0]
            print(f"Rejected ({detected})")
            continue

        seed_id = f"{language}_{seed_index}"
        shared_meta = {
            "seed_id": seed_id,
            "lang": language,
            "domain": doc.get("domain"),
            "url": doc.get("url"),
            "date": doc.get("date"),
        }

        accepted_pairs.append({**shared_meta, "text": human_continuation, "label": "human"})
        accepted_pairs.append({**shared_meta, "text": generated, "label": "machine"})

        print(f"Accepted pair {len(accepted_pairs) // 2}/{NUM_SAMPLES}  (seed_id={seed_id})")

    print("\nFiltering Statistics")
    print("-" * 35)
    print(f"Source docs too short for split : {filtered_length}")
    print(f"Generation too short             : {rejected_generation_length}")
    for reason, count in rejected_quality.items():
        print(f"Rejected ({reason:<16s})        : {count}")
    print(f"Generation wrong language        : {rejected_language}")
    print(f"Accepted pairs                   : {len(accepted_pairs) // 2}")

    return accepted_pairs


if __name__ == "__main__":

    os.makedirs("LAPT_data", exist_ok=True)

    for language in LANGUAGES:

        pairs = generate_paired_samples(language)

        outfile = f"LAPT_data/{language}_paired.jsonl"

        with open(outfile, "w", encoding="utf-8") as f:
            for record in pairs:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")

        print("\nSaved")
        print(f"{len(pairs)} records ({len(pairs) // 2} pairs) -> {outfile}")