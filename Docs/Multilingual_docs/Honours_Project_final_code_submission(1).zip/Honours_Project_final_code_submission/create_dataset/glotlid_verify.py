"""
GlotLID language ID, used to verify Gemma's generated continuations are
actually in the target language before being accepted
"""

from huggingface_hub import hf_hub_download
import fasttext

model_path = hf_hub_download(
    repo_id="cis-lmu/glotlid",
    filename="model.bin"
)

glotlid = fasttext.load_model(model_path)


def detect_language(text):
    """Returns top-3 (language_code, score) predictions, highest first."""
    text = text.replace("\n", " ").strip()
    labels, scores = glotlid.predict(text, k=3)
    labels = [l.replace("__label__", "") for l in labels]
    return list(zip(labels, scores))


def is_correct_language(text, expected_language, threshold=0.80):
    """True if GlotLID's top prediction matches expected_language with at
    least threshold confidence."""
    prediction = detect_language(text)[0]
    return (
        prediction[0] == expected_language
        and prediction[1] >= threshold
    )
