"""
Domain content inspector

A reusable tool for the manual spot-checking. look up a specific domain's documents,
sample random domains within a count range, or list top domains by
frequency. Run against the LAPT/reserved pool JSONL files directly.

Usage examples:

  # Show documents from a specific domain
  python inspect_domain.py --domain mymemory.translated.net

  # Show 5 documents from a domain, full text (not truncated)
  python inspect_domain.py --domain xh.airbnb.com --sample 5 --full

  # Randomly sample 20 domains with 5-9 total occurrences (one doc each) 
  python inspect_domain.py --random-domains 20 --min-count 5 --max-count 9

  # List the top 30 domains by document count
  python inspect_domain.py --list-top 30

  # Search domain names by substring (e.g. find all "videochat" domains)
  python inspect_domain.py --search videochat

By default, loads both LAPT_data/fineweb2_lapt_pool.jsonl and
LAPT_data/fineweb2_reserved_pool.jsonl if present. override with --files
if your files are named/located differently.
"""

import argparse
import json
import random
from collections import Counter


def load_jsonl(path):
    rows = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    rows.append(json.loads(line))
    except FileNotFoundError:
        print(f"  (not found, skipping: {path})")
    return rows


def load_all(paths):
    all_docs = []
    for path in paths:
        docs = load_jsonl(path)
        print(f"  loaded {len(docs)} docs from {path}")
        all_docs.extend(docs)
    return all_docs


def print_doc(doc, full=False, max_chars=250):
    lang = doc.get("language", "?")
    domain = doc.get("domain", "?")
    url = doc.get("url", "?")
    text = doc.get("text", "")
    print(f"--- {domain} ({lang}) ---")
    print(f"url: {url}")
    if full:
        print(text)
    else:
        preview = text[:max_chars].replace("\n", " ")
        print(f"{preview}{'...' if len(text) > max_chars else ''}")
    print()


def cmd_domain(all_docs, domain, sample, full):
    matches = [d for d in all_docs if d.get("domain") == domain]
    print(f"\n{domain}: {len(matches)} total documents\n")
    if not matches:
        return
    shown = matches[:sample] if sample else matches
    for doc in shown:
        print_doc(doc, full=full)


def cmd_random_domains(all_docs, n, min_count, max_count, full, seed):
    domain_counts = Counter(d.get("domain") for d in all_docs)
    candidates = [d for d, c in domain_counts.items() if min_count <= c <= max_count]
    print(f"\n{len(candidates)} domains with {min_count}-{max_count} total occurrences")

    if not candidates:
        return
    random.seed(seed)
    sample_domains = random.sample(candidates, min(n, len(candidates)))

    for domain in sample_domains:
        doc = next(d for d in all_docs if d.get("domain") == domain)
        print(f"\n[{domain_counts[domain]} occurrences]", end=" ")
        print_doc(doc, full=full)


def cmd_list_top(all_docs, n):
    domain_counts = Counter(d.get("domain") for d in all_docs)
    print(f"\nTop {n} domains by document count:\n")
    for domain, count in domain_counts.most_common(n):
        print(f"  {count:6d}  {domain}")


def cmd_search(all_docs, substring, sample, full):
    domain_counts = Counter(d.get("domain") for d in all_docs)
    matches = [d for d in domain_counts if substring.lower() in d.lower()]
    print(f"\n{len(matches)} domains matching '{substring}':\n")
    for domain in matches:
        print(f"  {domain_counts[domain]:6d}  {domain}")

    if sample:
        print(f"\nShowing sample documents:")
        for domain in matches[:sample]:
            doc = next(d for d in all_docs if d.get("domain") == domain)
            print()
            print_doc(doc, full=full)


def main():
    parser = argparse.ArgumentParser(description="Inspect domain content in LAPT/reserved pools")
    parser.add_argument("--files", nargs="+",
                         default=["LAPT_data/fineweb2_lapt_pool.jsonl", "LAPT_data/fineweb2_reserved_pool.jsonl"],
                         help="JSONL files to load (default: both pool files in LAPT_data/)")
    parser.add_argument("--domain", help="Show documents from a specific domain")
    parser.add_argument("--random-domains", type=int, metavar="N",
                         help="Randomly sample N domains within a count range")
    parser.add_argument("--min-count", type=int, default=5, help="Min occurrences (for --random-domains)")
    parser.add_argument("--max-count", type=int, default=9, help="Max occurrences (for --random-domains)")
    parser.add_argument("--list-top", type=int, metavar="N", help="List top N domains by document count")
    parser.add_argument("--search", help="Search domain names by substring")
    parser.add_argument("--sample", type=int, default=3, help="Number of documents to show per domain")
    parser.add_argument("--full", action="store_true", help="Show full text instead of a truncated preview")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for --random-domains")

    args = parser.parse_args()

    print("Loading files...")
    all_docs = load_all(args.files)
    print(f"Total documents loaded: {len(all_docs)}")

    if args.domain:
        cmd_domain(all_docs, args.domain, args.sample, args.full)
    elif args.random_domains:
        cmd_random_domains(all_docs, args.random_domains, args.min_count, args.max_count,
                            args.full, args.seed)
    elif args.list_top:
        cmd_list_top(all_docs, args.list_top)
    elif args.search:
        cmd_search(all_docs, args.search, args.sample, args.full)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
