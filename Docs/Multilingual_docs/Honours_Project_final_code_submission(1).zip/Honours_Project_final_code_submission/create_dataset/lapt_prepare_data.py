"""
LAPT data preparation for isiXhosa/isiZulu mBERT continued pretraining.

Pipeline:
  1. Load LAPT_data/fineweb2_lapt_pool_final.jsonl
  2. Diagnostic: tokenize a sample per language, report subword fragmentation
     and document length distribution -> informs block_size choice
  3. Deterministic held-out split (hash-based on id, per language, so
     train/eval never mix and re-running is reproducible without a seed file)
  4. Chunk into fixed-length blocks (concat-then-split, not per-doc padding)
  5. Save train/eval splits per language + combined, ready for Trainer

Usage:
  python lapt_prepare_data.py \
      --input LAPT_data/fineweb2_lapt_pool_final.jsonl \
      --tokenizer bert-base-multilingual-cased \
      --output-dir LAPT_data/lapt_prepared \
      --eval-frac 0.02 \
      --block-size 512   # omit to auto-suggest from diagnostic
"""

import argparse
import hashlib
import json
import os
from collections import defaultdict

import numpy as np
from datasets import Dataset, concatenate_datasets
from transformers import AutoTokenizer


def load_jsonl(path):
    docs = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                docs.append(json.loads(line))
    return docs


def deterministic_bucket(doc_id: str, n_buckets: int = 10000) -> int:
    """Stable hash -> bucket in [0, n_buckets), so held-out membership is
    reproducible without persisting a split file."""
    h = hashlib.sha256(doc_id.encode("utf-8")).hexdigest()
    return int(h[:8], 16) % n_buckets


def diagnose_tokenization(docs, tokenizer, sample_size=500):
    """Report words-per-doc, tokens-per-doc, and fragmentation ratio
    (tokens/word) per language."""
    by_lang = defaultdict(list)
    for d in docs:
        by_lang[d["language"]].append(d)

    print("\n=== Tokenization diagnostic ===")
    suggestions = {}
    for lang, lang_docs in by_lang.items():
        sample = lang_docs[: min(sample_size, len(lang_docs))]
        word_counts, token_counts = [], []
        for d in sample:
            text = d["text"]
            word_counts.append(len(text.split()))
            token_counts.append(len(tokenizer.encode(text, add_special_tokens=False)))

        word_counts = np.array(word_counts)
        token_counts = np.array(token_counts)
        frag_ratio = token_counts.sum() / max(word_counts.sum(), 1)

        p50_tok, p90_tok, p99_tok = np.percentile(token_counts, [50, 90, 99])

        print(f"\n[{lang}] n={len(sample)} docs sampled")
        print(f"  words/doc   median={np.median(word_counts):.0f}")
        print(f"  tokens/doc  median={p50_tok:.0f}  p90={p90_tok:.0f}  p99={p99_tok:.0f}")
        print(f"  fragmentation ratio (tokens/word): {frag_ratio:.2f}")
        print(f"  -> most docs need >512 tokens: {(token_counts > 512).mean()*100:.1f}%")
        print(f"  -> most docs need >1024 tokens: {(token_counts > 1024).mean()*100:.1f}%")

        suggestions[lang] = {
            "fragmentation_ratio": float(frag_ratio),
            "median_tokens": float(p50_tok),
            "p90_tokens": float(p90_tok),
        }

    print("\nNote: fragmentation ratio > ~1.5-1.8 suggests the shared mBERT")
    print("vocab is splitting isiXhosa/isiZulu words into several subword")
    print("pieces each -- common for agglutinative morphology against a")
    print("vocab not built with these languages in mind. If both languages")
    print("show high p90/p99 relative to English-typical web docs, prefer")
    print("block_size=512 with concat-chunking (below) over truncation --")
    print("truncating single documents would throw away most of the text.")
    return suggestions


def split_train_eval(docs, eval_frac=0.02, n_buckets=10000):
    """Per-language deterministic split. Held-out docs come from a disjoint
    bucket range, not a random sample, so adding more data later doesn't
    reshuffle existing eval membership."""
    threshold = int(n_buckets * eval_frac)
    train, eval_ = [], []
    for d in docs:
        bucket = deterministic_bucket(d["id"], n_buckets)
        if bucket < threshold:
            eval_.append(d)
        else:
            train.append(d)
    return train, eval_


def chunk_texts(examples, tokenizer, block_size):
    """Concatenate tokenized documents in the batch, inserting a separator
    token at each document boundary, then split into block_size chunks

    must only be called on a batch that is entirely one
    language.
    """
    tokenized = tokenizer(examples["text"], add_special_tokens=False)
    sep_id = tokenizer.sep_token_id
    concatenated = []
    for ids in tokenized["input_ids"]:
        concatenated.extend(ids)
        concatenated.append(sep_id)  # boundary marker between documents
    total_len = (len(concatenated) // block_size) * block_size
    chunks = [concatenated[i : i + block_size] for i in range(0, total_len, block_size)]
    return {"input_ids": chunks}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--tokenizer", default="bert-base-multilingual-cased")
    ap.add_argument("--output-dir", default="LAPT_data/lapt_prepared")
    ap.add_argument("--eval-frac", type=float, default=0.02)
    ap.add_argument("--block-size", type=int, default=None,
                     help="If omitted, diagnostic runs and you re-run with a chosen value.")
    ap.add_argument("--diagnose-sample", type=int, default=500)
    args = ap.parse_args()

    print(f"Loading {args.input} ...")
    docs = load_jsonl(args.input)
    print(f"Loaded {len(docs)} documents")

    by_lang_counts = defaultdict(int)
    for d in docs:
        by_lang_counts[d["language"]] += 1
    print("Per-language counts:", dict(by_lang_counts))

    tokenizer = AutoTokenizer.from_pretrained(args.tokenizer)

    diagnose_tokenization(docs, tokenizer, sample_size=args.diagnose_sample)

    if args.block_size is None:
        print("\nNo --block-size given. Review the diagnostic above, then "
              "re-run with --block-size set (512 is the standard mBERT "
              "default; consider higher only if p90 tokens/doc is far above "
              "it across both languages). Stopping here.")
        return

    train_docs, eval_docs = split_train_eval(docs, eval_frac=args.eval_frac)
    print(f"\nSplit: {len(train_docs)} train docs, {len(eval_docs)} eval docs")
    train_by_lang = defaultdict(int)
    eval_by_lang = defaultdict(int)
    for d in train_docs:
        train_by_lang[d["language"]] += 1
    for d in eval_docs:
        eval_by_lang[d["language"]] += 1
    print("  train per language:", dict(train_by_lang))
    print("  eval per language:", dict(eval_by_lang))

    os.makedirs(args.output_dir, exist_ok=True)

    for split_name, split_docs in [("train", train_docs), ("eval", eval_docs)]:
        # Group by language before chunking, and chunk each language separately.
        per_lang_chunked = []
        for lang in sorted(set(d["language"] for d in split_docs)):
            lang_docs = [d for d in split_docs if d["language"] == lang]
            ds = Dataset.from_list([{"text": d["text"]} for d in lang_docs])
            chunked = ds.map(
                lambda ex: chunk_texts(ex, tokenizer, args.block_size),
                batched=True,
                remove_columns=["text"],
                desc=f"Chunking {split_name}/{lang}",
            )
            chunked = chunked.add_column("language", [lang] * len(chunked))
            print(f"  {split_name}/{lang}: {len(chunked)} blocks")
            per_lang_chunked.append(chunked)

        combined = concatenate_datasets(per_lang_chunked)
        out_path = os.path.join(args.output_dir, split_name)
        combined.save_to_disk(out_path)
        print(f"Saved {split_name}: {len(combined)} total blocks of {args.block_size} tokens -> {out_path}")

    print("\nDone. Load with: datasets.load_from_disk(path)")
    print("Each block now carries a `language` column for per-language eval loss/perplexity later.")


if __name__ == "__main__":
    main()
