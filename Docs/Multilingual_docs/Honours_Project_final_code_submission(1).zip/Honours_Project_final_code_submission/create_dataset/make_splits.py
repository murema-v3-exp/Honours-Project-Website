"""
Train/val/test split of the generated paired dataset.

Splits at the pair level (grouped by seed_id) and independently per
language before combining.

Usage:
    python make_splits.py --paired LAPT_data/xho_paired.jsonl LAPT_data/zul_paired.jsonl
"""

import argparse
import json
import random
from collections import Counter, defaultdict


def load_jsonl(path):
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def write_jsonl(path, rows):
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def split_seed_ids(seed_ids, train_frac, val_frac, seed):
    """Shuffles and splits a list of seed_ids into three disjoint sets."""
    ids = list(seed_ids)
    random.Random(seed).shuffle(ids)
    n = len(ids)
    n_train = int(n * train_frac)
    n_val = int(n * val_frac)
    train_ids = set(ids[:n_train])
    val_ids = set(ids[n_train:n_train + n_val])
    test_ids = set(ids[n_train + n_val:])
    return train_ids, val_ids, test_ids


def main():
    parser = argparse.ArgumentParser(description="Train/val/test split of generated paired data")
    parser.add_argument("--paired", nargs="+", required=True,
                         help="Paired JSONL file(s), e.g. LAPT_data/xho_paired.jsonl LAPT_data/zul_paired.jsonl")
    parser.add_argument("--train-frac", type=float, default=0.8)
    parser.add_argument("--val-frac", type=float, default=0.1)
    # test-frac isn't a separate argument, so the three fractions always sum to exactly 1.0
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--out-prefix", default="", help="Optional prefix for output filenames")
    args = parser.parse_args()

    if args.train_frac + args.val_frac >= 1.0:
        raise ValueError(f"train_frac ({args.train_frac}) + val_frac ({args.val_frac}) "
                          f"must be < 1.0 so test gets a non-empty share")
    test_frac = 1.0 - args.train_frac - args.val_frac

    print("Loading paired files...")
    all_records = []
    for path in args.paired:
        rows = load_jsonl(path)
        print(f"  {path}: {len(rows)} records")
        all_records.extend(rows)

    print(f"\nTotal records: {len(all_records)}")

    # Every seed_id should appear exactly twice (one human, one machine)
    seed_id_counts = Counter(r["seed_id"] for r in all_records)
    malformed = [sid for sid, c in seed_id_counts.items() if c != 2]
    if malformed:
        print(f"\nWARNING: {len(malformed)} seed_ids don't have exactly 2 records "
              f"(one human + one machine). Examples: {malformed[:5]}")
        print("Proceeding anyway, but investigate this before trusting the split.")

    # Human/machine siblings (same seed_id) must stay in the same split.
    # Group seed_ids by language
    records_by_seed_id = defaultdict(list)
    for r in all_records:
        records_by_seed_id[r["seed_id"]].append(r)

    seed_ids_by_lang = defaultdict(set)
    for sid, recs in records_by_seed_id.items():
        lang = recs[0].get("lang") or recs[0].get("language")
        seed_ids_by_lang[lang].add(sid)

    print(f"\nUnique seed_ids (pairs) by language:")
    for lang, sids in seed_ids_by_lang.items():
        print(f"  {lang}: {len(sids)}")

    # isiXhosa and isiZulu are evaluated separately, so each split needs a
    # representative mix of both languages.
    train_ids, val_ids, test_ids = set(), set(), set()
    for lang, sids in seed_ids_by_lang.items():
        t, v, te = split_seed_ids(sids, args.train_frac, args.val_frac, args.seed)
        train_ids |= t
        val_ids |= v
        test_ids |= te

    # Splits are disjoint and cover everything
    assert not (train_ids & val_ids), "train/val overlap - this should be impossible"
    assert not (train_ids & test_ids), "train/test overlap - this should be impossible"
    assert not (val_ids & test_ids), "val/test overlap - this should be impossible"
    all_ids = set(records_by_seed_id.keys())
    assert train_ids | val_ids | test_ids == all_ids, "some seed_ids weren't assigned to any split"

    def collect(ids):
        rows = []
        for sid in ids:
            rows.extend(records_by_seed_id[sid])
        return rows

    train_rows = collect(train_ids)
    val_rows = collect(val_ids)
    test_rows = collect(test_ids)

    print(f"\n{'='*60}")
    print("Split summary")
    print(f"{'='*60}")
    for name, ids, rows in [("train", train_ids, train_rows), ("val", val_ids, val_rows), ("test", test_ids, test_rows)]:
        lang_counts = Counter()
        for sid in ids:
            lang = records_by_seed_id[sid][0].get("lang") or records_by_seed_id[sid][0].get("language")
            lang_counts[lang] += 1
        label_counts = Counter(r["label"] for r in rows)
        print(f"\n{name}: {len(ids)} pairs ({len(rows)} records)")
        print(f"  by language: {dict(lang_counts)}")
        print(f"  by label:    {dict(label_counts)}")

    train_path = f"{args.out_prefix}train.jsonl"
    val_path = f"{args.out_prefix}val.jsonl"
    test_path = f"{args.out_prefix}test.jsonl"

    write_jsonl(train_path, train_rows)
    write_jsonl(val_path, val_rows)
    write_jsonl(test_path, test_rows)

    print(f"\nSaved: {train_path}, {val_path}, {test_path}")
    print(f"(target ratios were train={args.train_frac}, val={args.val_frac}, test={test_frac:.2f})")


if __name__ == "__main__":
    main()
