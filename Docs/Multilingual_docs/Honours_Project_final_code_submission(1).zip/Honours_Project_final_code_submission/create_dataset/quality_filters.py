import re
from collections import Counter


# 1. Prompt artefact detection
# Catches Gemma echoing part of the instruction/prompt instead of (or
# alongside) the actual paragraph 

_ARTEFACT_PATTERNS = [
    r"<context>", r"</context>",
    r"\bparagraph\s*:",
    r"\btranslation\s*:",
    r"\brequirements?\s*:",
    r"\bdo not\b", r"\bdo n't\b",
    r"\bnative\s+isi(xhosa|zulu)\s+speaker\b",
    r"\bwrite\s+only\s+in\b",
    r"\bas an ai\b", r"\blanguage model\b",
    r"\(continued\)",              # fabricated pagination, seen in real output
    r"isalathiso semixholo",       # isiXhosa "table of contents"
]
_ARTEFACT_RE = re.compile("|".join(_ARTEFACT_PATTERNS), re.IGNORECASE)


def has_prompt_artefact(text):
    return bool(_ARTEFACT_RE.search(text))



# 2. English-heavy detection
# GlotLID's top-1 language ID doesn't catch within-document code-switching,
# so a document can still be mostly English and pass. This is a cheap
# word-level heuristic instead: flag text that has a large fraction of English words in it

_ENGLISH_STOPWORDS = {
    "the", "is", "and", "of", "to", "in", "for", "with", "a", "on", "that",
    "this", "it", "as", "are", "was", "were", "be", "by", "an", "at", "or",
    "but", "not", "have", "has", "had", "you", "your", "we", "our", "they",
    "their", "he", "she", "his", "her", "which", "will", "would", "can",
    "could", "about", "into", "than", "then", "so", "if", "there",
}


def english_word_fraction(text):
    words = re.findall(r"[a-zA-Z]+", text.lower())
    if not words:
        return 0.0
    english_count = sum(1 for w in words if w in _ENGLISH_STOPWORDS)
    return english_count / len(words)


def is_english_heavy(text, threshold=0.15):
    return english_word_fraction(text) >= threshold

# 3. Repetition detection

# Catches the model looping on the same phrase/sentence.
# Two checks: word-level
# type-token ratio (low = lots of repeated words), and exact-duplicate
# sentences, a stronger signal than TTR alone since TTR is naturally lower
# in short texts regardless.

_SENTENCE_SPLIT_PATTERN = re.compile(r"(?<=[.!?])\s+")


def type_token_ratio(text):
    words = text.split()
    if not words:
        return 1.0
    return len(set(words)) / len(words)


def has_duplicate_sentences(text):
    sentences = [s.strip() for s in _SENTENCE_SPLIT_PATTERN.split(text) if s.strip()]
    if len(sentences) < 2:
        return False
    counts = Counter(sentences)
    return any(c > 1 for c in counts.values())


def max_periodic_repeat(words, period):
    """
    Longest run where words[i] == words[i+period]. detects a phrase of
    length period repeating back-to-back. 
    """
    n = len(words)
    if n <= period:
        return 0
    max_run = 0
    current_run = 0
    for i in range(n - period):
        if words[i] == words[i + period]:
            current_run += 1
            max_run = max(max_run, current_run)
        else:
            current_run = 0
    return max_run


def has_degenerate_repetition(text, max_period=6, min_repeats=3):
    """
    Flags a phrase of 1-6 words repeating back-to-back at least
    min_repeats times. covers both single-word collapse ("ukuba ukuba
    ukuba...") and longer-phrase cyclic collapse. min_repeats=3 is picked
    to catch genuine collapse without flagging incidental repetition
    """
    words = text.split()
    for period in range(1, max_period + 1):
        run = max_periodic_repeat(words, period)
        if run >= (min_repeats - 1) * period:
            return True
    return False


def is_repetitive(text, min_ttr=0.4, max_period=6, min_repeats=3):
    return (
        type_token_ratio(text) < min_ttr
        or has_duplicate_sentences(text)
        or has_degenerate_repetition(text, max_period=max_period, min_repeats=min_repeats)
    )


# 4. Script validity
# isiXhosa/isiZulu are both Latin-script. Checks alphabetic characters are
# overwhelmingly Latin, catching generation that degenerates into another
# script.

def latin_alpha_fraction(text):
    alpha_chars = [c for c in text if c.isalpha()]
    if not alpha_chars:
        return 1.0
    latin_count = sum(1 for c in alpha_chars if ord(c) < 0x250)  # Basic Latin + Latin-1/Extended range
    return latin_count / len(alpha_chars)


def is_valid_script(text, min_latin_fraction=0.95):
    return latin_alpha_fraction(text) >= min_latin_fraction



# Combined check

def longest_common_word_run(text_a, text_b):
    """
    Longest neighbouring run of shared words between two texts
    """
    words_a = text_a.split()
    words_b = text_b.split()
    na, nb = len(words_a), len(words_b)
    if na == 0 or nb == 0:
        return 0
    prev = [0] * (nb + 1)
    best = 0
    for i in range(1, na + 1):
        curr = [0] * (nb + 1)
        for j in range(1, nb + 1):
            if words_a[i - 1] == words_b[j - 1]:
                curr[j] = prev[j - 1] + 1
                best = max(best, curr[j])
        prev = curr
    return best


def has_context_copy(generated_text, context_text, max_allowed_run=10):
    """
    Flags generated text with a long verbatim word run copied from the
    context. 10+ consecutive identical words is beyond what shared
    vocabulary or topic overlap alone would explain.
    """
    if not context_text:
        return False
    return longest_common_word_run(generated_text, context_text) > max_allowed_run


def check_quality(text, context=None):
    """
    Runs all checks, cheapest first, so a fast rejection short-circuits the
    rest. context is optional

    Returns (passed: bool, reason: str or None).
    """
    if has_prompt_artefact(text):
        return False, "prompt_artefact"
    if is_repetitive(text):
        return False, "repetitive"
    if not is_valid_script(text):
        return False, "invalid_script"
    if is_english_heavy(text):
        return False, "english_heavy"
    if context and has_context_copy(text, context):
        return False, "context_copy"
    return True, None
