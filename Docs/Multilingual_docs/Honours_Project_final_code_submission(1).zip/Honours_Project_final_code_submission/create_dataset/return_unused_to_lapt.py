"""
Return unused reserved-pool documents to LAPT.

fold it back into unused docs back into LAPT.
 Writes a new LAPT_data/fineweb2_lapt_pool_final.jsonl rather than
overwriting the original LAPT pool file.

run this after generation is fully complete for both
languages.
"""

import json
from collections import Counter

RESERVED_POOL_PATH = "./LAPT_data/fineweb2_reserved_pool.jsonl"
LAPT_POOL_PATH = "./LAPT_data/fineweb2_lapt_pool.jsonl"

PAIRED_PATHS = {
    "xho": "./LAPT_data/xho_paired.jsonl",
    "zul": "./LAPT_data/zul_paired.jsonl",
}

LAPT_OUTPUT_PATH = "./LAPT_data/fineweb2_lapt_pool_final.jsonl"  # written fresh, doesn't overwrite the original


def load_jsonl(path):
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def main():
    print("Loading reserved pool...")
    reserved = load_jsonl(RESERVED_POOL_PATH)
    print(f"  {len(reserved)} total reserved-pool documents")

    print("\nLoading generated paired output...")
    used_seed_ids = set()
    for language, path in PAIRED_PATHS.items():
        try:
            paired = load_jsonl(path)
        except FileNotFoundError:
            print(f"  [{language}] no paired file found at {path} - treating as 0 accepted")
            continue
        lang_seed_ids = set(r["seed_id"] for r in paired)
        used_seed_ids |= lang_seed_ids
        print(f"  [{language}] {len(lang_seed_ids)} accepted pairs (unique seed_ids)")

    print(f"\nTotal accepted across both languages: {len(used_seed_ids)}")

    # A reserved-pool document whose seed_id doesn't appear in the paired
    # output was rejected or never attempted. Matching by
    # seed_id (stable, content-based) rather than position is safe against
    # reordering.
    unused = [doc for doc in reserved if doc["seed_id"] not in used_seed_ids]
    print(f"Unused reserved-pool documents (rejected or never attempted): {len(unused)}")

    # Per-language breakdown for a clear report
    unused_by_lang = Counter(doc["language"] for doc in unused)
    print("  by language:")
    for lang, count in unused_by_lang.items():
        print(f"    {lang}: {count}")

    print(f"\nLoading LAPT pool...")
    lapt = load_jsonl(LAPT_POOL_PATH)
    print(f"  {len(lapt)} existing LAPT documents")

    # Strip reserved-pool-only fields (seed_id, label)
    cleaned_unused = []
    for doc in unused:
        doc = dict(doc)
        doc.pop("seed_id", None)
        doc.pop("label", None)
        cleaned_unused.append(doc)

    combined_lapt = lapt + cleaned_unused
    print(f"\nFinal LAPT pool size: {len(lapt)} + {len(cleaned_unused)} = {len(combined_lapt)}")

    with open(LAPT_OUTPUT_PATH, "w", encoding="utf-8") as f:
        for doc in combined_lapt:
            f.write(json.dumps(doc, ensure_ascii=False) + "\n")

    print(f"\nSaved: {LAPT_OUTPUT_PATH}")
    print("(original LAPT pool file untouched - this is a new, separate output)")


if __name__ == "__main__":
    main()
