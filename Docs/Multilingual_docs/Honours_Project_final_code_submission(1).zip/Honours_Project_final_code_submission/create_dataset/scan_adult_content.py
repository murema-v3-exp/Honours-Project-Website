"""
Adult-content domain scanner.

Reusable version of the manual review process used to find and verify the
domains in filter_fineweb2.py's DOMAIN_BLOCKLIST. Flags candidate domains.

Usage:
    python scan_adult_content.py --files LAPT_data/fineweb2_lapt_pool.jsonl LAPT_data/fineweb2_reserved_pool.jsonl
    python scan_adult_content.py --domain xh.videochat.life --full   # inspect one candidate
"""

import argparse
import json
import re
from collections import Counter, defaultdict

# Word-boundary regex
# Manual verification needed
INDICATORS = [
    r"\b(porn|porno|pornography|pornographic|porny)\b", 
    r"\bxxx+\b", r"\bescort\w*\b", r"\bnsfw\b", r"\bmilf\b",
    r"\bfetish\w*\b", r"\bnude\w*\b", r"\bnaked\b", r"\bhentai\b",
    r"\bcamgirl\w*\b", r"\bonlyfans\b", r"\bplayboy\b", r"\bxvideos\b",
    r"\bpornhub\b", r"\bredtube\b", r"\bxnxx\b", r"\bwebcam\w*\b",
    r"\blivejasmin\b", r"\bchaturbate\b", r"\bstripchat\b", r"\bbongacams\b",
    r"\burdolls\b", r"\bdildo\w*\b", r"\bvibrator\w*\b", r"\borgasm\w*\b",
    r"\bmasturbat\w*\b", r"\berotic\w*\b", r"\bbrazzers\b", r"\bxhamster\b",
    r"\byouporn\b", r"\bcumshot\w*\b", r"\bgangbang\w*\b", r"\bbdsm\b",
    r"\bbondage\b", r"\bstriptease\b", r"\blapdance\w*\b", r"\bcamsoda\b",
    r"\bmyfreecams\b", r"\bsugar\s+daddy\b", r"\bbrothel\w*\b",
    r"\bprostitut\w*\b", r"\bblowjob\w*\b", r"\bthreesome\w*\b",
    r"\bswinger\w*\b",
]

PATTERN = re.compile("|".join(INDICATORS), re.IGNORECASE)


def load_jsonl(path):
    rows = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    rows.append(json.loads(line))
    except FileNotFoundError:
        print(f"  (not found, skipping: {path})")
    return rows


def load_all(paths):
    all_docs = []
    for path in paths:
        docs = load_jsonl(path)
        print(f"  loaded {len(docs)} docs from {path}")
        all_docs.extend(docs)
    return all_docs


def scan(all_docs, exclude_domains):
    """Returns {domain: [(doc, match), ...]} for every flagged document."""
    domain_flagged = defaultdict(list)
    for doc in all_docs:
        domain = doc.get("domain", "")
        if domain in exclude_domains:
            continue
        text = doc.get("text", "")
        m = PATTERN.search(text) or PATTERN.search(domain)
        if m:
            domain_flagged[domain].append((doc, m))
    return domain_flagged


def print_candidates(domain_flagged, domain_counts, top_n, context_chars=45):
    ranked = sorted(domain_flagged.keys(), key=lambda d: -domain_counts[d])
    print(f"\n{len(domain_flagged)} candidate domains flagged. "
          f"Showing top {min(top_n, len(ranked))} by total document count:\n")
    print(f"{'Domain':38s} {'Flagged/Total':>15s}  Match context")
    print("-" * 100)
    for domain in ranked[:top_n]:
        doc, m = domain_flagged[domain][0]
        text = doc.get("text", "")
        text_match = PATTERN.search(text)
        if text_match:
            start = max(0, text_match.start() - context_chars)
            context = text[start:text_match.end() + context_chars].replace("\n", " ")
            kw = text_match.group()
        else:
            context = "(matched domain name)"
            kw = PATTERN.search(domain).group()
        n_flagged = len(domain_flagged[domain])
        total = domain_counts[domain]
        print(f"{domain:38s} {f'{n_flagged}/{total}':>15s}  '{kw}': ...{context}...")

    print("\nREMEMBER: this is a candidate list, not a verdict. Manually check")
    print("each domain's actual content before adding anything to a blocklist -")
    print("false positives from journalism, advocacy content, technical jargon,")
    print("and place names are common (see module docstring).")


def inspect_domain(all_docs, domain, full, sample):
    matches = [d for d in all_docs if d.get("domain") == domain]
    print(f"\n{domain}: {len(matches)} total documents\n")
    for doc in matches[:sample]:
        text = doc.get("text", "")
        print(f"--- url: {doc.get('url', '?')} ---")
        print(text if full else text[:300].replace("\n", " "))
        print()


def main():
    parser = argparse.ArgumentParser(description="Scan for adult-content domain candidates")
    parser.add_argument("--files", nargs="+",
                         default=["LAPT_data/fineweb2_lapt_pool.jsonl", "LAPT_data/fineweb2_reserved_pool.jsonl"])
    parser.add_argument("--exclude", nargs="*", default=[],
                         help="Domains already reviewed/blocklisted - skip re-flagging these")
    parser.add_argument("--top", type=int, default=50, help="How many top candidates to display")
    parser.add_argument("--domain", help="Inspect one specific domain's documents instead of scanning")
    parser.add_argument("--sample", type=int, default=3, help="Docs to show per domain (--domain mode)")
    parser.add_argument("--full", action="store_true", help="Show full text instead of a preview")
    args = parser.parse_args()

    print("Loading files...")
    all_docs = load_all(args.files)
    print(f"Total documents loaded: {len(all_docs)}")

    if args.domain:
        inspect_domain(all_docs, args.domain, args.full, args.sample)
        return

    domain_counts = Counter(d.get("domain") for d in all_docs)
    domain_flagged = scan(all_docs, set(args.exclude))
    print_candidates(domain_flagged, domain_counts, args.top)


if __name__ == "__main__":
    main()
