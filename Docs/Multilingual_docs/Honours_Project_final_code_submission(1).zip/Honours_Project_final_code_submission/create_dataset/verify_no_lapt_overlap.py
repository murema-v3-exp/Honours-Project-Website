"""
Verify no overlap between LAPT pool and generated pairs.

Usage:
    python verify_no_lapt_overlap.py \\
        --lapt LAPT_data/fineweb2_lapt_pool_final.jsonl \\
        --paired LAPT_data/xho_paired.jsonl LAPT_data/zul_paired.jsonl
"""

import argparse
import json


def load_jsonl(path):
    rows = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    rows.append(json.loads(line))
    except FileNotFoundError:
        print(f"  ERROR: file not found: {path}")
        return None
    return rows


def main():
    parser = argparse.ArgumentParser(description="Verify no LAPT/generated-pairs overlap")
    parser.add_argument("--lapt", default="LAPT_data/fineweb2_lapt_pool_final.jsonl",
                         help="LAPT pool file to check (default: the output of return_unused_to_lapt.py)")
    parser.add_argument("--paired", nargs="+",
                         default=["LAPT_data/xho_paired.jsonl", "LAPT_data/zul_paired.jsonl"],
                         help="Generated paired dataset file(s)")
    args = parser.parse_args()

    print(f"Loading LAPT pool: {args.lapt}")
    lapt = load_jsonl(args.lapt)
    if lapt is None:
        return
    print(f"  {len(lapt)} documents")

    # Build seed_id-equivalent keys, matching the format used elsewhere:
    # f"{language}_{id}"
    lapt_ids = set()
    lapt_urls = set()
    missing_fields = 0
    for doc in lapt:
        lang = doc.get("language")
        native_id = doc.get("id")
        if lang is None or native_id is None:
            missing_fields += 1
            continue
        lapt_ids.add(f"{lang}_{native_id}")
        if doc.get("url"):
            lapt_urls.add(doc["url"])

    if missing_fields:
        print(f"  WARNING: {missing_fields} LAPT docs missing language/id fields - "
              f"can't be checked by id, only by URL if present")

    print(f"\nLoading paired files: {args.paired}")
    all_paired = []
    for path in args.paired:
        rows = load_jsonl(path)
        if rows is None:
            return
        print(f"  {path}: {len(rows)} records")
        all_paired.extend(rows)

    paired_seed_ids = set(r["seed_id"] for r in all_paired if "seed_id" in r)
    paired_urls = set(r["url"] for r in all_paired if "url" in r)

    print(f"\nTotal unique seed_ids across paired files: {len(paired_seed_ids)}")

    # Check 1 (primary): by seed_id/id.
    id_overlap = lapt_ids & paired_seed_ids
    print(f"\n=== Check 1: overlap by (language, id) / seed_id ===")
    print(f"Overlapping documents: {len(id_overlap)}")
    if id_overlap:
        print("  THIS IS A LEAKAGE PROBLEM. Example overlapping ids:")
        for sid in list(id_overlap)[:10]:
            print(f"    {sid}")

    # Check 2 : by URL
    # catches the same document appearing under a different id
    url_overlap = lapt_urls & paired_urls
    print(f"\n=== Check 2: overlap by URL (secondary check) ===")
    print(f"Overlapping documents: {len(url_overlap)}")
    if url_overlap:
        print("  THIS IS A LEAKAGE PROBLEM. Example overlapping URLs:")
        for url in list(url_overlap)[:10]:
            print(f"    {url}")

    print(f"\n{'='*60}")
    if not id_overlap and not url_overlap:
        print("PASS: no overlap found between LAPT pool and generated pairs.")
    else:
        print("FAIL: overlap detected - see above. LAPT and the generated")
        print("dataset are NOT disjoint, which risks memorization-based")
        print("leakage between pretraining and classifier evaluation.")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
