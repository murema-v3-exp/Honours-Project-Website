"""
Scans this project's text documents for occurrences of the connective/
subordinating-conjunction word list, and separately counts infinitive verb
forms (the uku- prefix pattern), excluding words already confirmed as
connectives.

Connective feature is split into two, not blended. This project's own TF-IDF
output showed 'ukuba', 'ukuthi', and 'ngoba' are strongly Machine-leaning
(ukuba was the single highest-magnitude machine feature, +14.09), while
most other lexicon connectives are Human-leaning. A single blended count
averages these opposite effects and can hide the true direction.

Only the three words with confirmed TF-IDF evidence (ukuba, ukuthi, ngoba)
are split into their own feature; every other lexicon connective goes into
a second, undirected feature.

OUTPUTS:
  linguistic_marker_features.csv -- one row per scanned document, with raw
  and length-normalised counts for the two connective features and
  infinitives. Feeds directly into the diagnostic classifier.

Usage:
    python build_linguistic_marker_features.py \
        --lexicon lexicon.json \
        --input-files train.jsonl val.jsonl test.jsonl \
        --output-features linguistic_marker_features.csv
"""

import argparse
import csv
import json
import re

# Confirmed machine-leaning via TF-IDF coefficients: ukuba (+14.09,
# highest-magnitude machine feature overall), ukuthi (+6.67), ngoba
# (+5.16). Split out rather than averaged in with human-leaning connectives.
CONFIRMED_MACHINE_LEANING_CONNECTIVES = {"ukuba", "ukuthi", "ngoba"}


def tokenize(text):
    text = text.lower()
    tokens = text.split()
    return [re.sub(r"^[^\w]+|[^\w]+$", "", t) for t in tokens]


def count_features(text, connectives, uku_exclude):
    tokens = tokenize(text)
    if not tokens:
        return 0, 0, 0, 0
    n_words = len(tokens)
    machine_leaning_count = sum(1 for t in tokens if t in CONFIRMED_MACHINE_LEANING_CONNECTIVES and t in connectives)
    other_connective_count = sum(1 for t in tokens
                                  if t in connectives and t not in CONFIRMED_MACHINE_LEANING_CONNECTIVES)
    infinitive_count = sum(1 for t in tokens
                            if t.startswith("uku") and t not in uku_exclude)
    return n_words, machine_leaning_count, other_connective_count, infinitive_count


def load_jsonl(path):
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--lexicon", default="lexicon.json",
                     help="Output of extract_conjunctions_from_pos_corpus.py -- run that script first")
    ap.add_argument("--input-files", nargs="+", required=True,
                     help="One or more JSONL files to scan (e.g. train.jsonl val.jsonl test.jsonl)")
    ap.add_argument("--output-features", default="linguistic_marker_features.csv")
    ap.add_argument("--language-field", default="lang")
    ap.add_argument("--label-field", default="label")
    ap.add_argument("--seed-id-field", default="seed_id")
    args = ap.parse_args()

    with open(args.lexicon, encoding="utf-8") as f:
        lexicon = json.load(f)

    if "isiXhosa" not in lexicon or "isiZulu" not in lexicon:
        print("ERROR: lexicon.json is missing an isiXhosa or isiZulu entry -- "
              "was extract_conjunctions_from_pos_corpus.py run with both "
              "--xhosa-files and --zulu-files?")
        return

    xhosa_connectives = set(lexicon["isiXhosa"]["connectives"].keys())
    xhosa_uku_exclude = set(lexicon["isiXhosa"]["uku_prefixed_connectives_excluded_from_infinitive_count"])
    zulu_connectives = set(lexicon["isiZulu"]["connectives"].keys())
    zulu_uku_exclude = set(lexicon["isiZulu"]["uku_prefixed_connectives_excluded_from_infinitive_count"])

    print(f"Loaded lexicon from {args.lexicon} (source: {lexicon.get('source', 'unknown')})")
    print(f"  isiXhosa: {len(xhosa_connectives)} connectives, {len(xhosa_uku_exclude)} uku-prefixed excluded")
    print(f"  isiZulu : {len(zulu_connectives)} connectives, {len(zulu_uku_exclude)} uku-prefixed excluded")
    xhosa_ml = xhosa_connectives & CONFIRMED_MACHINE_LEANING_CONNECTIVES
    zulu_ml = zulu_connectives & CONFIRMED_MACHINE_LEANING_CONNECTIVES
    print(f"  Confirmed machine-leaning connectives present -- isiXhosa: {sorted(xhosa_ml)}, isiZulu: {sorted(zulu_ml)}\n")

    feature_rows = []
    lang_doc_counts = {}
    for path in args.input_files:
        rows = load_jsonl(path)
        print(f"Scanning {len(rows)} documents from {path}...")
        for r in rows:
            lang_raw = r.get(args.language_field, "unknown")
            lang = "isiXhosa" if str(lang_raw).lower().startswith("xho") else \
                   "isiZulu" if str(lang_raw).lower().startswith("zul") else None
            if lang is None:
                continue  # skip anything not clearly xho/zul

            connectives = xhosa_connectives if lang == "isiXhosa" else zulu_connectives
            uku_exclude = xhosa_uku_exclude if lang == "isiXhosa" else zulu_uku_exclude

            text = r.get("text", "")
            n_words, ml_count, other_count, inf_count = count_features(text, connectives, uku_exclude)

            feature_rows.append({
                "seed_id": r.get(args.seed_id_field, ""),
                "language": lang,
                "label": r.get(args.label_field, ""),
                "source_file": path,
                "n_words": n_words,
                "machine_leaning_connective_count": ml_count,
                "other_connective_count": other_count,
                "infinitive_count": inf_count,
                "machine_leaning_connective_rate_per_100_words": (100 * ml_count / n_words) if n_words else 0,
                "other_connective_rate_per_100_words": (100 * other_count / n_words) if n_words else 0,
                "infinitive_rate_per_100_words": (100 * inf_count / n_words) if n_words else 0,
            })
            lang_doc_counts[lang] = lang_doc_counts.get(lang, 0) + 1

    fieldnames = ["seed_id", "language", "label", "source_file", "n_words",
                  "machine_leaning_connective_count", "other_connective_count", "infinitive_count",
                  "machine_leaning_connective_rate_per_100_words", "other_connective_rate_per_100_words",
                  "infinitive_rate_per_100_words"]
    with open(args.output_features, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(feature_rows)

    print(f"\nSaved feature table: {args.output_features}")
    print(f"Total documents scanned: {len(feature_rows)}")
    for lang, count in lang_doc_counts.items():
        print(f"  {lang}: {count}")

    # Mean rates by label, to check each feature's actual direction
    # (no direction assumed) before building the classifier.
    print("\n=== Sanity check: mean rates by label ===")
    by_label = {}
    for row in feature_rows:
        by_label.setdefault(row["label"], []).append(row)
    for label, rows in by_label.items():
        avg_ml = sum(r["machine_leaning_connective_rate_per_100_words"] for r in rows) / len(rows)
        avg_other = sum(r["other_connective_rate_per_100_words"] for r in rows) / len(rows)
        avg_inf = sum(r["infinitive_rate_per_100_words"] for r in rows) / len(rows)
        print(f"  {label} (n={len(rows)}): "
              f"machine-leaning connectives = {avg_ml:.3f} per 100 words, "
              f"other connectives = {avg_other:.3f} per 100 words, "
              f"infinitives = {avg_inf:.3f} per 100 words")


if __name__ == "__main__":
    main()
