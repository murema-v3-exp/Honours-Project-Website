"""
Builds a distribution-matched test subset for the linguistic-marker
confound check on the transformer and TF-IDF classifiers.

Method: bins Test-set documents by the Fitted Diagnostic Classifier's
predicted probability, used as a single combined score.
Within each bin, subsamples human and machine documents
independently so both classes have the same count per bin.

Important: unlike the length and repetition confound checks, this does
not preserve human/machine pairs. A human document and its paired machine
counterpart can have very different marker rates by design,
so matching the two classes' score
distributions means treating them as independent pools.

OUTPUTS:
  1. A matched-subset JSONL, same schema as the input test file -- just
     point --test-file at it for re-evaluation, no other changes needed.
  2. A console/CSV report of the score distribution before/after matching,
     to confirm matching actually equalised the two classes.

Usage:
    python build_linguistic_marker_matched_subset.py \
        --features-file linguistic_marker_features.csv \
        --diagnostic-result linguistic_marker_diagnostic_result.json \
        --original-test-file test.jsonl \
        --n-bins 10 \
        --output-subset linguistic_marker_matched_test.jsonl \
        --output-report linguistic_marker_matching_report.csv
"""

import argparse
import csv
import json
import math
import random
from collections import defaultdict

FEATURE_COLUMNS = [
    "machine_leaning_connective_rate_per_100_words",
    "other_connective_rate_per_100_words",
    "infinitive_rate_per_100_words",
]


def sigmoid(x):
    return 1 / (1 + math.exp(-x))


def load_features(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def load_jsonl(path):
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--features-file", default="linguistic_marker_features.csv")
    ap.add_argument("--diagnostic-result", default="linguistic_marker_diagnostic_result.json",
                     help="Output of linguistic_marker_diagnostic_classifier.py, for the fitted coefficients")
    ap.add_argument("--original-test-file", required=True,
                     help="Original test.jsonl -- used to pull back full document text/fields for kept documents")
    ap.add_argument("--test-source", default="test.jsonl",
                     help="Value (or suffix match) of source_file identifying test rows in the features file")
    ap.add_argument("--n-bins", type=int, default=10)
    ap.add_argument("--seed", type=int, default=42, help="Random seed for reproducible subsampling")
    ap.add_argument("--seed-id-field", default="seed_id")
    ap.add_argument("--label-field", default="label")
    ap.add_argument("--output-subset", default="linguistic_marker_matched_test.jsonl")
    ap.add_argument("--output-report", default="linguistic_marker_matching_report.csv")
    args = ap.parse_args()

    random.seed(args.seed)

    with open(args.diagnostic_result) as f:
        diag = json.load(f)
    coefs = diag["coefficients"]
    intercept = diag["intercept"]
    print(f"Loaded fitted coefficients from {args.diagnostic_result}:")
    for name in FEATURE_COLUMNS:
        print(f"  {name}: {coefs[name]:+.4f}")
    print(f"  intercept: {intercept:+.4f}\n")

    feature_rows = load_features(args.features_file)
    test_rows = [r for r in feature_rows if r["source_file"].endswith(args.test_source)]
    if not test_rows:
        print(f"ERROR: no rows matched --test-source '{args.test_source}'. "
              f"Distinct source_file values present: {sorted(set(r['source_file'] for r in feature_rows))}")
        return
    print(f"Loaded {len(test_rows)} test-set document rows from {args.features_file}")

    # Combined score = predicted probability of "machine" from the fitted diagnostic classifier.
    for r in test_rows:
        z = intercept + sum(coefs[c] * float(r[c]) for c in FEATURE_COLUMNS)
        r["_score"] = sigmoid(z)

    scores = [r["_score"] for r in test_rows]
    bin_edges = [min(scores) + i * (max(scores) - min(scores)) / args.n_bins for i in range(args.n_bins + 1)]
    bin_edges[-1] += 1e-9  # ensure the max score falls inside the last bin

    def bin_index(score):
        for i in range(args.n_bins):
            if bin_edges[i] <= score < bin_edges[i + 1]:
                return i
        return args.n_bins - 1

    bins = defaultdict(lambda: {"human": [], "machine": []})
    for r in test_rows:
        b = bin_index(r["_score"])
        bins[b][r[args.label_field]].append(r)

    kept_rows = []
    report_rows = []
    for b in range(args.n_bins):
        human_docs = bins[b]["human"]
        machine_docs = bins[b]["machine"]
        n_keep = min(len(human_docs), len(machine_docs))
        random.shuffle(human_docs)
        random.shuffle(machine_docs)
        kept_human = human_docs[:n_keep]
        kept_machine = machine_docs[:n_keep]
        kept_rows.extend(kept_human)
        kept_rows.extend(kept_machine)
        report_rows.append({
            "bin": b, "score_range": f"[{bin_edges[b]:.3f}, {bin_edges[b+1]:.3f})",
            "human_available": len(human_docs), "machine_available": len(machine_docs),
            "kept_per_class": n_keep,
        })

    print("=== Matching report (per score bin) ===")
    for row in report_rows:
        print(f"  bin {row['bin']} {row['score_range']}: "
              f"human={row['human_available']}, machine={row['machine_available']} -> kept {row['kept_per_class']} each")

    with open(args.output_report, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["bin", "score_range", "human_available", "machine_available", "kept_per_class"])
        writer.writeheader()
        writer.writerows(report_rows)
    print(f"\nSaved matching report: {args.output_report}")

    n_human_kept = sum(1 for r in kept_rows if r[args.label_field] == "human")
    n_machine_kept = sum(1 for r in kept_rows if r[args.label_field] == "machine")
    print(f"\nTotal kept: {len(kept_rows)} ({n_human_kept} human, {n_machine_kept} machine)")
    print(f"Original test set: {len(test_rows)} documents "
          f"({sum(1 for r in test_rows if r[args.label_field]=='human')} human, "
          f"{sum(1 for r in test_rows if r[args.label_field]=='machine')} machine)")

    # Features CSV only stores counts, so pull the full text back from the original file.
    kept_keys = {(r[args.seed_id_field], r[args.label_field]) for r in kept_rows}
    original_rows = load_jsonl(args.original_test_file)
    matched_docs = [r for r in original_rows
                    if (r.get(args.seed_id_field), r.get(args.label_field)) in kept_keys]

    if len(matched_docs) != len(kept_rows):
        print(f"\nWARNING: matched {len(matched_docs)} documents from {args.original_test_file}, "
              f"expected {len(kept_rows)} -- check --seed-id-field/--label-field match the original "
              f"file's schema, and that {args.original_test_file} is the same test set the features "
              f"were computed from.")

    with open(args.output_subset, "w", encoding="utf-8") as f:
        for r in matched_docs:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"\nSaved matched subset: {args.output_subset} ({len(matched_docs)} documents, unpaired)")


if __name__ == "__main__":
    main()
