"""
Extracts connective/subordinating-conjunction word lists from the SADII
POS-annotated Nguni corpus, rather than hand-typing a word list, so the
result is reproducible and auditable from the source data.

Input Format: SADII_XX_Morph_Lemma_POS_*.txt, tab-separated with four
columns (Token, Morphological analysis, Lemma, POS), one token per line,
with "<LINE# NNNN>" marker lines between sentences/paragraphs.

Methos: keeps rows tagged POS == "CONJ" and counts lemma (not surface
token) frequency, so capitalised/inflected variants of the same word
(e.g. "Uma" vs "uma") merge correctly. A minimum-frequency threshold
excludes near-singleton tokens that may be annotation edge cases rather
than genuinely productive conjunctions.

Also flags words starting with the uku- infinitive prefix: several
grammaticalised conjunctions (ukuba, ukuze, ukuthi) derive from uku- +
verb stem, and this flag is used downstream to exclude them from the
infinitive-verb count so the two features don't overlap.

Usage:
    python extract_conjunctions_from_pos_corpus.py \
        --xhosa-files SADII_XH_..._TRAIN....txt SADII_XH_..._TEST....txt \
        --zulu-files SADII_ZU_..._TRAIN....txt SADII_ZU_..._TEST....txt \
        --min-frequency 3 \
        --output lexicon.json \
        --output-csv lexicon.csv
"""

import argparse
import csv
import json
from collections import Counter

SOURCE_NAME = "SADII POS-annotated Nguni corpus"


def extract_conj_lemmas(paths):
    """Returns a Counter of lowercased CONJ-tagged lemmas across the given
    files, plus the total token count (for reporting the CONJ rate)."""
    lemma_counter = Counter()
    total_tokens = 0
    for path in paths:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.rstrip("\n")
                if not line or line.startswith("<LINE#"):
                    continue
                parts = line.split("\t")
                if len(parts) != 4:
                    continue  # skip malformed/unexpected lines rather than crashing
                token, morph, lemma, pos = parts
                total_tokens += 1
                if pos == "CONJ":
                    lemma_counter[lemma.lower()] += 1
    return lemma_counter, total_tokens


def build_language_entry(paths, min_frequency, label):
    if not paths:
        print(f"No files provided for {label} -- skipping.")
        return None

    lemma_counter, total_tokens = extract_conj_lemmas(paths)
    n_conj_total = sum(lemma_counter.values())
    kept = {w: c for w, c in lemma_counter.most_common() if c >= min_frequency}
    dropped = {w: c for w, c in lemma_counter.most_common() if c < min_frequency}
    uku_prefixed = sorted(w for w in kept if w.startswith("uku"))

    print(f"=== {label} ===")
    print(f"Files: {paths}")
    print(f"Total annotated tokens scanned: {total_tokens}")
    print(f"Total CONJ-tagged tokens: {n_conj_total} ({100 * n_conj_total / total_tokens:.2f}%)")
    print(f"Unique CONJ lemmas found: {len(lemma_counter)}")
    print(f"Kept (>= {min_frequency} occurrences): {len(kept)} words")
    print(f"Dropped (< {min_frequency} occurrences, likely near-singletons): {len(dropped)} words -- {sorted(dropped)}")
    print(f"uku--prefixed connectives (exclude from any separate infinitive count): {uku_prefixed}")
    print()

    return {
        "connectives": kept,
        "dropped_below_threshold": dropped,
        "uku_prefixed_connectives_excluded_from_infinitive_count": uku_prefixed,
        "source_files_scanned": paths,
        "total_tokens_in_source": total_tokens,
        "total_conj_tagged_tokens_in_source": n_conj_total,
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--xhosa-files", nargs="+", default=[],
                     help="isiXhosa annotated POS file(s), e.g. TRAIN and TEST")
    ap.add_argument("--zulu-files", nargs="+", default=[],
                     help="isiZulu annotated POS file(s), e.g. TRAIN and TEST")
    ap.add_argument("--min-frequency", type=int, default=3,
                     help="Minimum lemma occurrence count to keep (default: 3)")
    ap.add_argument("--output", default="lexicon.json")
    ap.add_argument("--output-csv", default="lexicon.csv",
                     help="Flat, human-readable CSV of the final word list -- easy to eyeball "
                          "or paste directly into a paper table, unlike the nested JSON")
    args = ap.parse_args()

    lexicon = {
        "source": SOURCE_NAME,
        "extraction_note": f"CONJ-tagged lemmas, minimum {args.min_frequency} combined occurrences "
                            f"across all provided files, extracted mechanically from the annotated corpus.",
        "min_frequency_threshold": args.min_frequency,
    }

    xhosa_entry = build_language_entry(args.xhosa_files, args.min_frequency, "isiXhosa")
    if xhosa_entry:
        lexicon["isiXhosa"] = xhosa_entry

    zulu_entry = build_language_entry(args.zulu_files, args.min_frequency, "isiZulu")
    if zulu_entry:
        lexicon["isiZulu"] = zulu_entry

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(lexicon, f, indent=2, ensure_ascii=False)
    print(f"Saved: {args.output}")

    # Flat CSV: one row per kept word, easier to eyeball than the nested JSON.
    csv_rows = []
    for lang, entry in [("isiXhosa", xhosa_entry), ("isiZulu", zulu_entry)]:
        if entry is None:
            continue
        for word, count in sorted(entry["connectives"].items(), key=lambda x: -x[1]):
            csv_rows.append({
                "language": lang,
                "word": word,
                "corpus_frequency": count,
                "starts_with_uku_prefix": word in entry["uku_prefixed_connectives_excluded_from_infinitive_count"],
            })

    with open(args.output_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["language", "word", "corpus_frequency", "starts_with_uku_prefix"])
        writer.writeheader()
        writer.writerows(csv_rows)
    print(f"Saved: {args.output_csv} ({len(csv_rows)} words, source: {SOURCE_NAME})")


if __name__ == "__main__":
    main()
