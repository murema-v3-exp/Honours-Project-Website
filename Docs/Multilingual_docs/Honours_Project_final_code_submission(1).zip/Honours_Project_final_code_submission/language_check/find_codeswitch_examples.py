"""
Searches human-labeled examples in a JSONL test/corpus file for
code-switched English words and prints the matching documents (or a
snippet around the match), so the code-switching finding can be checked
against real text rather than just the isolated TF-IDF tokens.

Searches a configurable list of common English function words that showed
up as human-indicator features (e.g. 'the'), plus any --extra-words.

Usage:
    python find_codeswitch_examples.py \
        --test-file finetuning_data/test.jsonl \
        --max-examples 10 \
        --full-text
"""

import argparse
import json
import re

DEFAULT_ENGLISH_WORDS = ["the", "and", "is", "are", "was", "were", "this", "that"]


def load_jsonl(path):
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def find_word_matches(text, word):
    """Whole-word, case-insensitive match, returns list of (start, end) spans."""
    pattern = r"\b" + re.escape(word) + r"\b"
    return [m.span() for m in re.finditer(pattern, text, flags=re.IGNORECASE)]


def snippet_around(text, start, end, context_chars=60):
    s = max(0, start - context_chars)
    e = min(len(text), end + context_chars)
    prefix = "..." if s > 0 else ""
    suffix = "..." if e < len(text) else ""
    return f"{prefix}{text[s:e]}{suffix}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--test-file", required=True)
    ap.add_argument("--label-field", default="label")
    ap.add_argument("--human-label-value", default="human")
    ap.add_argument("--language-field", default="lang")
    ap.add_argument("--words", nargs="+", default=DEFAULT_ENGLISH_WORDS,
                     help="English words to search for (default: common function words)")
    ap.add_argument("--extra-words", nargs="+", default=[],
                     help="Additional words to add to the search list")
    ap.add_argument("--max-examples", type=int, default=10,
                     help="Max total examples to print (across all words)")
    ap.add_argument("--full-text", action="store_true",
                     help="Print the entire document text instead of a snippet")
    args = ap.parse_args()

    words = args.words + args.extra_words
    rows = load_jsonl(args.test_file)
    human_rows = [r for r in rows if r.get(args.label_field) == args.human_label_value]
    print(f"Loaded {len(rows)} total examples, {len(human_rows)} human-labeled\n")
    print(f"Searching for: {words}\n")

    printed = 0
    word_counts = {w: 0 for w in words}

    for r in human_rows:
        text = r.get("text", "")
        lang = r.get(args.language_field, "unknown")
        for word in words:
            matches = find_word_matches(text, word)
            if matches:
                word_counts[word] += 1
                if printed < args.max_examples:
                    start, end = matches[0]
                    print(f"--- Match: '{word}' | language: {lang} | seed_id: {r.get('seed_id', '?')} ---")
                    if args.full_text:
                        print(text)
                    else:
                        print(snippet_around(text, start, end))
                    print()
                    printed += 1

    print("=== Summary: number of human documents containing each word ===")
    for word, count in sorted(word_counts.items(), key=lambda x: -x[1]):
        pct = 100 * count / len(human_rows) if human_rows else 0
        print(f"  '{word}': {count} documents ({pct:.2f}% of human-labeled examples)")


if __name__ == "__main__":
    main()