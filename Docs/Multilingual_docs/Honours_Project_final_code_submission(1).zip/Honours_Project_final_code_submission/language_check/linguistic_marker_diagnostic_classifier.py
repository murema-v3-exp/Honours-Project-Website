"""
Diagnostic classifier trained on the three linguistic-marker rate
features from build_linguistic_marker_features.py. no raw text, TF-IDF,
or transformer embeddings.

one classifier but Three features:
  - machine_leaning_connective_rate_per_100_words (ukuba, ukuthi, ngoba)
  - other_connective_rate_per_100_words (rest of the lexicon)
  - infinitive_rate_per_100_words

Uses rate-normalised columns, not raw counts, to avoid reintroducing the
length confound the project's own length-confound check found in raw
counts.

Splits by the existing source_file column rather than re-splitting
randomly, so this evaluates on the same test set as the rest of the
project and stays comparable to the other diagnostics.

Usage:
    python linguistic_marker_diagnostic_classifier.py \
        --features-file linguistic_marker_features.csv \
        --train-source train.jsonl \
        --test-source test.jsonl \
        --output-json linguistic_marker_diagnostic_result.json
"""

import argparse
import csv
import json

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, confusion_matrix, precision_recall_fscore_support,
                              roc_auc_score)

FEATURE_COLUMNS = [
    "machine_leaning_connective_rate_per_100_words",
    "other_connective_rate_per_100_words",
    "infinitive_rate_per_100_words",
]

LABEL2ID = {"human": 0, "machine": 1}


def load_features(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def build_xy(rows):
    X = np.array([[float(r[c]) for c in FEATURE_COLUMNS] for r in rows])
    y = np.array([LABEL2ID[r["label"]] for r in rows])
    return X, y


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--features-file", default="linguistic_marker_features.csv")
    ap.add_argument("--train-source", default="train.jsonl",
                     help="Value (or suffix match) of source_file identifying training rows")
    ap.add_argument("--test-source", default="test.jsonl",
                     help="Value (or suffix match) of source_file identifying test rows")
    ap.add_argument("--output-json", default="linguistic_marker_diagnostic_result.json")
    args = ap.parse_args()

    rows = load_features(args.features_file)
    print(f"Loaded {len(rows)} document rows from {args.features_file}")

    train_rows = [r for r in rows if r["source_file"].endswith(args.train_source)]
    test_rows = [r for r in rows if r["source_file"].endswith(args.test_source)]

    if not train_rows or not test_rows:
        print(f"ERROR: found {len(train_rows)} train rows and {len(test_rows)} test rows -- "
              f"check --train-source/--test-source match your source_file values. "
              f"Distinct source_file values present: {sorted(set(r['source_file'] for r in rows))}")
        return

    print(f"Train rows: {len(train_rows)} | Test rows: {len(test_rows)}")

    X_train, y_train = build_xy(train_rows)
    X_test, y_test = build_xy(test_rows)

    clf = LogisticRegression()
    clf.fit(X_train, y_train)

    probs = clf.predict_proba(X_test)[:, 1]
    preds = (probs >= 0.5).astype(int)

    acc = accuracy_score(y_test, preds)
    p, r, f1, _ = precision_recall_fscore_support(y_test, preds, average="binary", pos_label=1)
    auc = roc_auc_score(y_test, probs)
    tn, fp, fn, tp = confusion_matrix(y_test, preds, labels=[0, 1]).ravel()

    print(f"\n=== Linguistic marker diagnostic classifier (test set, n={len(test_rows)}) ===")
    print(f"Accuracy : {acc:.4f}")
    print(f"Precision: {p:.4f}")
    print(f"Recall   : {r:.4f}")
    print(f"F1       : {f1:.4f}")
    print(f"ROC-AUC  : {auc:.4f}")
    print(f"Confusion matrix: tn={tn} fp={fp} fn={fn} tp={tp}")

    print(f"\n=== Fitted coefficients (positive = machine-associated) ===")
    for name, coef in zip(FEATURE_COLUMNS, clf.coef_[0]):
        print(f"  {name}: {coef:+.4f}")
    print(f"  intercept: {clf.intercept_[0]:+.4f}")

    result = {
        "features_used": FEATURE_COLUMNS,
        "n_train": len(train_rows),
        "n_test": len(test_rows),
        "test_metrics": {
            "accuracy": acc, "precision": p, "recall": r, "f1": f1, "roc_auc": auc,
            "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
        },
        "coefficients": {name: float(coef) for name, coef in zip(FEATURE_COLUMNS, clf.coef_[0])},
        "intercept": float(clf.intercept_[0]),
    }
    with open(args.output_json, "w") as f:
        json.dump(result, f, indent=2)
    print(f"\nSaved: {args.output_json}")


if __name__ == "__main__":
    main()
