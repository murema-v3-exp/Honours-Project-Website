"""
Bootstrap confidence intervals for accuracy and F1, at both default and
RAID-calibrated thresholds, for every run in results_classifier/ (and
optionally the TF-IDF baselines).

Method: nonparametric bootstrap (resample test examples with
replacement, recompute the metric, repeat n_boot times), percentile CI.
Reuses each run's own already-computed predictions and calibrated RAID
threshold rather than retraining/recalibrating, same as
evaluate_on_subset.py.

Usage:
    python bootstrap_ci.py --results-dir results_classifier --output bootstrap_ci.csv
    python bootstrap_ci.py --results-dir results_classifier --tfidf-dir results_tfidf --output bootstrap_ci.csv
"""

import argparse
import csv
import os

import numpy as np
from sklearn.metrics import f1_score


def bootstrap_metric(true_labels, preds, metric_fn, n_boot=2000, ci=0.95, seed=42):
    rng = np.random.default_rng(seed)
    n = len(true_labels)
    true_arr = np.array(true_labels)
    pred_arr = np.array(preds)
    point = metric_fn(true_arr, pred_arr)
    boot_vals = np.empty(n_boot)
    for i in range(n_boot):
        idx = rng.integers(0, n, n)
        boot_vals[i] = metric_fn(true_arr[idx], pred_arr[idx])
    lower = np.percentile(boot_vals, (1 - ci) / 2 * 100)
    upper = np.percentile(boot_vals, (1 + ci) / 2 * 100)
    return point, lower, upper


def accuracy_fn(y_true, y_pred):
    return (y_true == y_pred).mean()


def f1_fn(y_true, y_pred):
    return f1_score(y_true, y_pred, pos_label=1, zero_division=0)


def load_classifier_predictions(run_dir):
    path = os.path.join(run_dir, "test_predictions.csv")
    if not os.path.exists(path):
        return None
    true_labels, pred_default, pred_raid = [], [], []
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            true_labels.append(int(r["true_label"]))
            pred_default.append(int(r["pred_default_0.5"]))
            pred_raid.append(int(r["pred_raid_calibrated"]))
    return true_labels, pred_default, pred_raid


def load_tfidf_predictions(run_dir):
    # tfidf_baseline.py saves the same test_predictions.csv format.
    return load_classifier_predictions(run_dir)


def process_run(run_name, run_dir, loader, writer, n_boot, ci, seed):
    result = loader(run_dir)
    if result is None:
        print(f"SKIP {run_name}: no test_predictions.csv found")
        return
    true_labels, pred_default, pred_raid = result

    for threshold_name, preds in [("default", pred_default), ("raid_calibrated", pred_raid)]:
        for metric_name, metric_fn in [("accuracy", accuracy_fn), ("f1", f1_fn)]:
            point, lower, upper = bootstrap_metric(true_labels, preds, metric_fn, n_boot, ci, seed)
            writer.writerow({
                "run_name": run_name,
                "threshold": threshold_name,
                "metric": metric_name,
                "point_estimate": point,
                "ci_lower": lower,
                "ci_upper": upper,
                "ci_width": upper - lower,
                "n_boot": n_boot,
                "ci_level": ci,
                "n_examples": len(true_labels),
            })
    print(f"Done: {run_name}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results-dir", default="results_classifier")
    ap.add_argument("--tfidf-dir", default=None,
                     help="Optional -- e.g. results_tfidf, containing TFIDF_WordLevel_Baseline/ "
                          "and TFIDF_CharLevel_Baseline/ subfolders, IF those were updated to also "
                          "save test_predictions.csv (they are, per the earlier tfidf_baseline.py update).")
    ap.add_argument("--output", default="bootstrap_ci.csv")
    ap.add_argument("--n-boot", type=int, default=2000)
    ap.add_argument("--ci", type=float, default=0.95)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    fieldnames = ["run_name", "threshold", "metric", "point_estimate", "ci_lower",
                  "ci_upper", "ci_width", "n_boot", "ci_level", "n_examples"]

    with open(args.output, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

        if os.path.isdir(args.results_dir):
            for run_name in sorted(os.listdir(args.results_dir)):
                run_dir = os.path.join(args.results_dir, run_name)
                if os.path.isdir(run_dir):
                    process_run(run_name, run_dir, load_classifier_predictions,
                                writer, args.n_boot, args.ci, args.seed)

        if args.tfidf_dir and os.path.isdir(args.tfidf_dir):
            for run_name in sorted(os.listdir(args.tfidf_dir)):
                run_dir = os.path.join(args.tfidf_dir, run_name)
                if os.path.isdir(run_dir):
                    process_run(run_name, run_dir, load_tfidf_predictions,
                                writer, args.n_boot, args.ci, args.seed)

    print(f"\nSaved: {args.output}")


if __name__ == "__main__":
    main()
