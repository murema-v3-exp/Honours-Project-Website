"""
Builds a length-distribution-MATCHED subset of test.jsonl

Method: bin by word count, and within each bin, keep only
min(n_human_in_bin, n_machine_in_bin) examples of each class (randomly
subsampled from the more abundant one). This gives near-identical length
distributions for both classes, so a classifier relying on length alone
should now perform at chance, isolating whatever signal survives once
length is controlled for.

Usage:
    python build_length_matched_test.py --test-file test.jsonl --output length_matched_test.jsonl
"""

import argparse
import json
import random
from collections import defaultdict

import numpy as np


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--test-file", required=True)
    ap.add_argument("--output", default="length_matched_test.jsonl")
    ap.add_argument("--bin-width", type=int, default=3,
                     help="Word-count bin width. Smaller = tighter length "
                          "matching but fewer retained examples per bin; "
                          "larger = looser matching but more retained data. "
                          "3 is a reasonable start given the observed "
                          "distributions (human median=77, machine median=73, "
                          "machine max=93).")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    random.seed(args.seed)

    rows_by_label = defaultdict(list)
    with open(args.test_file, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            r = json.loads(line)
            r["_wordcount"] = len(r["text"].split())
            rows_by_label[r["label"]].append(r)

    print(f"Loaded: {len(rows_by_label['human'])} human, {len(rows_by_label['machine'])} machine")

    def bin_of(wc):
        return wc // args.bin_width

    binned = defaultdict(lambda: defaultdict(list))  # word-count bin -> label -> rows
    for label, rows in rows_by_label.items():
        for r in rows:
            binned[bin_of(r["_wordcount"])][label].append(r)

    matched = []
    for b, by_label in sorted(binned.items()):
        h = by_label.get("human", [])
        m = by_label.get("machine", [])
        n = min(len(h), len(m))
        if n == 0:
            continue
        matched.extend(random.sample(h, n))
        matched.extend(random.sample(m, n))

    random.shuffle(matched)

    print(f"\nMatched subset: {len(matched)} total "
          f"({sum(1 for r in matched if r['label']=='human')} human, "
          f"{sum(1 for r in matched if r['label']=='machine')} machine)")
    print(f"Retained {len(matched) / (len(rows_by_label['human']) + len(rows_by_label['machine'])) * 100:.1f}% "
          f"of the original test set")

    # Sanity check: word-count-alone accuracy on the matched subset should be near chance
    h_lens = np.array([r["_wordcount"] for r in matched if r["label"] == "human"])
    m_lens = np.array([r["_wordcount"] for r in matched if r["label"] == "machine"])
    print(f"\nMatched subset length stats:")
    print(f"  human:   median={np.median(h_lens):.0f} mean={h_lens.mean():.1f}")
    print(f"  machine: median={np.median(m_lens):.0f} mean={m_lens.mean():.1f}")

    best_acc = 0
    all_lens = np.concatenate([h_lens, m_lens])
    for t in np.unique(all_lens):
        acc = max(
            (h_lens > t).sum() + (m_lens <= t).sum(),
            (h_lens <= t).sum() + (m_lens > t).sum(),
        ) / len(all_lens)
        best_acc = max(best_acc, acc)
    print(f"\nBest possible accuracy from word-count ALONE on matched subset: {best_acc:.4f}")
    print("(compare to 0.6571 on the original full test set -- should be much closer to 0.50 now)")

    with open(args.output, "w", encoding="utf-8") as f:
        for r in matched:
            r.pop("_wordcount")
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"\nSaved: {args.output}")


if __name__ == "__main__":
    main()
