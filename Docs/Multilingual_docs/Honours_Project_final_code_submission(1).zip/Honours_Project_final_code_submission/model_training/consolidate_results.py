"""
Consolidates results from every finetuning run, all classifier configs
(results_classifier/*/metrics.json) and both TF-IDF baselines
(results_tfidf/*/baseline_config.json) into one flat CSV, the master
table for building results tables/graphs from.

Also auto-derives categorical columns from run names (backbone, LAPT
method, language scope, classifier method) for grouping/faceting.

Usage:
    python consolidate_results.py \
        --classifier-dir results_classifier \
        --tfidf-dir results_tfidf \
        --output all_results.csv
"""

import argparse
import csv
import json
import os


def derive_categories(run_name, is_tfidf=False, tfidf_variant=None):
    if is_tfidf:
        return {
            "backbone": f"TF-IDF-{tfidf_variant}",
            "lapt_status": "n/a",
            "lapt_language_scope": "n/a",
            "classifier_method": "n/a",
        }
    backbone = "mBERT" if run_name.startswith("mbert") else "XLM-R"
    if "no_lapt" in run_name:
        lapt_status = "no_lapt"
    elif "lora_lapt" in run_name:
        lapt_status = "lora_lapt"
    elif "full_lapt" in run_name:
        lapt_status = "full_lapt"
    else:
        lapt_status = "unknown"
    if "xhoonly" in run_name:
        scope = "xho_only"
    elif "zulonly" in run_name:
        scope = "zul_only"
    else:
        scope = "combined"
    if "clsfull" in run_name:
        cls_method = "full"
    elif "clslora" in run_name:
        cls_method = "lora"
    else:
        cls_method = "unknown"
    return {
        "backbone": backbone,
        "lapt_status": lapt_status,
        "lapt_language_scope": scope if lapt_status != "no_lapt" else "n/a",
        "classifier_method": cls_method,
    }


def process_classifier_run(run_name, run_dir):
    metrics_path = os.path.join(run_dir, "metrics.json")
    if not os.path.exists(metrics_path):
        return None
    with open(metrics_path) as f:
        m = json.load(f)

    row = {"run_name": run_name, **derive_categories(run_name)}
    row["lapt_checkpoint"] = m["config"].get("lapt_checkpoint")
    row["classifier_lora"] = m["config"].get("classifier_lora")
    row["n_trials_requested"] = m["config"].get("n_trials")
    row["max_epochs"] = m["config"].get("max_epochs")

    combined = m["test_results"]["combined"]
    row["accuracy"] = combined.get("eval_accuracy")
    row["precision"] = combined.get("eval_precision")
    row["recall"] = combined.get("eval_recall")
    row["f1"] = combined.get("eval_f1")
    row["roc_auc"] = combined.get("roc_auc")
    cm = combined.get("confusion_matrix", {})
    row["tn"] = cm.get("tn"); row["fp"] = cm.get("fp"); row["fn"] = cm.get("fn"); row["tp"] = cm.get("tp")

    for lang in ["xho", "zul"]:
        lang_metrics = m["test_results"].get(lang, {})
        row[f"{lang}_accuracy"] = lang_metrics.get("eval_accuracy")
        row[f"{lang}_f1"] = lang_metrics.get("eval_f1")

    raid = m.get("raid_style_evaluation", {})
    row["raid_threshold"] = raid.get("threshold")
    row["raid_threshold_unreachable"] = raid.get("threshold_unreachable")
    row["raid_accuracy"] = raid.get("test_accuracy_at_calibrated_threshold")
    row["raid_achieved_fpr"] = raid.get("test_achieved_fpr_at_threshold")

    res = m.get("resource_usage", {})
    row["wall_clock_hours"] = res.get("total_search_wall_clock_hours")
    row["n_trials_pruned"] = res.get("n_trials_pruned")
    row["peak_gpu_memory_gb"] = res.get("best_trial_peak_gpu_memory_gb")
    row["total_params"] = res.get("best_trial_total_params")
    row["trainable_params"] = res.get("best_trial_trainable_params")

    row["best_learning_rate"] = m.get("best_params", {}).get("learning_rate")
    row["best_weight_decay"] = m.get("best_params", {}).get("weight_decay")
    row["best_lora_r"] = m.get("best_params", {}).get("lora_r")
    return row


def process_tfidf_run(variant_name, run_dir):
    config_path = os.path.join(run_dir, "baseline_config.json")
    if not os.path.exists(config_path):
        return None
    with open(config_path) as f:
        c = json.load(f)

    tfidf_variant = "word" if "Word" in variant_name else "char"
    row = {"run_name": variant_name, **derive_categories(variant_name, is_tfidf=True, tfidf_variant=tfidf_variant)}

    results = c.get("results", {})
    row["accuracy"] = results.get("test_accuracy")
    row["f1"] = results.get("test_f1")
    row["roc_auc"] = results.get("roc_auc")
    cm = c.get("confusion_matrix", {})
    row["tn"] = cm.get("tn"); row["fp"] = cm.get("fp"); row["fn"] = cm.get("fn"); row["tp"] = cm.get("tp")

    raid = c.get("raid_style_evaluation", {})
    row["raid_threshold"] = raid.get("threshold")
    row["raid_threshold_unreachable"] = raid.get("threshold_unreachable")
    row["raid_accuracy"] = raid.get("test_accuracy_at_calibrated_threshold")
    row["raid_achieved_fpr"] = raid.get("test_achieved_fpr_at_threshold")

    res = c.get("resource_usage", {})
    row["wall_clock_hours"] = res.get("total_wall_clock_seconds", 0) / 3600 if res.get("total_wall_clock_seconds") else None

    # Per-language metrics live in a separate per_language_results.csv, not baseline_config.json.
    per_lang_path = os.path.join(run_dir, "per_language_results.csv")
    if os.path.exists(per_lang_path):
        with open(per_lang_path, newline="") as f:
            for r in csv.DictReader(f):
                lang = r["language"]
                if lang in ("xho", "zul"):
                    row[f"{lang}_accuracy"] = float(r["accuracy"])
                    row[f"{lang}_f1"] = float(r["f1"])

    best_params = c.get("search", {}).get("best_params", {})
    row["best_C"] = best_params.get("clf__C")
    return row


FIELDNAMES = [
    "run_name", "backbone", "lapt_status", "lapt_language_scope", "classifier_method",
    "lapt_checkpoint", "classifier_lora",
    "accuracy", "precision", "recall", "f1", "roc_auc",
    "tn", "fp", "fn", "tp",
    "xho_accuracy", "xho_f1", "zul_accuracy", "zul_f1",
    "raid_threshold", "raid_threshold_unreachable", "raid_accuracy", "raid_achieved_fpr",
    "wall_clock_hours", "n_trials_pruned", "peak_gpu_memory_gb", "total_params", "trainable_params",
    "n_trials_requested", "max_epochs",
    "best_learning_rate", "best_weight_decay", "best_lora_r", "best_C",
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--classifier-dir", default="results_classifier")
    ap.add_argument("--tfidf-dir", default=None)
    ap.add_argument("--output", default="all_results.csv")
    args = ap.parse_args()

    rows = []
    n_missing = 0

    if os.path.isdir(args.classifier_dir):
        for run_name in sorted(os.listdir(args.classifier_dir)):
            run_dir = os.path.join(args.classifier_dir, run_name)
            if not os.path.isdir(run_dir):
                continue
            row = process_classifier_run(run_name, run_dir)
            if row is None:
                print(f"SKIP {run_name}: no metrics.json found (run not finished yet?)")
                n_missing += 1
                continue
            rows.append(row)
            print(f"OK: {run_name}")

    if args.tfidf_dir and os.path.isdir(args.tfidf_dir):
        for variant_name in sorted(os.listdir(args.tfidf_dir)):
            run_dir = os.path.join(args.tfidf_dir, variant_name)
            if not os.path.isdir(run_dir):
                continue
            row = process_tfidf_run(variant_name, run_dir)
            if row is None:
                print(f"SKIP {variant_name}: no baseline_config.json found")
                n_missing += 1
                continue
            rows.append(row)
            print(f"OK: {variant_name}")

    with open(args.output, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k, "") for k in FIELDNAMES})

    print(f"\nConsolidated {len(rows)} runs into {args.output} ({n_missing} skipped/missing)")


if __name__ == "__main__":
    main()
