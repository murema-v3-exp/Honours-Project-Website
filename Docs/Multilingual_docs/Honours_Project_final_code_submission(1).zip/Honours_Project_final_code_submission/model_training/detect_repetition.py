"""
Repetition detector for the length/punctuation confound-check family.
The original detector only caught a phrase repeating 3+ times
consecutively, missing repeats spaced out elsewhere in the document.
This version counts n-gram frequency across the whole document instead,
catching repeats regardless of spacing.

Method: for each machine-generated test example, extract all n-grams of
length --ngram-size (default 5 words), count occurrences, and flag the
document if any single n-gram appears --min-repeats or more times.

Scope: only the machine-generated side is scanned (the repetition bug is
specific to generation). A flagged machine example excludes its whole
pair (matched by seed_id), not just the flagged side, to keep the paired
test-set structure intact.

OUTPUTS:
  1. A filtered .jsonl test file (repetition-matched subset), same format
     as the input, ready for evaluate_on_subset.py / run_all_length_matched_evals.py.
  2. A per-document CSV report (repetition_scan_report.csv): whether each
     scanned example was flagged, the worst-offending n-gram and its
     count, and its language.
  3. Console summary: total scanned, flagged, kept, per-language breakdown.

Usage:
    python detect_repetition.py \
        --test-file test.jsonl \
        --output-subset repetition_matched_test.jsonl \
        --output-report repetition_scan_report.csv
"""

import argparse
import csv
import json
import re
from collections import Counter


def load_jsonl(path):
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def tokenize(text):
    """Lowercase, whitespace-split, strip surrounding punctuation per
    token. only used internally for n-gram matching,
    not linguistic analysis."""
    text = text.lower()
    tokens = text.split()
    tokens = [re.sub(r"^[^\w]+|[^\w]+$", "", t) for t in tokens]
    return [t for t in tokens if t]


def find_worst_repeat(text, ngram_size, min_repeats):
    """Returns (flagged, worst_ngram, worst_count) for the most-repeated
    n-gram of the given size in this document."""
    tokens = tokenize(text)
    if len(tokens) < ngram_size:
        return False, None, 0

    ngram_counts = Counter()
    for i in range(len(tokens) - ngram_size + 1):
        ngram = " ".join(tokens[i:i + ngram_size])
        ngram_counts[ngram] += 1

    if not ngram_counts:
        return False, None, 0

    worst_ngram, worst_count = ngram_counts.most_common(1)[0]
    flagged = worst_count >= min_repeats
    return flagged, worst_ngram, worst_count


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--test-file", required=True, help="Original test.jsonl (human + machine examples)")
    ap.add_argument("--output-subset", default="repetition_matched_test.jsonl",
                     help="Filtered subset with flagged pairs excluded, same format as input")
    ap.add_argument("--output-report", default="repetition_scan_report.csv",
                     help="Per-document scan report for every machine-generated example")
    ap.add_argument("--ngram-size", type=int, default=5, help="N-gram length in words (default: 5)")
    ap.add_argument("--min-repeats", type=int, default=3,
                     help="Minimum occurrences of an n-gram to flag the document (default: 3)")
    ap.add_argument("--seed-id-field", default="seed_id", help="Field name linking human/machine pairs")
    ap.add_argument("--label-field", default="label", help="Field name for human/machine label")
    ap.add_argument("--machine-label-value", default="machine", help="Value in label field marking machine-generated text")
    ap.add_argument("--language-field", default="lang", help="Field name for language")
    args = ap.parse_args()

    rows = load_jsonl(args.test_file)
    print(f"Loaded {len(rows)} examples from {args.test_file}")

    flagged_seed_ids = set()
    report_rows = []
    lang_scanned = Counter()
    lang_flagged = Counter()

    for r in rows:
        if r.get(args.label_field) != args.machine_label_value:
            continue  # only scan the machine-generated side

        seed_id = r.get(args.seed_id_field)
        lang = r.get(args.language_field, "unknown")
        text = r.get("text", "")

        flagged, worst_ngram, worst_count = find_worst_repeat(text, args.ngram_size, args.min_repeats)

        lang_scanned[lang] += 1
        if flagged:
            lang_flagged[lang] += 1
            flagged_seed_ids.add(seed_id)

        report_rows.append({
            "seed_id": seed_id,
            "language": lang,
            "flagged": flagged,
            "worst_ngram": worst_ngram or "",
            "worst_ngram_count": worst_count,
            "ngram_size_used": args.ngram_size,
        })

    # Write per-document report
    with open(args.output_report, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["seed_id", "language", "flagged", "worst_ngram",
                                                 "worst_ngram_count", "ngram_size_used"])
        writer.writeheader()
        writer.writerows(report_rows)
    print(f"Saved per-document scan report: {args.output_report}")

    # Exclude whole pairs (both human and machine rows sharing a flagged seed_id).
    kept_rows = [r for r in rows if r.get(args.seed_id_field) not in flagged_seed_ids]
    with open(args.output_subset, "w", encoding="utf-8") as f:
        for r in kept_rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"Saved filtered subset: {args.output_subset}")

    total_pairs_scanned = sum(lang_scanned.values())
    total_pairs_flagged = len(flagged_seed_ids)
    total_pairs_kept = total_pairs_scanned - total_pairs_flagged

    print(f"\n=== Summary ===")
    print(f"Machine-generated examples scanned : {total_pairs_scanned}")
    print(f"Flagged (repetition detected)      : {total_pairs_flagged} "
          f"({100 * total_pairs_flagged / total_pairs_scanned:.2f}%)" if total_pairs_scanned else "")
    print(f"Pairs kept in filtered subset       : {total_pairs_kept}")
    print(f"Total rows in filtered subset file  : {len(kept_rows)} (both human + machine sides of kept pairs)")
    print(f"\nPer-language breakdown:")
    for lang in sorted(lang_scanned):
        scanned = lang_scanned[lang]
        flagged = lang_flagged[lang]
        kept = scanned - flagged
        pct = 100 * flagged / scanned if scanned else 0
        print(f"  {lang}: {scanned} scanned, {flagged} flagged ({pct:.2f}%), {kept} kept")


if __name__ == "__main__":
    main()
