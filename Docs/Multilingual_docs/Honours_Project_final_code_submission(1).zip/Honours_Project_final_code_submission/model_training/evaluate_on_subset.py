"""
Evaluates an already-trained classifier checkpoint (from
finetune_classifier_bohb.py's final/ output) against a given test file.
used to compare full-test-set accuracy against length-matched-subset
accuracy, using the same trained model and decision threshold both times.

Does not recalibrate the RAID threshold on this subset
determines how the model as Deployed performs once the
confound is removed. Pass --raid-threshold with the value from the
original run's metrics.json (raid_style_evaluation.threshold).

Usage:
    # No-LAPT, full fine-tune:
    python evaluate_on_subset.py --model bert-base-multilingual-cased \
        --final-model-dir results_classifier/mbert_no_lapt_clsfull/final \
        --test-file length_matched_test.jsonl \
        --raid-threshold <value from that run's metrics.json>

    # LAPT'd + classifier-LoRA:
    python evaluate_on_subset.py --model bert-base-multilingual-cased \
        --lapt-checkpoint results/LAPT_mbert_full/final --lora true \
        --final-model-dir results_classifier/mbert_full_lapt_clslora/final \
        --test-file length_matched_test.jsonl \
        --raid-threshold <value from that run's metrics.json>
"""

import argparse
import json
import os

import numpy as np
import torch
from datasets import Dataset
from sklearn.metrics import accuracy_score, confusion_matrix, precision_recall_fscore_support, roc_auc_score
from transformers import AutoModelForSequenceClassification, AutoTokenizer, Trainer, TrainingArguments

LABEL2ID = {"human": 0, "machine": 1}
ID2LABEL = {0: "Human", 1: "Machine"}


def load_jsonl(path):
    texts, labels, langs = [], [], []
    with open(path, encoding="utf-8") as f:
        for line in f:
            item = json.loads(line)
            texts.append(item["text"])
            labels.append(LABEL2ID[item["label"]])
            langs.append(item["lang"])
    return texts, labels, langs


def build_dataset(texts, labels, tokenizer, max_length=256):
    enc = tokenizer(texts, truncation=True, max_length=max_length, padding="max_length")
    ds = Dataset.from_dict({"input_ids": enc["input_ids"], "attention_mask": enc["attention_mask"], "labels": labels})
    ds.set_format("torch")
    return ds


def _copy_lapt_backbone_into_classifier(lapt_backbone_model, cls_model, backbone_attr):
    """Same fix as finetune_classifier_bohb.py: copy embeddings+encoder
    only, never swap the whole submodule."""
    lapt_backbone = getattr(lapt_backbone_model, backbone_attr)
    cls_backbone = getattr(cls_model, backbone_attr)
    lapt_state = lapt_backbone.state_dict()
    cls_state = cls_backbone.state_dict()
    transferred = {k: v for k, v in lapt_state.items() if k in cls_state and not k.startswith("pooler")}
    cls_state.update(transferred)
    cls_backbone.load_state_dict(cls_state)
    return cls_model


def build_lapt_merged_classifier(model_name, lapt_checkpoint, num_labels=2):
    if lapt_checkpoint is None:
        return AutoModelForSequenceClassification.from_pretrained(
            model_name, num_labels=num_labels, id2label=ID2LABEL, label2id=LABEL2ID
        )
    is_lora_lapt = os.path.exists(os.path.join(lapt_checkpoint, "adapter_config.json"))
    cls_model = AutoModelForSequenceClassification.from_pretrained(
        model_name, num_labels=num_labels, id2label=ID2LABEL, label2id=LABEL2ID
    )
    backbone_attr = "bert" if hasattr(cls_model, "bert") else "roberta"
    from transformers import AutoModelForMaskedLM
    if is_lora_lapt:
        from peft import PeftModel
        base = AutoModelForMaskedLM.from_pretrained(model_name)
        merged = PeftModel.from_pretrained(base, lapt_checkpoint).merge_and_unload()
        return _copy_lapt_backbone_into_classifier(merged, cls_model, backbone_attr)
    else:
        lapt_model = AutoModelForMaskedLM.from_pretrained(lapt_checkpoint)
        return _copy_lapt_backbone_into_classifier(lapt_model, cls_model, backbone_attr)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--lapt-checkpoint", default=None,
                     help="Only needed if the model being evaluated was trained "
                          "starting from a LAPT checkpoint -- must match what "
                          "was used for the ORIGINAL training run, so the "
                          "classifier-LoRA adapter (if any) attaches to the "
                          "correct base.")
    ap.add_argument("--lora", type=lambda v: str(v).lower() in ("true", "1", "yes"), default=False)
    ap.add_argument("--final-model-dir", required=True,
                     help="The `final/` directory from the ORIGINAL finetune_classifier_bohb.py run")
    ap.add_argument("--test-file", required=True, help="e.g. the length-matched subset")
    ap.add_argument("--raid-threshold", type=float, default=None,
                     help="From the original run's metrics.json -> raid_style_evaluation.threshold. "
                          "If omitted, only default-threshold (0.5) results are reported.")
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--max-length", type=int, default=256)
    args = ap.parse_args()

    tokenizer = AutoTokenizer.from_pretrained(args.model)
    texts, labels, langs = load_jsonl(args.test_file)
    ds = build_dataset(texts, labels, tokenizer, args.max_length)
    print(f"Loaded {len(texts)} examples from {args.test_file}")

    if args.lora:
        from peft import PeftModel
        base_for_final = build_lapt_merged_classifier(args.model, args.lapt_checkpoint, num_labels=2)
        model = PeftModel.from_pretrained(base_for_final, args.final_model_dir)
    else:
        model = AutoModelForSequenceClassification.from_pretrained(args.final_model_dir)

    training_args = TrainingArguments(
        output_dir="/tmp/_length_matched_eval_scratch",
        per_device_eval_batch_size=args.batch_size,
        bf16=torch.cuda.is_available(),
        report_to="none",
    )
    trainer = Trainer(model=model, args=training_args)

    predictions = trainer.predict(ds)
    logits = predictions.predictions
    labels_arr = np.array(labels)
    probs = torch.softmax(torch.tensor(logits), dim=-1)[:, 1].numpy()
    preds_default = (probs >= 0.5).astype(int)

    acc = accuracy_score(labels_arr, preds_default)
    p, r, f1, _ = precision_recall_fscore_support(labels_arr, preds_default, average="binary", pos_label=1)
    auc = roc_auc_score(labels_arr, probs)
    tn, fp, fn, tp = confusion_matrix(labels_arr, preds_default, labels=[0, 1]).ravel()

    print(f"\n=== Default threshold (0.5) on {args.test_file} ===")
    print(f"Accuracy : {acc:.4f}")
    print(f"Precision: {p:.4f}")
    print(f"Recall   : {r:.4f}")
    print(f"F1       : {f1:.4f}")
    print(f"ROC-AUC  : {auc:.4f}")
    print(f"Confusion matrix: tn={tn} fp={fp} fn={fn} tp={tp}")

    result = {
        "test_file": args.test_file,
        "n_examples": len(texts),
        "default_threshold": {
            "accuracy": acc, "precision": p, "recall": r, "f1": f1, "roc_auc": auc,
            "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
        },
    }

    if args.raid_threshold is not None:
        preds_raid = (probs >= args.raid_threshold).astype(int)
        raid_acc = accuracy_score(labels_arr, preds_raid)
        rtn, rfp, rfn, rtp = confusion_matrix(labels_arr, preds_raid, labels=[0, 1]).ravel()
        achieved_fpr = rfp / (rfp + rtn) if (rfp + rtn) > 0 else None
        print(f"\n=== Original RAID threshold ({args.raid_threshold:.6f}), reapplied (not recalibrated) ===")
        print(f"Accuracy: {raid_acc:.4f}  |  Achieved FPR on this subset: {achieved_fpr:.4f}")
        print(f"Confusion matrix: tn={rtn} fp={rfp} fn={rfn} tp={rtp}")
        result["raid_threshold_reapplied"] = {
            "threshold": args.raid_threshold,
            "accuracy": raid_acc,
            "achieved_fpr_on_this_subset": achieved_fpr,
            "confusion_matrix": {"tn": int(rtn), "fp": int(rfp), "fn": int(rfn), "tp": int(rtp)},
        }

    # Include the run id (from --final-model-dir) in the filename
    run_id = os.path.basename(os.path.normpath(os.path.dirname(args.final_model_dir)))
    test_stem = os.path.basename(args.test_file).replace(".jsonl", "")
    out_path = f"{test_stem}_{run_id}_eval_result.json"
    with open(out_path, "w") as f:
        json.dump(result, f, indent=2)
    print(f"\nSaved: {out_path}")


if __name__ == "__main__":
    main()
