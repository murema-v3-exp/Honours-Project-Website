"""
Evaluates an already-trained TF-IDF+LogisticRegression pipeline against a given test file

Reuses the original RAID threshold rather than recalibrating .

Usage:
    python evaluate_tfidf_on_subset.py \
        --model-path results_tfidf/TFIDF_WordLevel_Baseline/model.joblib \
        --test-file finetuning_data/test_full_stripped.jsonl \
        --raid-threshold <value from that baseline's baseline_config.json>
"""

import argparse
import json

import joblib
import numpy as np
from sklearn.metrics import accuracy_score, confusion_matrix, precision_recall_fscore_support, roc_auc_score

LABEL2ID = {"human": 0, "machine": 1}


def load_jsonl(path):
    texts, labels = [], []
    with open(path, encoding="utf-8") as f:
        for line in f:
            item = json.loads(line)
            texts.append(item["text"])
            labels.append(LABEL2ID[item["label"]])
    return texts, labels


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model-path", required=True, help="Path to the saved model.joblib")
    ap.add_argument("--test-file", required=True)
    ap.add_argument("--raid-threshold", type=float, default=None,
                     help="From the original baseline's baseline_config.json -> "
                          "raid_style_evaluation.threshold")
    args = ap.parse_args()

    pipeline = joblib.load(args.model_path)
    texts, labels = load_jsonl(args.test_file)
    labels_arr = np.array(labels)
    print(f"Loaded {len(texts)} examples from {args.test_file}")

    probs = pipeline.predict_proba(texts)[:, 1]
    preds_default = (probs >= 0.5).astype(int)

    acc = accuracy_score(labels_arr, preds_default)
    p, r, f1, _ = precision_recall_fscore_support(labels_arr, preds_default, average="binary", pos_label=1)
    auc = roc_auc_score(labels_arr, probs)
    tn, fp, fn, tp = confusion_matrix(labels_arr, preds_default, labels=[0, 1]).ravel()

    print(f"\n=== Default threshold (0.5) on {args.test_file} ===")
    print(f"Accuracy : {acc:.4f}")
    print(f"Precision: {p:.4f}")
    print(f"Recall   : {r:.4f}")
    print(f"F1       : {f1:.4f}")
    print(f"ROC-AUC  : {auc:.4f}")
    print(f"Confusion matrix: tn={tn} fp={fp} fn={fn} tp={tp}")

    result = {
        "test_file": args.test_file,
        "n_examples": len(texts),
        "default_threshold": {
            "accuracy": acc, "precision": p, "recall": r, "f1": f1, "roc_auc": auc,
            "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
        },
    }

    if args.raid_threshold is not None:
        preds_raid = (probs >= args.raid_threshold).astype(int)
        raid_acc = accuracy_score(labels_arr, preds_raid)
        rtn, rfp, rfn, rtp = confusion_matrix(labels_arr, preds_raid, labels=[0, 1]).ravel()
        achieved_fpr = rfp / (rfp + rtn) if (rfp + rtn) > 0 else None
        print(f"\n=== Original RAID threshold ({args.raid_threshold:.6f}), reapplied (not recalibrated) ===")
        print(f"Accuracy: {raid_acc:.4f}  |  Achieved FPR on this subset: {achieved_fpr:.4f}")
        print(f"Confusion matrix: tn={rtn} fp={rfp} fn={rfn} tp={rtp}")
        result["raid_threshold_reapplied"] = {
            "threshold": args.raid_threshold,
            "accuracy": raid_acc,
            "achieved_fpr_on_this_subset": achieved_fpr,
            "confusion_matrix": {"tn": int(rtn), "fp": int(rfp), "fn": int(rfn), "tp": int(rtp)},
        }

    # Include the run id (from --model-path's parent dir) in the filename 
    import os
    run_id = os.path.basename(os.path.normpath(os.path.dirname(args.model_path)))
    test_stem = os.path.basename(args.test_file).replace(".jsonl", "")
    out_path = f"{test_stem}_{run_id}_tfidf_eval_result.json"
    with open(out_path, "w") as f:
        json.dump(result, f, indent=2)
    print(f"\nSaved: {out_path}")


if __name__ == "__main__":
    main()
