"""
Classifier fine-tuning with BOHB-style hyperparameter search for
isiXhosa/isiZulu MGT detection. Starting from either a raw pretrained
checkpoint or a LAPT'd checkpoint (full or LoRA), so the same script
produces both the no-LAPT baseline and every LAPT'd-checkpoint comparison
point in the ablation.

Method: BOHB-style search (Bayesian optimization to propose configs,
Hyperband to early-stop weak trials)

Loading a LAPT'd checkpoint: pass --lapt-checkpoint pointing at a final/
directory from train_lapt.py
"""

import argparse
import json
import os
import shutil
import time

import numpy as np
import optuna
import torch
from datasets import Dataset
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    precision_recall_fscore_support,
    roc_auc_score,
    roc_curve,
)
from transformers import (
    AutoModelForSequenceClassification,
    AutoTokenizer,
    Trainer,
    TrainerCallback,
    TrainingArguments,
)

LABEL2ID = {"human": 0, "machine": 1}
ID2LABEL = {0: "Human", 1: "Machine"}
SEED = 42


def load_jsonl(path):
    texts, labels, langs = [], [], []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            item = json.loads(line)
            texts.append(item["text"])
            labels.append(LABEL2ID[item["label"]])
            langs.append(item["lang"])
    return texts, labels, langs


def build_dataset(texts, labels, langs, tokenizer, max_length=256):
    enc = tokenizer(texts, truncation=True, max_length=max_length, padding="max_length")
    ds = Dataset.from_dict({
        "input_ids": enc["input_ids"],
        "attention_mask": enc["attention_mask"],
        "labels": labels,
        "language": langs,
    })
    ds.set_format("torch", columns=["input_ids", "attention_mask", "labels"], output_all_columns=True)
    return ds


def compute_metrics(eval_pred):
    logits, labels = eval_pred
    preds = np.argmax(logits, axis=-1)
    acc = accuracy_score(labels, preds)
    p, r, f1, _ = precision_recall_fscore_support(labels, preds, average="binary", pos_label=1, zero_division=0)
    return {"accuracy": acc, "precision": p, "recall": r, "f1": f1}


def get_probs_and_labels(trainer, dataset):
    """Raw positive-class (machine) probabilities and true labels. Needed
    for anything threshold-dependent (confusion matrix, ROC curve, FPR
    calibration). trainer.evaluate() alone only gives scalar metrics at
    the default 0.5 threshold."""
    predictions = trainer.predict(dataset)
    logits = predictions.predictions
    labels = predictions.label_ids
    probs = torch.softmax(torch.tensor(logits), dim=-1)[:, 1].numpy()
    return probs, labels


def calibrate_threshold_for_fpr(val_probs, val_labels, target_fpr=0.05):
    """The RAID evaluation protocol: calibrate the decision threshold to a
    fixed false positive rate on human-written text, then report accuracy
    on machine text at that threshold.

    Calibrated on VAL, not test, to avoid leaking test-set info into the
    threshold choice.

    Returns (threshold, achieved_fpr, unreachable). sklearn's roc_curve
    inserts a synthetic first threshold of max(score)+1 for the "predict
    nothing positive" point unreachable by any real probability
    (bounded [0,1]) and not valid JSON (Infinity isn't RFC 8259). If the
    closest-to-target point is that synthetic entry, no real threshold
    gets near target_fpr
    """
    fpr, tpr, thresholds = roc_curve(val_labels, val_probs)
    idx = np.argmin(np.abs(fpr - target_fpr))
    threshold = float(thresholds[idx])
    achieved_fpr = float(fpr[idx])
    unreachable = threshold > 1.0  # only true at sklearn's synthetic entry (probs are bounded [0,1])
    if unreachable:
        threshold = 1.0
    return threshold, achieved_fpr, unreachable


def _copy_lapt_backbone_into_classifier(lapt_backbone_model, cls_model, backbone_attr):
    """Copies embeddings + encoder weights from a LAPT'd MLM backbone into
    a fresh classification model's backbone, without touching the
    classification model's own pooler.

    MLM models are built with add_pooling_layer=False,
    while classification models are built with a pooler. A
    wholesale submodule swap would give the classifier a pooler-less
    backbone, which crashes as soon as forward() tries to read the
    pooler output.
    """
    lapt_backbone = getattr(lapt_backbone_model, backbone_attr)
    cls_backbone = getattr(cls_model, backbone_attr)

    lapt_state = lapt_backbone.state_dict()
    cls_state = cls_backbone.state_dict()
    transferred = {k: v for k, v in lapt_state.items() if k in cls_state and not k.startswith("pooler")}
    cls_state.update(transferred)
    cls_backbone.load_state_dict(cls_state)
    return cls_model


def build_lapt_merged_classifier(model_name, lapt_checkpoint, num_labels=2):
    """Returns a plain AutoModelForSequenceClassification with the LAPT
    checkpoint's embeddings+encoder weights merged in (or the untouched
    pretrained backbone if lapt_checkpoint is None). Classification head
    and pooler always come from a fresh classification-model load, never
    from the MLM checkpoint (which has neither). Factored out from
    load_model() so it can be reused both for training and for rebuilding
    the correct base when reloading a classifier-LoRA adapter later."""
    if lapt_checkpoint is None:
        return AutoModelForSequenceClassification.from_pretrained(
            model_name, num_labels=num_labels, id2label=ID2LABEL, label2id=LABEL2ID
        )

    # Full vs LoRA LAPT: detected by presence of adapter_config.json in the checkpoint dir.
    is_lora_lapt = os.path.exists(os.path.join(lapt_checkpoint, "adapter_config.json"))
    cls_model = AutoModelForSequenceClassification.from_pretrained(
        model_name, num_labels=num_labels, id2label=ID2LABEL, label2id=LABEL2ID
    )
    backbone_attr = "bert" if hasattr(cls_model, "bert") else "roberta"

    if is_lora_lapt:
        from peft import PeftModel
        from transformers import AutoModelForMaskedLM

        base = AutoModelForMaskedLM.from_pretrained(model_name)
        merged = PeftModel.from_pretrained(base, lapt_checkpoint)
        # Merge into the base weights
        merged = merged.merge_and_unload()
        return _copy_lapt_backbone_into_classifier(merged, cls_model, backbone_attr)
    else:
        from transformers import AutoModelForMaskedLM

        lapt_model = AutoModelForMaskedLM.from_pretrained(lapt_checkpoint)
        return _copy_lapt_backbone_into_classifier(lapt_model, cls_model, backbone_attr)


def load_model(model_name, lapt_checkpoint, num_labels=2, use_lora=False, lora_r=16):
    """Builds the LAPT-merged (or plain) classification model, then
    optionally wraps it with a fresh LoRA adapter for the classifier
    fine-tuning stage itself.

    Default lora_r=16: matches this project's
    classifier LoRA convention rather than the LAPT-specific rank.
    """
    cls_model = build_lapt_merged_classifier(model_name, lapt_checkpoint, num_labels)

    if use_lora:
        from peft import LoraConfig, TaskType, get_peft_model
        # Unlike LAPT's MLM stage, SEQ_CLS is natively supported: peft keeps the classification head fully
        # trainable (modules_to_save) while LoRA-adapting the attention layers.
        lora_config = LoraConfig(
            r=lora_r,
            lora_alpha=lora_r * 2,
            target_modules=["query", "value"],
            lora_dropout=0.05,
            bias="none",
            task_type=TaskType.SEQ_CLS,
        )
        cls_model = get_peft_model(cls_model, lora_config)
        cls_model.print_trainable_parameters()

    return cls_model


class PruningCallback(TrainerCallback):
    """Reports eval accuracy to Optuna after each epoch and raises
    TrialPruned if Hyperband decides this trial isn't worth continuing

    Important: trial.should_prune() is not idempotent. The pruning decision
    must be captured here, at the moment it's made, in self.pruned.
    """

    def __init__(self, trial):
        self.trial = trial
        self.pruned = False
        self._last_reported_epoch = None

    def on_evaluate(self, args, state, control, metrics=None, **kwargs):
        if metrics is None:
            return control
        epoch = int(round(state.epoch))
        if epoch == self._last_reported_epoch:
            # Avoids a duplicate-report warning when evaluate() is called again
            # after training at an epoch already reported during the training loop.
            return control
        self._last_reported_epoch = epoch
        self.trial.report(metrics.get("eval_accuracy", 0.0), step=epoch)
        if self.trial.should_prune():
            self.pruned = True
            control.should_training_stop = True
        return control


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, help="bert-base-multilingual-cased or xlm-roberta-base")
    ap.add_argument("--lapt-checkpoint", default=None,
                     help="Path to a train_lapt.py `final/` dir. Omit for the no-LAPT baseline.")
    ap.add_argument("--train-file", required=True)
    ap.add_argument("--val-file", required=True)
    ap.add_argument("--test-file", required=True)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--n-trials", type=int, default=8)
    ap.add_argument("--max-epochs", type=int, default=10)
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--max-length", type=int, default=256)
    ap.add_argument("--lora", type=lambda v: str(v).lower() in ("true", "1", "yes"), default=False,
                     help="LoRA for the CLASSIFIER stage itself -- independent of whether "
                          "--lapt-checkpoint was LoRA-trained (that adapter gets merged away "
                          "regardless; this is a fresh adapter for classifier fine-tuning). "
                          "Rank is searched (see objective()), not fixed via a flag.")
    args = ap.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    tokenizer = AutoTokenizer.from_pretrained(args.model)

    print("Loading data...")
    train_texts, train_labels, train_langs = load_jsonl(args.train_file)
    val_texts, val_labels, val_langs = load_jsonl(args.val_file)
    test_texts, test_labels, test_langs = load_jsonl(args.test_file)

    train_ds = build_dataset(train_texts, train_labels, train_langs, tokenizer, args.max_length)
    val_ds = build_dataset(val_texts, val_labels, val_langs, tokenizer, args.max_length)
    test_ds = build_dataset(test_texts, test_labels, test_langs, tokenizer, args.max_length)
    print(f"Train: {len(train_ds)}  Val: {len(val_ds)}  Test: {len(test_ds)}")

    trials_dir = os.path.join(args.output_dir, "_trials")
    os.makedirs(trials_dir, exist_ok=True)

    def objective(trial):
        lr = trial.suggest_float("learning_rate", 1e-5, 5e-4, log=True)
        weight_decay = trial.suggest_float("weight_decay", 0.0, 0.1)

        # Rank is searched, not fixed, when LoRA is on 
        lora_r = trial.suggest_categorical("lora_r", [4, 8, 16, 32, 64]) if args.lora else None

        model = load_model(args.model, args.lapt_checkpoint, use_lora=args.lora, lora_r=lora_r)
        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)

        trial_dir = os.path.join(trials_dir, f"trial_{trial.number}")
        training_args = TrainingArguments(
            output_dir=trial_dir,
            per_device_train_batch_size=args.batch_size,
            per_device_eval_batch_size=args.batch_size,
            num_train_epochs=args.max_epochs,
            learning_rate=lr,
            weight_decay=weight_decay,
            eval_strategy="epoch",
            save_strategy="epoch",
            save_total_limit=1,
            load_best_model_at_end=True,
            metric_for_best_model="accuracy",
            bf16=torch.cuda.is_available(),
            report_to="none",
            logging_steps=50,
        )

        pruning_callback = PruningCallback(trial)
        trainer = Trainer(
            model=model,
            args=training_args,
            train_dataset=train_ds.remove_columns(["language"]),
            eval_dataset=val_ds.remove_columns(["language"]),
            compute_metrics=compute_metrics,
            callbacks=[pruning_callback],
        )

        if torch.cuda.is_available():
            torch.cuda.reset_peak_memory_stats()
        t_start = time.time()

        trainer.train()

        t_end = time.time()
        peak_mem_gb = torch.cuda.max_memory_allocated() / 1e9 if torch.cuda.is_available() else None

        eval_result = trainer.evaluate()

        # Recorded regardless of prune/complete.
        trial.set_user_attr("wall_clock_seconds", t_end - t_start)
        trial.set_user_attr("peak_gpu_memory_gb", peak_mem_gb)
        trial.set_user_attr("total_params", total_params)
        trial.set_user_attr("trainable_params", trainable_params)

        if pruning_callback.pruned:
            # Decided inside the callback, not re-queried here.
            shutil.rmtree(trial_dir, ignore_errors=True)
            raise optuna.TrialPruned()

        trainer.save_model(trial_dir)  # overwrite with the best-checkpoint state actually used
        tokenizer.save_pretrained(trial_dir)
        return eval_result["eval_accuracy"]

    study_name = os.path.basename(args.output_dir.rstrip("/"))
    storage_path = f"sqlite:///{os.path.join(args.output_dir, 'optuna_study.db')}"
    # TPESampler: Bayesian-optimization component, picks new configs informed by past
    # trials. HyperbandPruner: bandit-based early-termination component, kills weak
    # trials early. Together this is the TPE + Hyperband hybrid BOHB describes, without
    # needing a distributed nameserver/worker setup.
    sampler = optuna.samplers.TPESampler(seed=SEED)
    pruner = optuna.pruners.HyperbandPruner(min_resource=1, max_resource=args.max_epochs, reduction_factor=3)
    study = optuna.create_study(
        study_name=study_name,
        storage=storage_path,
        direction="maximize",
        sampler=sampler,
        pruner=pruner,
        load_if_exists=True,  # resume from the .db if it already has trials
    )

    # Only complete/pruned trials count as "done" 
    n_done = sum(1 for t in study.trials if t.state in
                 (optuna.trial.TrialState.COMPLETE, optuna.trial.TrialState.PRUNED))
    n_remaining = max(0, args.n_trials - n_done)

    if n_done > 0:
        print(f"\nResuming existing study ({storage_path}): {n_done} trials already done, "
              f"running {n_remaining} more to reach --n-trials {args.n_trials}")

    print(f"\nRunning BOHB search: {n_remaining} trial(s) this invocation "
          f"(target {args.n_trials} total), TPE sampling + Hyperband pruning "
          f"(min_resource=1, max_resource={args.max_epochs} epochs)")
    search_start = time.time()
    if n_remaining > 0:
        study.optimize(objective, n_trials=n_remaining)
    else:
        print("Study already has enough completed/pruned trials -- skipping search entirely.")
    search_wall_clock_seconds = time.time() - search_start

    print(f"\nBest trial: #{study.best_trial.number}, accuracy={study.best_value:.4f}")
    print(f"Best params: {study.best_params}")
    print(f"Total search wall-clock: {search_wall_clock_seconds/3600:.3f} hours "
          f"({args.n_trials} trials requested, "
          f"{sum(1 for t in study.trials if t.state == optuna.trial.TrialState.PRUNED)} pruned early)")

    # The winning trial already trained to full budget by surviving every Hyperband round
    best_trial_dir = os.path.join(trials_dir, f"trial_{study.best_trial.number}")
    final_dir = os.path.join(args.output_dir, "final")
    shutil.copytree(best_trial_dir, final_dir, dirs_exist_ok=True)

    # Remove other trial dirs (full model checkpoints each) once the winner is promoted.
    for d in os.listdir(trials_dir):
        if d != f"trial_{study.best_trial.number}":
            shutil.rmtree(os.path.join(trials_dir, d), ignore_errors=True)

    # Final test-set evaluation, combined + per-language.
    if args.lora:
        from peft import PeftModel
        # Rebuild the same LAPT-merged base the adapter was trained on
        base_for_final = build_lapt_merged_classifier(args.model, args.lapt_checkpoint, num_labels=2)
        final_model = PeftModel.from_pretrained(base_for_final, final_dir)
    else:
        final_model = AutoModelForSequenceClassification.from_pretrained(final_dir)
    final_args = TrainingArguments(
        output_dir=os.path.join(args.output_dir, "_final_eval_scratch"),
        per_device_eval_batch_size=args.batch_size,
        bf16=torch.cuda.is_available(),
        report_to="none",
    )
    final_trainer = Trainer(model=final_model, args=final_args, compute_metrics=compute_metrics)

    # RAID-style evaluation: calibrate a threshold to 5% FPR on val (never test),
    # then report both default-threshold and FPR-calibrated results on test.
    val_probs, val_labels_arr = get_probs_and_labels(final_trainer, val_ds.remove_columns(["language"]))
    raid_threshold, val_achieved_fpr, threshold_unreachable = calibrate_threshold_for_fpr(
        val_probs, val_labels_arr, target_fpr=0.05
    )
    print(f"\nRAID-style threshold calibration: target FPR=5%, calibrated on val, "
          f"threshold={raid_threshold:.4f}, actual val FPR at this threshold={val_achieved_fpr:.4f}"
          f"{' (UNREACHABLE -- no real threshold gets close to 5% FPR)' if threshold_unreachable else ''}")

    combined_test = test_ds.remove_columns(["language"])
    test_probs, test_labels_arr = get_probs_and_labels(final_trainer, combined_test)
    test_preds_default = (test_probs >= 0.5).astype(int)
    test_preds_raid = (test_probs >= raid_threshold).astype(int)

    tn, fp, fn, tp = confusion_matrix(test_labels_arr, test_preds_default, labels=[0, 1]).ravel()
    raid_tn, raid_fp, raid_fn, raid_tp = confusion_matrix(test_labels_arr, test_preds_raid, labels=[0, 1]).ravel()
    test_achieved_fpr_at_raid_threshold = raid_fp / (raid_fp + raid_tn) if (raid_fp + raid_tn) > 0 else None

    fpr_curve, tpr_curve, roc_thresholds = roc_curve(test_labels_arr, test_probs)
    # Same sklearn quirk as calibrate_threshold_for_fpr: first entry is np.inf, not
    # valid JSON. Clip to 1.0 before saving (loses no info; probs are bounded [0,1]).
    roc_thresholds_safe = np.clip(roc_thresholds, a_min=None, a_max=1.0)

    test_results = {}
    combined_test_metrics = final_trainer.evaluate(eval_dataset=combined_test)
    combined_test_metrics["confusion_matrix"] = {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)}
    combined_test_metrics["roc_auc"] = roc_auc_score(test_labels_arr, test_probs)
    test_results["combined"] = combined_test_metrics
    for lang in sorted(set(test_langs)):
        subset = test_ds.filter(lambda ex: ex["language"] == lang).remove_columns(["language"])
        lang_metrics = final_trainer.evaluate(eval_dataset=subset)
        lang_probs, lang_labels_arr = get_probs_and_labels(final_trainer, subset)
        lang_preds = (lang_probs >= 0.5).astype(int)
        ltn, lfp, lfn, ltp = confusion_matrix(lang_labels_arr, lang_preds, labels=[0, 1]).ravel()
        lang_metrics["confusion_matrix"] = {"tn": int(ltn), "fp": int(lfp), "fn": int(lfn), "tp": int(ltp)}
        test_results[lang] = lang_metrics

    raid_style_results = {
        "target_fpr": 0.05,
        "threshold": raid_threshold,
        "threshold_unreachable": threshold_unreachable,
        "val_achieved_fpr_at_threshold": val_achieved_fpr,
        "test_achieved_fpr_at_threshold": test_achieved_fpr_at_raid_threshold,
        "test_accuracy_at_calibrated_threshold": accuracy_score(test_labels_arr, test_preds_raid),
        "test_confusion_matrix_at_calibrated_threshold": {
            "tn": int(raid_tn), "fp": int(raid_fp), "fn": int(raid_fn), "tp": int(raid_tp)
        },
        "note": (
            "No val threshold got close to 5% FPR (model's score distribution doesn't "
            "separate finely enough at this operating point) -- threshold clamped to 1.0 "
            "(predicts nothing as machine), reported for transparency, not usefully interpretable."
            if threshold_unreachable else
            "Threshold calibrated on val (RAID protocol), applied to test. "
            "test_achieved_fpr may differ slightly from target_fpr/val_achieved_fpr since val and "
            "test have different score distributions -- reported honestly rather than assumed."
        ),
    }

    # Save per-example predictions + full ROC curve so plots/matrices at any
    # threshold can be reconstructed later without re-running training.
    import csv
    with open(os.path.join(args.output_dir, "test_predictions.csv"), "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["true_label", "probability_machine", "language", "pred_default_0.5", "pred_raid_calibrated"])
        for prob, label, lang, pred_d, pred_r in zip(
            test_probs, test_labels_arr, test_langs, test_preds_default, test_preds_raid
        ):
            writer.writerow([int(label), float(prob), lang, int(pred_d), int(pred_r)])

    with open(os.path.join(args.output_dir, "roc_curve.json"), "w") as f:
        json.dump({
            "fpr": fpr_curve.tolist(),
            "tpr": tpr_curve.tolist(),
            "thresholds": roc_thresholds_safe.tolist(),
        }, f)

    report = {
        "config": {
            "model": args.model,
            "lapt_checkpoint": args.lapt_checkpoint,
            "n_trials": args.n_trials,
            "max_epochs": args.max_epochs,
            "classifier_lora": args.lora,
            "classifier_lora_r_searched": [4, 8, 16, 32, 64] if args.lora else None,
        },
        "search_method": "TPE sampler + Hyperband pruner (BOHB-style)",
        "resource_usage": {
            "total_search_wall_clock_seconds": search_wall_clock_seconds,
            "total_search_wall_clock_hours": round(search_wall_clock_seconds / 3600, 3),
            "n_trials_requested": args.n_trials,
            "n_trials_pruned": sum(1 for t in study.trials if t.state == optuna.trial.TrialState.PRUNED),
            "best_trial_wall_clock_seconds": study.best_trial.user_attrs.get("wall_clock_seconds"),
            "best_trial_peak_gpu_memory_gb": study.best_trial.user_attrs.get("peak_gpu_memory_gb"),
            "best_trial_total_params": study.best_trial.user_attrs.get("total_params"),
            "best_trial_trainable_params": study.best_trial.user_attrs.get("trainable_params"),
        },
        "best_trial": study.best_trial.number,
        "best_params": study.best_params,
        "best_val_accuracy": study.best_value,
        "test_results": {k: v for k, v in test_results.items()},
        "raid_style_evaluation": raid_style_results,
        "all_trials": [
            {
                "number": t.number,
                "state": str(t.state),
                "value": t.value,
                "params": t.params,
                "wall_clock_seconds": t.user_attrs.get("wall_clock_seconds"),
                "peak_gpu_memory_gb": t.user_attrs.get("peak_gpu_memory_gb"),
            }
            for t in study.trials
        ],
    }
    with open(os.path.join(args.output_dir, "metrics.json"), "w") as f:
        json.dump(report, f, indent=2)

    print(f"\nDone. Results saved to {args.output_dir}")


if __name__ == "__main__":
    main()
