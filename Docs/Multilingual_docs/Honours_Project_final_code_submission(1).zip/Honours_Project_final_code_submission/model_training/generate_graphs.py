"""
Generates the key result figures for the project from all_results.csv
(metrics + resource usage), bootstrap_ci.csv (uncertainty), and the raw
per-run roc_curve.json + test_predictions.csv files.

FIGURES PRODUCED (see each fig*_ function below for what it does and why):
  1. main_comparison_bar.png          RAID-accuracy across the full matrix
  2. bootstrap_ci_forest.png          point estimates + 95% CI, sorted
  3. roc_curves_mbert.png,
     roc_curves_xlmr.png              actual ROC curves, one figure per backbone
  4. resource_efficiency.png          peak GPU memory & wall-clock hours vs
                                         RAID-accuracy (full vs LoRA classifier)
  5. probability_distributions.png    predicted-probability histograms by
                                         true class, threshold lines marked
  6. per_language_comparison.png      xho vs zul accuracy across configs

Each figure is wrapped so a missing input file skips that figure with a
clear message rather than crashing the whole script.

Usage:
    python generate_graphs.py \
        --all-results all_results.csv \
        --bootstrap-ci bootstrap_ci.csv \
        --results-dir results_classifier \
        --tfidf-dir results_tfidf \
        --output-dir figures
"""

import argparse
import csv
import json
import os

import matplotlib.pyplot as plt
import numpy as np

plt.rcParams["figure.dpi"] = 120
plt.rcParams["savefig.bbox"] = "tight"


def load_csv(path):
    if not os.path.exists(path):
        return None
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def fnum(row, key, default=None):
    v = row.get(key)
    if v is None or v == "":
        return default
    try:
        return float(v)
    except ValueError:
        return default


BACKBONE_COLORS = {"mBERT": "#4C72B0", "XLM-R": "#DD8452", "TF-IDF-word": "#55A868", "TF-IDF-char": "#8172B2"}


def fig1_main_comparison(rows, output_dir):
    rows = [r for r in rows if fnum(r, "raid_accuracy") is not None]
    rows.sort(key=lambda r: fnum(r, "raid_accuracy"))

    fig, ax = plt.subplots(figsize=(max(9, len(rows) * 0.55), 7))
    x = np.arange(len(rows))
    accs = [fnum(r, "raid_accuracy") for r in rows]
    colors = [BACKBONE_COLORS.get(r["backbone"], "#999999") for r in rows]
    labels = [r["run_name"] for r in rows]
    unreachable = [r.get("raid_threshold_unreachable", "").lower() == "true" for r in rows]

    ax.set_ylim(0.4, 1.08)
    ax.bar(x, accs, color=colors)

    # Alternate the vertical offset for consecutive "threshold unreachable" labels
    # so adjacent unreachable bars (e.g. the two TF-IDF baselines) don't collide.
    last_unreachable_idx = None
    offset_toggle = 0
    for i, (u, acc) in enumerate(zip(unreachable, accs)):
        if u:
            if last_unreachable_idx is not None and i - last_unreachable_idx <= 1:
                offset_toggle = 1 - offset_toggle
            else:
                offset_toggle = 0
            y_offset = 0.02 + offset_toggle * 0.05
            ax.text(i, max(acc, 0.4) + y_offset, "threshold\nunreachable",
                    ha="center", va="bottom", fontsize=7, color="black")
            last_unreachable_idx = i

    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=8, rotation=90)
    ax.set_ylabel("RAID-calibrated test accuracy (5% FPR)")
    ax.set_title("RAID-calibrated accuracy across the full comparison matrix")
    ax.axhline(0.5, color="gray", linewidth=0.5, linestyle="--")

    handles = [plt.Rectangle((0, 0), 1, 1, color=c) for c in BACKBONE_COLORS.values()]
    ax.legend(handles, BACKBONE_COLORS.keys(), loc="upper left", fontsize=8)

    path = os.path.join(output_dir, "main_comparison_bar.png")
    fig.savefig(path)
    plt.close(fig)
    print(f"Saved: {path}")


def fig2_bootstrap_forest(boot_rows, output_dir):
    rows = [r for r in boot_rows if r["metric"] == "accuracy" and r["threshold"] == "raid_calibrated"]
    if not rows:
        print("SKIP fig2: no raid_calibrated accuracy rows in bootstrap_ci.csv")
        return
    rows.sort(key=lambda r: fnum(r, "point_estimate"))

    fig, ax = plt.subplots(figsize=(max(9, len(rows) * 0.55), 7))
    x = np.arange(len(rows))
    points = [fnum(r, "point_estimate") for r in rows]
    lowers = [p - fnum(r, "ci_lower") for p, r in zip(points, rows)]
    uppers = [fnum(r, "ci_upper") - p for p, r in zip(points, rows)]

    ax.errorbar(x, points, yerr=[lowers, uppers], fmt="o", markersize=4, capsize=3, color="#4C72B0")
    ax.set_xticks(x)
    ax.set_xticklabels([r["run_name"] for r in rows], fontsize=8, rotation=90)
    ax.set_ylabel("RAID-calibrated accuracy (point estimate, 95% bootstrap CI)")
    ax.set_title("Bootstrap confidence intervals -- overlapping CIs mean the\ndifference may not be reliable at this test-set size")

    path = os.path.join(output_dir, "bootstrap_ci_forest.png")
    fig.savefig(path)
    plt.close(fig)
    print(f"Saved: {path}")


def _plot_roc_panel(results_dir, run_names, output_path, title_suffix, zoom_xmax, zoom_ymin):
    """Shared ROC-plotting logic for a single named group of runs, saved to
    its own output file."""
    fig, ax = plt.subplots(1, 2, figsize=(13, 5.5))
    any_plotted = False
    for run_name in run_names:
        path = os.path.join(results_dir, run_name, "roc_curve.json")
        if not os.path.exists(path):
            print(f"SKIP roc curve for {run_name}: {path} not found")
            continue
        with open(path) as f:
            roc = json.load(f)
        ax[0].plot(roc["fpr"], roc["tpr"], label=run_name, linewidth=1.2)
        ax[1].plot(roc["fpr"], roc["tpr"], label=run_name, linewidth=1.2)
        any_plotted = True

    if not any_plotted:
        print(f"SKIP {output_path}: no roc_curve.json files found for the requested run names")
        plt.close(fig)
        return

    ax[0].plot([0, 1], [0, 1], "k--", linewidth=0.5)
    ax[0].set_xlabel("False Positive Rate"); ax[0].set_ylabel("True Positive Rate")
    ax[0].set_title("Full ROC curve")
    ax[0].legend(fontsize=7, loc="lower right")

    # Zoomed panel: AUC is ~1.0 everywhere, so the full curve looks identical across models.
    ax[1].set_xlim(0, zoom_xmax)
    ax[1].set_ylim(zoom_ymin, 1.001)
    ax[1].set_xlabel("False Positive Rate (zoomed)")
    ax[1].set_ylabel("True Positive Rate (zoomed)")
    ax[1].set_title(f"Zoomed: xlim=(0,{zoom_xmax}), ylim=({zoom_ymin},1.0)\n"
                     f"-- tighten further via --zoom-xmax/--zoom-ymin if curves still overlap")
    ax[1].legend(fontsize=7, loc="lower right")

    fig.suptitle(f"ROC curves -- key comparisons ({title_suffix})")
    fig.savefig(output_path)
    plt.close(fig)
    print(f"Saved: {output_path}")


def fig3_roc_curves(results_dir, roc_groups, output_dir, zoom_xmax, zoom_ymin):
    """Produces one ROC figure PER GROUP in roc_groups (a dict of
    {group_label: [run_names]}), each with its own distinctly-named file
    -- so the default config covers both backbones automatically instead
    of a single fixed filename silently overwriting itself per group."""
    for group_label, run_names in roc_groups.items():
        safe_label = group_label.lower().replace(" ", "_").replace("-", "")
        output_path = os.path.join(output_dir, f"roc_curves_{safe_label}.png")
        _plot_roc_panel(results_dir, run_names, output_path, group_label, zoom_xmax, zoom_ymin)


def fig4_resource_efficiency(rows, output_dir):
    rows = [r for r in rows if fnum(r, "raid_accuracy") is not None and r.get("classifier_method") in ("full", "lora")]
    if not rows:
        print("SKIP fig4: no rows with both raid_accuracy and classifier_method")
        return

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    markers = {"full": "o", "lora": "^"}
    for method in ["full", "lora"]:
        sub = [r for r in rows if r["classifier_method"] == method]
        mem = [fnum(r, "peak_gpu_memory_gb") for r in sub]
        hrs = [fnum(r, "wall_clock_hours") for r in sub]
        acc = [fnum(r, "raid_accuracy") for r in sub]
        colors = [BACKBONE_COLORS.get(r["backbone"], "#999") for r in sub]
        axes[0].scatter(mem, acc, marker=markers[method], c=colors, label=f"classifier: {method}", s=50, edgecolors="black", linewidths=0.3)
        axes[1].scatter(hrs, acc, marker=markers[method], c=colors, label=f"classifier: {method}", s=50, edgecolors="black", linewidths=0.3)

    axes[0].set_xlabel("Peak GPU memory (GB)"); axes[0].set_ylabel("RAID-calibrated accuracy")
    axes[0].set_title("Memory vs accuracy")
    axes[1].set_xlabel("Wall-clock search time (hours)"); axes[1].set_ylabel("RAID-calibrated accuracy")
    axes[1].set_title("Time vs accuracy (noisier since BOHB pruning varies run to run)")
    for ax in axes:
        ax.legend(fontsize=8)
    fig.suptitle("Resource cost vs accuracy")
    path = os.path.join(output_dir, "resource_efficiency.png")
    fig.savefig(path)
    plt.close(fig)
    print(f"Saved: {path}")


def _find_run_dir(run_name, results_dir, tfidf_dir):
    """Checks results_dir first, then tfidf_dir (if given), for a run's
    output folder -- TF-IDF and transformer classifier runs live in
    separate directories."""
    candidate = os.path.join(results_dir, run_name)
    if os.path.exists(candidate):
        return candidate
    if tfidf_dir:
        candidate = os.path.join(tfidf_dir, run_name)
        if os.path.exists(candidate):
            return candidate
    return None


def fig5_probability_distributions(results_dir, tfidf_dir, run_names, output_dir):
    """Predicted-probability histograms by true class, with default (0.5)
    and RAID threshold lines marked. run_names should include a TF-IDF run
    alongside the transformer runs so the "threshold_unreachable" finding
    has its own visual explanation.

    Grid layout instead of a single row, since a single row of 4+ panels
    (5in each) gets too wide for a paper page.
    """
    n = len(run_names)
    n_cols = int(np.ceil(np.sqrt(n)))
    n_rows = int(np.ceil(n / n_cols))
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(5 * n_cols, 4.5 * n_rows), squeeze=False)
    axes_flat = axes.flatten()
    any_plotted = False
    for ax, run_name in zip(axes_flat, run_names):
        run_dir = _find_run_dir(run_name, results_dir, tfidf_dir)
        if run_dir is None:
            ax.set_title(f"{run_name}\n(test_predictions.csv not found)")
            continue
        path = os.path.join(run_dir, "test_predictions.csv")
        metrics_path = os.path.join(run_dir, "metrics.json")
        if not os.path.exists(path):
            ax.set_title(f"{run_name}\n(test_predictions.csv not found)")
            continue
        rows = load_csv(path)
        human_probs = [float(r["probability_machine"]) for r in rows if int(r["true_label"]) == 0]
        machine_probs = [float(r["probability_machine"]) for r in rows if int(r["true_label"]) == 1]
        ax.hist(human_probs, bins=40, alpha=0.6, label="Human (true)", color="#4C72B0")
        ax.hist(machine_probs, bins=40, alpha=0.6, label="Machine (true)", color="#DD8452")
        ax.axvline(0.5, color="black", linestyle="--", linewidth=1, label="Default threshold (0.5)")

        if os.path.exists(metrics_path):
            with open(metrics_path) as f:
                m = json.load(f)
            raid_t = m.get("raid_style_evaluation", {}).get("threshold")
            unreachable = m.get("raid_style_evaluation", {}).get("threshold_unreachable", False)
            if raid_t is not None and not unreachable:
                label = f"RAID threshold ({raid_t:.4g})"
                ax.axvline(raid_t, color="red", linestyle=":", linewidth=1.5, label=label)
            elif unreachable:
                # An unreachable threshold (e.g. exactly 1.0 for TF-IDF runs) sits
                # invisibly at the plot's edge if drawn as a line 
                ax.text(0.5, 0.5, "No RAID threshold found\n(target FPR unreachable)",
                        transform=ax.transAxes, ha="center", va="center", fontsize=8,
                        color="darkred", style="italic",
                        bbox=dict(boxstyle="round", facecolor="white", edgecolor="darkred", alpha=0.85))

        # Display-only: run_name itself keeps the results_classifier/ directory naming.
        display_name = run_name.replace("lapt", "lapt").replace("LAPT", "LAPT")
        ax.set_title(display_name, fontsize=9)
        ax.set_xlabel("P(machine)")
        ax.set_ylabel("Number of test examples")
        ax.legend(fontsize=7)
        any_plotted = True

    # Hide leftover empty subplot slots from the rounded-up grid.
    for ax in axes_flat[len(run_names):]:
        ax.set_visible(False)

    if not any_plotted:
        print("SKIP fig5: no test_predictions.csv found for any requested run")
        plt.close(fig)
        return

    fig.suptitle("Predicted probability distributions by true class")
    path = os.path.join(output_dir, "probability_distributions.png")
    fig.savefig(path)
    plt.close(fig)
    print(f"Saved: {path}")


def fig6_per_language(rows, results_dir, tfidf_dir, output_dir):
    """Computes per-language accuracy at the RAID-calibrated threshold
    directly from each run's test_predictions.csv, rather than the
    default-(0.5)-threshold accuracy in all_results.csv.
    Falls back to the default-threshold value,
    clearly labelled as such, when test_predictions.csv or a RAID
    threshold isn't available, rather than silently mixing metrics.

    Assumes test_predictions.csv has columns: true_label, language,
    probability_machine.
    """
    xho_accs, zul_accs, labels, used_raid = [], [], [], []

    for r in sorted(rows, key=lambda r: r["run_name"]):
        run_name = r["run_name"]
        run_dir = _find_run_dir(run_name, results_dir, tfidf_dir)
        raid_threshold = fnum(r, "raid_threshold")
        computed = False

        if run_dir is not None and raid_threshold is not None:
            pred_path = os.path.join(run_dir, "test_predictions.csv")
            if os.path.exists(pred_path):
                pred_rows = load_csv(pred_path)
                try:
                    for lang, acc_list in (("xho", xho_accs), ("zul", zul_accs)):
                        sub = [pr for pr in pred_rows if pr.get("language", "").lower().startswith(lang)]
                        if not sub:
                            raise ValueError(f"no rows for language prefix '{lang}'")
                        correct = 0
                        for pr in sub:
                            true_label = int(pr["true_label"])
                            prob_machine = float(pr["probability_machine"])
                            pred_label = 1 if prob_machine >= raid_threshold else 0
                            correct += int(pred_label == true_label)
                        acc_list.append(correct / len(sub))
                    computed = True
                except (KeyError, ValueError) as e:
                    print(f"  {run_name}: couldn't compute RAID-calibrated per-language accuracy ({e}); "
                          f"falling back to default-threshold summary value")

        if not computed:
            xho = fnum(r, "xho_accuracy")
            zul = fnum(r, "zul_accuracy")
            if xho is None or zul is None:
                continue
            xho_accs.append(xho)
            zul_accs.append(zul)

        labels.append(run_name)
        used_raid.append(computed)

    if not labels:
        print("SKIP fig6: no rows with per-language accuracy available (neither computed nor default)")
        return

    # Export exact values to CSV 
    csv_path = os.path.join(output_dir, "per_language_accuracy.csv")
    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["run_name", "xho_accuracy", "zul_accuracy", "metric_used"])
        for run_name, xho, zul, used in zip(labels, xho_accs, zul_accs, used_raid):
            writer.writerow([run_name, xho, zul, "raid_calibrated" if used else "default_threshold"])
    print(f"Saved: {csv_path}")

    any_default_fallback = not all(used_raid)
    metric_label = "RAID-calibrated accuracy" if all(used_raid) else \
        "Accuracy (RAID-calibrated where available, default-threshold otherwise -- see console output)"

    fig, ax = plt.subplots(figsize=(max(9, len(labels) * 0.55), 7))
    x = np.arange(len(labels))
    width = 0.38
    ax.bar(x - width / 2, xho_accs, width=width, label="isiXhosa", color="#4C72B0")
    ax.bar(x + width / 2, zul_accs, width=width, label="isiZulu", color="#DD8452")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=8, rotation=90)
    ax.set_ylabel(metric_label)

    # Autoscale with padding, since RAID-calibrated accuracy spans a much wider
    # band than default-threshold accuracy.
    all_vals = xho_accs + zul_accs
    lo, hi = min(all_vals), max(all_vals)
    pad = max(0.01, (hi - lo) * 0.15)
    ax.set_ylim(max(0, lo - pad), min(1.02, hi + pad))

    title = "Per-language accuracy"
    if any_default_fallback:
        title += "\n(some runs fell back to default-threshold accuracy -- see console output)"
    ax.set_title(title)
    ax.legend()

    path = os.path.join(output_dir, "per_language_comparison.png")
    fig.savefig(path)
    plt.close(fig)
    print(f"Saved: {path}")


def fig7_robustness_comparison(robustness_rows, output_dir):
    rows = [r for r in robustness_rows if fnum(r, "orig_accuracy") is not None
            and fnum(r, "full_stripped_accuracy") is not None]
    if not rows:
        print("SKIP fig7: no rows with both orig_accuracy and full_stripped_accuracy "
              "(run run_all_robustness_checks.py first)")
        return
    rows.sort(key=lambda r: fnum(r, "acc_drop_full_stripped", 0), reverse=True)

    fig, ax = plt.subplots(figsize=(max(10, len(rows) * 0.6), 7))
    x = np.arange(len(rows))
    width = 0.25

    orig = [fnum(r, "orig_accuracy") for r in rows]
    fmt = [fnum(r, "formatting_stripped_accuracy") for r in rows]
    full = [fnum(r, "full_stripped_accuracy") for r in rows]

    ax.bar(x - width, orig, width=width, label="Original", color="#4C72B0")
    ax.bar(x, fmt, width=width, label="Formatting-stripped", color="#DD8452")
    ax.bar(x + width, full, width=width, label="Fully stripped (+ punctuation)", color="#C44E52")

    ax.set_xticks(x)
    ax.set_xticklabels([r["run_name"] for r in rows], fontsize=8, rotation=90)
    ax.set_ylabel("Default-threshold accuracy")
    ax.set_ylim(0.0, 1.02)
    ax.set_title("Robustness to punctuation/formatting removal\n(sorted by accuracy drop -- largest drop at left)")
    ax.legend(fontsize=8, loc="lower left")

    path = os.path.join(output_dir, "robustness_comparison.png")
    fig.savefig(path)
    plt.close(fig)
    print(f"Saved: {path}")


def fig8_lora_vs_full_robustness(robustness_rows, output_dir):
    """Pairwise comparison: for each (backbone, LAPT checkpoint), how much
    does accuracy drop under full punctuation stripping for classifier-full
    vs classifier-LoRA. Controls for backbone/LAPT condition by only
    comparing within the same checkpoint."""
    by_base = {}
    for r in robustness_rows:
        name = r["run_name"]
        drop = fnum(r, "acc_drop_full_stripped")
        if drop is None:
            continue
        if name.endswith("_clsfull"):
            by_base.setdefault(name[: -len("_clsfull")], {})["full"] = drop
        elif name.endswith("_clslora"):
            by_base.setdefault(name[: -len("_clslora")], {})["lora"] = drop

    pairs = [(base, d["full"], d["lora"]) for base, d in sorted(by_base.items())
             if "full" in d and "lora" in d]
    if not pairs:
        print("SKIP fig8: no matched clsfull/clslora pairs found in robustness_results.csv")
        return

    fig, ax = plt.subplots(figsize=(max(10, len(pairs) * 0.6), 7))
    x = np.arange(len(pairs))
    width = 0.35
    full_drops = [p[1] for p in pairs]
    lora_drops = [p[2] for p in pairs]

    ax.bar(x - width / 2, full_drops, width=width, label="Classifier: full fine-tune", color="#55A868")
    ax.bar(x + width / 2, lora_drops, width=width, label="Classifier: LoRA", color="#C44E52")
    ax.axhline(0, color="black", linewidth=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels([p[0] for p in pairs], fontsize=8, rotation=90)
    ax.set_ylabel("Accuracy drop under full punctuation stripping")
    ax.set_title("Classifier-stage LoRA vs full fine-tune: robustness to punctuation removal\n")
    ax.legend(fontsize=8)

    path = os.path.join(output_dir, "lora_vs_full_robustness.png")
    fig.savefig(path)
    plt.close(fig)
    print(f"Saved: {path}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--all-results", default="all_results.csv")
    ap.add_argument("--bootstrap-ci", default="bootstrap_ci.csv")
    ap.add_argument("--results-dir", default="results_classifier")
    ap.add_argument("--tfidf-dir", default=None)
    ap.add_argument("--output-dir", default="figures")
    ap.add_argument("--roc-mbert-runs", nargs="+",
                     default=["mbert_no_lapt_clsfull", "mbert_full_lapt_clsfull", "mbert_lora_lapt_clsfull"],
                     help="mBERT run_names to overlay in the mBERT ROC figure")
    ap.add_argument("--roc-xlmr-runs", nargs="+",
                     default=["xlmr_no_lapt_clsfull", "xlmr_full_lapt_clsfull", "xlmr_lora_lapt_clsfull"],
                     help="XLM-R run_names to overlay in the XLM-R ROC figure")
    ap.add_argument("--prob-dist-runs", nargs="+",
                     default=["mbert_no_lapt_clsfull", "mbert_lora_lapt_clsfull",
                              "TFIDF_WordLevel_Baseline", "TFIDF_CharLevel_Baseline"],
                     help="Which run_names to show probability distributions for. Includes both "
                          "TF-IDF baselines by default so the threshold_unreachable finding has "
                          "its own visual explanation for both variants, not just the transformer runs.")
    ap.add_argument("--zoom-xmax", type=float, default=0.02,
                     help="ROC zoomed-panel x-axis max (FPR). Tighten if curves still overlap.")
    ap.add_argument("--zoom-ymin", type=float, default=0.98,
                     help="ROC zoomed-panel y-axis min (TPR). Raise if curves still overlap.")
    ap.add_argument("--robustness-results", default=None,
                     help="robustness_results.csv from run_all_robustness_checks.py -- "
                          "if provided, adds the punctuation-robustness comparison figure")
    args = ap.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    all_rows = load_csv(args.all_results)
    if all_rows is None:
        print(f"ERROR: {args.all_results} not found -- run consolidate_results.py first")
        return
    boot_rows = load_csv(args.bootstrap_ci) or []

    fig1_main_comparison(all_rows, args.output_dir)
    fig2_bootstrap_forest(boot_rows, args.output_dir)

    roc_groups = {
        "mBERT": args.roc_mbert_runs,
        "XLM-R": args.roc_xlmr_runs,
    }
    fig3_roc_curves(args.results_dir, roc_groups, args.output_dir, args.zoom_xmax, args.zoom_ymin)

    fig4_resource_efficiency(all_rows, args.output_dir)
    fig5_probability_distributions(args.results_dir, args.tfidf_dir, args.prob_dist_runs, args.output_dir)
    fig6_per_language(all_rows, args.results_dir, args.tfidf_dir, args.output_dir)

    if args.robustness_results:
        robustness_rows = load_csv(args.robustness_results)
        if robustness_rows is not None:
            fig7_robustness_comparison(robustness_rows, args.output_dir)
            fig8_lora_vs_full_robustness(robustness_rows, args.output_dir)
        else:
            print(f"SKIP fig7/fig8: {args.robustness_results} not found")

    print(f"\nAll figures saved to {args.output_dir}/")


if __name__ == "__main__":
    main()
