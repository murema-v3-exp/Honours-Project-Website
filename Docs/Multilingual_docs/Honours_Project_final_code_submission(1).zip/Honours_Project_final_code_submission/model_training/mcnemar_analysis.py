"""
Pairwise significance testing (McNemar's test) across the classifier
fine-tuning matrix

The standard test for comparing two classifiers on
the same test set (paired predictions), using only discordant pairs
(examples where the two models disagree). Doesn't need the independent
samples that raw accuracy comparison assumes and paired comparisons violate.

caveat: accuracies here cluster between 99.72% and 99.96%, i.e.
each model gets roughly 4-8 examples wrong out of ~2346. McNemar's power
comes entirely from discordant pairs, a subset of those tiny error
counts, so a comparison with few discordant pairs is underpowered. A
non-significant result means "not enough disagreement to tell," not
"confirmed no difference."

Runs at both the default (0.5) threshold and each run's own RAID-
calibrated threshold, since RAID accuracy showed more spread (96.8%-
99.7%).

Usage:
    python mcnemar_analysis.py --results-dir results_classifier
"""

import argparse
import csv
import os

from scipy.stats import binomtest, chi2

# The comparisons that matter to this project's research questions.
COMPARISON_GROUPS = {
    "LAPT vs No-LAPT (mBERT)": [
        ("mbert_no_lapt_clsfull", "mbert_full_lapt_clsfull"),
        ("mbert_no_lapt_clslora", "mbert_full_lapt_clslora"),
        ("mbert_no_lapt_clsfull", "mbert_lora_lapt_clsfull"),
        ("mbert_no_lapt_clslora", "mbert_lora_lapt_clslora"),
        # xho-only/zul-only LAPT vs the no-LAPT baseline (not just combined-language LAPT).
        ("mbert_no_lapt_clsfull", "mbert_full_lapt_xhoonly_clsfull"),
        ("mbert_no_lapt_clsfull", "mbert_full_lapt_zulonly_clsfull"),
        ("mbert_no_lapt_clslora", "mbert_full_lapt_xhoonly_clslora"),
        ("mbert_no_lapt_clslora", "mbert_full_lapt_zulonly_clslora"),
    ],
    "LAPT vs No-LAPT (XLM-R)": [
        ("xlmr_no_lapt_clsfull", "xlmr_full_lapt_clsfull"),
        ("xlmr_no_lapt_clslora", "xlmr_full_lapt_clslora"),
        ("xlmr_no_lapt_clsfull", "xlmr_lora_lapt_clsfull"),
        ("xlmr_no_lapt_clslora", "xlmr_lora_lapt_clslora"),
        # xho-only/zul-only LAPT vs baseline; xlmr_full_lapt_xhoonly_clsfull is the
        # paper's best RAID-calibrated result, tested here against baseline.
        ("xlmr_no_lapt_clsfull", "xlmr_full_lapt_xhoonly_clsfull"),
        ("xlmr_no_lapt_clsfull", "xlmr_full_lapt_zulonly_clsfull"),
        ("xlmr_no_lapt_clslora", "xlmr_full_lapt_xhoonly_clslora"),
        ("xlmr_no_lapt_clslora", "xlmr_full_lapt_zulonly_clslora"),
    ],
    "Full LAPT vs LoRA LAPT": [
        ("mbert_full_lapt_clsfull", "mbert_lora_lapt_clsfull"),
        ("mbert_full_lapt_clslora", "mbert_lora_lapt_clslora"),
        ("xlmr_full_lapt_clsfull", "xlmr_lora_lapt_clsfull"),
        ("xlmr_full_lapt_clslora", "xlmr_lora_lapt_clslora"),
    ],
    "Cross-lingual transfer (mBERT, full LAPT)": [
        ("mbert_full_lapt_clsfull", "mbert_full_lapt_xhoonly_clsfull"),
        ("mbert_full_lapt_clsfull", "mbert_full_lapt_zulonly_clsfull"),
        ("mbert_full_lapt_xhoonly_clsfull", "mbert_full_lapt_zulonly_clsfull"),
        # Same cross-lingual comparisons, classifier-LoRA versions.
        ("mbert_full_lapt_clslora", "mbert_full_lapt_xhoonly_clslora"),
        ("mbert_full_lapt_clslora", "mbert_full_lapt_zulonly_clslora"),
        ("mbert_full_lapt_xhoonly_clslora", "mbert_full_lapt_zulonly_clslora"),
    ],
    "Cross-lingual transfer (XLM-R, full LAPT)": [
        ("xlmr_full_lapt_clsfull", "xlmr_full_lapt_xhoonly_clsfull"),
        ("xlmr_full_lapt_clsfull", "xlmr_full_lapt_zulonly_clsfull"),
        ("xlmr_full_lapt_xhoonly_clsfull", "xlmr_full_lapt_zulonly_clsfull"),
        # Same cross-lingual comparisons, classifier-LoRA versions.
        ("xlmr_full_lapt_clslora", "xlmr_full_lapt_xhoonly_clslora"),
        ("xlmr_full_lapt_clslora", "xlmr_full_lapt_zulonly_clslora"),
        ("xlmr_full_lapt_xhoonly_clslora", "xlmr_full_lapt_zulonly_clslora"),
    ],
    "Backbone comparison (mBERT vs XLM-R, no LAPT)": [
        ("mbert_no_lapt_clsfull", "xlmr_no_lapt_clsfull"),
        ("mbert_no_lapt_clslora", "xlmr_no_lapt_clslora"),
    ],
    # Backbone comparison under each LAPT condition, not just no-LAPT.
    "Backbone comparison (mBERT vs XLM-R, with LAPT)": [
        ("mbert_full_lapt_clsfull", "xlmr_full_lapt_clsfull"),
        ("mbert_full_lapt_clslora", "xlmr_full_lapt_clslora"),
        ("mbert_lora_lapt_clsfull", "xlmr_lora_lapt_clsfull"),
        ("mbert_lora_lapt_clslora", "xlmr_lora_lapt_clslora"),
        ("mbert_full_lapt_xhoonly_clsfull", "xlmr_full_lapt_xhoonly_clsfull"),
        ("mbert_full_lapt_zulonly_clsfull", "xlmr_full_lapt_zulonly_clsfull"),
    ],
    "Classifier-stage LoRA vs Full (does it matter, per checkpoint)": [
        ("mbert_no_lapt_clsfull", "mbert_no_lapt_clslora"),
        ("mbert_full_lapt_clsfull", "mbert_full_lapt_clslora"),
        ("mbert_lora_lapt_clsfull", "mbert_lora_lapt_clslora"),
        ("xlmr_no_lapt_clsfull", "xlmr_no_lapt_clslora"),
        ("xlmr_full_lapt_clsfull", "xlmr_full_lapt_clslora"),
        ("xlmr_lora_lapt_clsfull", "xlmr_lora_lapt_clslora"),
        # xho-only/zul-only checkpoints too -- these matter to the punctuation-robustness
        # "9/10 pairs" finding, but hadn't been tested for baseline accuracy significance.
        ("mbert_full_lapt_xhoonly_clsfull", "mbert_full_lapt_xhoonly_clslora"),
        ("mbert_full_lapt_zulonly_clsfull", "mbert_full_lapt_zulonly_clslora"),
        ("xlmr_full_lapt_xhoonly_clsfull", "xlmr_full_lapt_xhoonly_clslora"),
        ("xlmr_full_lapt_zulonly_clsfull", "xlmr_full_lapt_zulonly_clslora"),
    ],
}


def load_predictions(results_dir, run_name):
    path = os.path.join(results_dir, run_name, "test_predictions.csv")
    if not os.path.exists(path):
        return None
    rows = []
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for r in reader:
            rows.append({
                "true_label": int(r["true_label"]),
                "prob": float(r["probability_machine"]),
                "pred_default": int(r["pred_default_0.5"]),
                "pred_raid": int(r["pred_raid_calibrated"]),
            })
    return rows


def mcnemar_test(correct_a, correct_b):
    """Returns (n01, n10, p_value). n01 = A wrong & B right, n10 = A right
    & B wrong -- agreements carry no information about which is better."""
    n01 = sum(1 for a, b in zip(correct_a, correct_b) if (not a) and b)
    n10 = sum(1 for a, b in zip(correct_a, correct_b) if a and (not b))
    n = n01 + n10
    if n == 0:
        return n01, n10, None  # zero discordant pairs
    if n < 25:
        # Exact binomial test 
        p = binomtest(min(n01, n10), n, 0.5).pvalue
    else:
        stat = (abs(n01 - n10) - 1) ** 2 / n
        p = 1 - chi2.cdf(stat, df=1)
    return n01, n10, p


def compare(results_dir, name_a, name_b, threshold_key):
    rows_a = load_predictions(results_dir, name_a)
    rows_b = load_predictions(results_dir, name_b)
    if rows_a is None or rows_b is None:
        missing = name_a if rows_a is None else name_b
        return {"error": f"test_predictions.csv not found for '{missing}'"}
    if len(rows_a) != len(rows_b):
        return {"error": f"length mismatch: {name_a}={len(rows_a)}, {name_b}={len(rows_b)}"}

    # Refuse to compare if these weren't run on the identical test set/order 
    labels_a = [r["true_label"] for r in rows_a]
    labels_b = [r["true_label"] for r in rows_b]
    if labels_a != labels_b:
        return {"error": f"true_label mismatch between {name_a} and {name_b} -- "
                          f"NOT the same test set/order, refusing to compare"}

    correct_a = [r["true_label"] == r[threshold_key] for r in rows_a]
    correct_b = [r["true_label"] == r[threshold_key] for r in rows_b]
    n01, n10, p = mcnemar_test(correct_a, correct_b)

    acc_a = sum(correct_a) / len(correct_a)
    acc_b = sum(correct_b) / len(correct_b)
    return {
        "n_discordant": n01 + n10,
        "n01": n01, "n10": n10,  # n01: A wrong/B right (B better on these); n10: A right/B wrong (A better)
        "p_value": p,
        "acc_a": acc_a, "acc_b": acc_b,
        "better": name_b if n01 > n10 else (name_a if n10 > n01 else "tie"),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results-dir", default="results_classifier")
    ap.add_argument("--alpha", type=float, default=0.05)
    ap.add_argument("--output", default="mcnemar_results.csv",
                     help="CSV output, one row per (comparison, threshold) -- for tables/graphs")
    args = ap.parse_args()

    all_tests = []
    for group_name, pairs in COMPARISON_GROUPS.items():
        for name_a, name_b in pairs:
            all_tests.append((group_name, name_a, name_b))

    n_bonferroni = len(all_tests) * 2  # x2 for default + RAID threshold, run separately below
    alpha_corrected = args.alpha / n_bonferroni
    print(f"Running {len(all_tests)} comparisons x 2 thresholds = {n_bonferroni} total tests")
    print(f"Bonferroni-corrected alpha: {args.alpha} / {n_bonferroni} = {alpha_corrected:.6f}\n")
    print("Reminder: check n_discordant before trusting any p-value here -- "
          "near-ceiling accuracy means many comparisons will have very few "
          "discordant pairs, i.e. low statistical power regardless of the "
          "p-value shown.\n")

    csv_rows = []
    for threshold_key, threshold_label in [("pred_default", "DEFAULT (0.5) threshold"),
                                             ("pred_raid", "RAID-calibrated threshold")]:
        print("=" * 78)
        print(f"  {threshold_label}")
        print("=" * 78)
        for group_name, name_a, name_b in all_tests:
            result = compare(args.results_dir, name_a, name_b, threshold_key)
            if "error" in result:
                print(f"[{group_name}] {name_a} vs {name_b}: SKIPPED -- {result['error']}")
                csv_rows.append({
                    "group": group_name, "model_a": name_a, "model_b": name_b,
                    "threshold": threshold_label, "error": result["error"],
                })
                continue
            sig_bonferroni = result["p_value"] is not None and result["p_value"] < alpha_corrected
            sig_uncorrected = result["p_value"] is not None and result["p_value"] < args.alpha
            sig = ""
            if sig_bonferroni:
                sig = " *** SIGNIFICANT (Bonferroni-corrected) ***"
            elif sig_uncorrected:
                sig = " (significant uncorrected, NOT after Bonferroni correction)"
            p_str = f"{result['p_value']:.4f}" if result["p_value"] is not None else "n/a (0 discordant pairs)"
            print(f"[{group_name}]")
            print(f"  {name_a} (acc={result['acc_a']:.4f}) vs {name_b} (acc={result['acc_b']:.4f})")
            print(f"  discordant pairs: {result['n_discordant']} (n01={result['n01']}, n10={result['n10']})  "
                  f"p={p_str}  better={result['better']}{sig}")

            csv_rows.append({
                "group": group_name, "model_a": name_a, "model_b": name_b,
                "threshold": threshold_label,
                "acc_a": result["acc_a"], "acc_b": result["acc_b"],
                "acc_diff": result["acc_b"] - result["acc_a"],
                "n_discordant": result["n_discordant"],
                "n01": result["n01"], "n10": result["n10"],
                "p_value": result["p_value"],
                "alpha_bonferroni": alpha_corrected,
                "significant_bonferroni": sig_bonferroni,
                "significant_uncorrected": sig_uncorrected,
                "better": result["better"],
                "error": "",
            })
        print()

    fieldnames = ["group", "model_a", "model_b", "threshold", "acc_a", "acc_b", "acc_diff",
                  "n_discordant", "n01", "n10", "p_value", "alpha_bonferroni",
                  "significant_bonferroni", "significant_uncorrected", "better", "error"]
    with open(args.output, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in csv_rows:
            writer.writerow({k: row.get(k, "") for k in fieldnames})
    print(f"Saved: {args.output}")


if __name__ == "__main__":
    main()
