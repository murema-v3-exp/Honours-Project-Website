"""
Driver for the full classifier fine-tuning matrix: 2 no-LAPT baselines +
every LAPT'd checkpoint from train_lapt.py, all through
finetune_classifier_bohb.py.

TF-IDF + Logistic Regression is not included: LAPT has no TF-IDF
analogue (no embeddings, no pretraining step to adapt).

Resumable: skips any run whose metrics.json already exists, so a re-run
after an interrupt only does the remaining work (at the level of "whole
runs already done", not mid-run checkpoints).

Usage:
    python run_all_classifier_finetuning.py \
        --train-file finetuning_data/train.jsonl --val-file finetuning_data/val.jsonl --test-file finetuning_data/test.jsonl \
        --lapt-results-dir results --output-dir results_classifier
"""

import argparse
import json
import os
import subprocess
import sys


def build_run_configs(lapt_results_dir):
    """Every (model, lapt_checkpoint_subdir_or_None) combination, each run
    TWICE -- once full classifier fine-tuning, once classifier-stage LoRA
    -- for 20 total runs."""
    base_configs = [
        # -- mBERT --
        {"model": "bert-base-multilingual-cased", "lapt_subdir": None,
         "run_name": "mbert_no_lapt"},
        {"model": "bert-base-multilingual-cased", "lapt_subdir": "LAPT_mbert_full",
         "run_name": "mbert_full_lapt"},
        {"model": "bert-base-multilingual-cased", "lapt_subdir": "LAPT_mbert_lora",
         "run_name": "mbert_lora_lapt"},
        {"model": "bert-base-multilingual-cased", "lapt_subdir": "LAPT_mbert_full_xhoonly",
         "run_name": "mbert_full_lapt_xhoonly"},
        {"model": "bert-base-multilingual-cased", "lapt_subdir": "LAPT_mbert_full_zulonly",
         "run_name": "mbert_full_lapt_zulonly"},
        # -- XLM-R --
        {"model": "xlm-roberta-base", "lapt_subdir": None,
         "run_name": "xlmr_no_lapt"},
        {"model": "xlm-roberta-base", "lapt_subdir": "LAPT_xlmr_full",
         "run_name": "xlmr_full_lapt"},
        {"model": "xlm-roberta-base", "lapt_subdir": "LAPT_xlmr_lora",
         "run_name": "xlmr_lora_lapt"},
        {"model": "xlm-roberta-base", "lapt_subdir": "LAPT_xlmr_full_xhoonly",
         "run_name": "xlmr_full_lapt_xhoonly"},
        {"model": "xlm-roberta-base", "lapt_subdir": "LAPT_xlmr_full_zulonly",
         "run_name": "xlmr_full_lapt_zulonly"},
    ]

    configs = []
    for base in base_configs:
        for classifier_lora in (False, True):
            cfg = dict(base)
            cfg["classifier_lora"] = classifier_lora
            cfg["run_name"] = base["run_name"] + ("_clslora" if classifier_lora else "_clsfull")
            configs.append(cfg)
    return configs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train-file", required=True)
    ap.add_argument("--val-file", required=True)
    ap.add_argument("--test-file", required=True)
    ap.add_argument("--lapt-results-dir", default="results",
                     help="Directory containing the LAPT_* subdirs from train_lapt.py runs")
    ap.add_argument("--output-dir", default="results_classifier")
    ap.add_argument("--n-trials", type=int, default=8)
    ap.add_argument("--max-epochs", type=int, default=10)
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--dry-run", action="store_true",
                     help="Print what would run without actually running it")
    args = ap.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    configs = build_run_configs(args.lapt_results_dir)

    print(f"{'='*70}\nClassifier fine-tuning matrix: {len(configs)} runs\n{'='*70}")

    results_summary = []
    for i, cfg in enumerate(configs, 1):
        run_output_dir = os.path.join(args.output_dir, cfg["run_name"])
        metrics_path = os.path.join(run_output_dir, "metrics.json")

        print(f"\n[{i}/{len(configs)}] {cfg['run_name']}")

        if os.path.exists(metrics_path):
            print(f"  SKIP -- {metrics_path} already exists (delete it to force a re-run)")
            with open(metrics_path) as f:
                results_summary.append((cfg["run_name"], json.load(f)))
            continue

        lapt_checkpoint = None
        if cfg["lapt_subdir"] is not None:
            lapt_checkpoint = os.path.join(args.lapt_results_dir, cfg["lapt_subdir"], "final")
            if not os.path.isdir(lapt_checkpoint):
                print(f"  SKIP -- {lapt_checkpoint} not found (has that LAPT run finished/downloaded yet?)")
                continue

        cmd = [
            sys.executable, "finetune_classifier_bohb.py",
            "--model", cfg["model"],
            "--train-file", args.train_file,
            "--val-file", args.val_file,
            "--test-file", args.test_file,
            "--output-dir", run_output_dir,
            "--n-trials", str(args.n_trials),
            "--max-epochs", str(args.max_epochs),
            "--batch-size", str(args.batch_size),
            "--lora", "true" if cfg["classifier_lora"] else "false",
        ]
        if lapt_checkpoint is not None:
            cmd += ["--lapt-checkpoint", lapt_checkpoint]

        print("  RUN:", " ".join(cmd))
        if args.dry_run:
            continue

        result = subprocess.run(cmd)
        if result.returncode != 0:
            print(f"  FAILED (exit code {result.returncode}) -- stopping here. "
                  f"Fix the issue and re-run this driver; completed runs will be skipped.")
            sys.exit(1)

        if os.path.exists(metrics_path):
            with open(metrics_path) as f:
                results_summary.append((cfg["run_name"], json.load(f)))

    if args.dry_run:
        print("\nDry run complete -- nothing was executed.")
        return

    print(f"\n{'='*70}\nSUMMARY\n{'='*70}")
    print(f"{'Run':<30} {'Test Acc':>10} {'Test F1':>10}")
    for name, metrics in results_summary:
        acc = metrics.get("test_results", {}).get("combined", {}).get("eval_accuracy", "n/a")
        f1 = metrics.get("test_results", {}).get("combined", {}).get("eval_f1", "n/a")
        acc_str = f"{acc:.4f}" if isinstance(acc, float) else str(acc)
        f1_str = f"{f1:.4f}" if isinstance(f1, float) else str(f1)
        print(f"{name:<30} {acc_str:>10} {f1_str:>10}")

    with open(os.path.join(args.output_dir, "summary.json"), "w") as f:
        json.dump({name: m for name, m in results_summary}, f, indent=2)
    print(f"\nFull summary saved to {os.path.join(args.output_dir, 'summary.json')}")


if __name__ == "__main__":
    main()
