"""
Runs evaluate_on_subset.py once for every transformer classifier
configuration in all_results.csv, so the length-confound check is
reported across the full model matrix, not one representative model.
Reads model name, LAPT checkpoint path, LoRA flag, and RAID threshold
directly from all_results.csv rather than requiring these to be retyped
by hand.

Skips TF-IDF rows automatically (evaluate_on_subset.py is HuggingFace-model
specific. TF-IDF baselines need evaluate_tfidf_on_subset.py instead).

After all runs complete, reads back each run's JSON output and consolidates them into a single CSV alongside
each model's original full-test-set accuracy from all_results.csv.

Usage:
    python run_all_length_matched_evals.py \
        --all-results all_results.csv \
        --results-dir results_classifier \
        --test-file length_matched_test.jsonl \
        --output-csv length_confound_results.csv
"""

import argparse
import csv
import json
import os
import subprocess
import sys

BACKBONE_MODEL_NAMES = {
    "mBERT": "bert-base-multilingual-cased",
    "XLM-R": "xlm-roberta-base",  # EDIT if a different XLM-R variant was used
}


def load_csv(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def fnum(row, key, default=None):
    v = row.get(key)
    if v is None or v == "":
        return default
    try:
        return float(v)
    except ValueError:
        return default


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--all-results", default="all_results.csv")
    ap.add_argument("--results-dir", default="results_classifier",
                     help="Directory containing each run's final/ checkpoint subfolder")
    ap.add_argument("--test-file", required=True, help="e.g. length_matched_test.jsonl")
    ap.add_argument("--eval-script", default="evaluate_on_subset.py")
    ap.add_argument("--output-csv", default="length_confound_results.csv",
                     help="Consolidated CSV summarising original vs length-matched accuracy for every run")
    ap.add_argument("--dry-run", action="store_true",
                     help="Print the commands that would run without actually running them")
    args = ap.parse_args()

    rows = load_csv(args.all_results)
    transformer_rows = [r for r in rows if r["backbone"] in BACKBONE_MODEL_NAMES]
    skipped = [r["run_name"] for r in rows if r["backbone"] not in BACKBONE_MODEL_NAMES]
    if skipped:
        print(f"Skipping {len(skipped)} non-transformer row(s) (e.g. TF-IDF baselines): {skipped}")

    print(f"Running length-matched evaluation for {len(transformer_rows)} configurations...\n")

    test_stem = os.path.basename(args.test_file).replace(".jsonl", "")
    failures = []
    csv_rows = []

    for r in transformer_rows:
        run_name = r["run_name"]
        model_name = BACKBONE_MODEL_NAMES[r["backbone"]]
        final_model_dir = os.path.join(args.results_dir, run_name, "final")
        lapt_checkpoint = r.get("lapt_checkpoint") or None
        is_lora = str(r.get("classifier_lora", "")).strip().lower() == "true"
        raid_threshold = r.get("raid_threshold")

        cmd = [sys.executable, args.eval_script,
               "--model", model_name,
               "--final-model-dir", final_model_dir,
               "--test-file", args.test_file,
               "--lora", "true" if is_lora else "false"]
        if lapt_checkpoint:
            cmd += ["--lapt-checkpoint", lapt_checkpoint]
        if raid_threshold:
            cmd += ["--raid-threshold", raid_threshold]

        print(f"[{run_name}] {' '.join(cmd)}")
        if args.dry_run:
            continue

        result = subprocess.run(cmd)
        if result.returncode != 0:
            print(f"  !! FAILED: {run_name} (exit code {result.returncode})")
            failures.append(run_name)
            print()
            continue
        print()

        # Read back this run's JSON output and pair it with this run's original
        # full-test-set numbers from all_results.csv, so both are in one row.
        result_path = f"{test_stem}_{run_name}_eval_result.json"
        if not os.path.exists(result_path):
            print(f"  !! Expected output {result_path} not found -- skipping from CSV")
            failures.append(run_name)
            continue

        with open(result_path) as f:
            eval_result = json.load(f)

        default_block = eval_result.get("default_threshold", {})
        raid_block = eval_result.get("raid_threshold_reapplied", {})

        orig_accuracy = fnum(r, "accuracy")
        orig_raid_accuracy = fnum(r, "raid_accuracy")
        matched_accuracy = default_block.get("accuracy")
        matched_raid_accuracy = raid_block.get("accuracy")

        csv_rows.append({
            "run_name": run_name,
            "backbone": r["backbone"],
            "lapt_status": r.get("lapt_status", ""),
            "lapt_language_scope": r.get("lapt_language_scope", ""),
            "classifier_method": r.get("classifier_method", ""),
            "n_examples_matched": eval_result.get("n_examples"),
            "orig_accuracy": orig_accuracy,
            "matched_accuracy": matched_accuracy,
            "accuracy_diff": (matched_accuracy - orig_accuracy)
                             if (matched_accuracy is not None and orig_accuracy is not None) else "",
            "orig_raid_accuracy": orig_raid_accuracy,
            "matched_raid_accuracy": matched_raid_accuracy,
            "raid_accuracy_diff": (matched_raid_accuracy - orig_raid_accuracy)
                                  if (matched_raid_accuracy is not None and orig_raid_accuracy is not None) else "",
            "matched_achieved_fpr": raid_block.get("achieved_fpr_on_this_subset", ""),
        })

    if args.dry_run:
        print("\nDry run complete -- no evaluations were actually executed.")
        return

    print(f"\nDone. {len(transformer_rows) - len(failures)}/{len(transformer_rows)} succeeded.")
    if failures:
        print(f"Failed runs: {failures}")

    if csv_rows:
        fieldnames = ["run_name", "backbone", "lapt_status", "lapt_language_scope", "classifier_method",
                      "n_examples_matched", "orig_accuracy", "matched_accuracy", "accuracy_diff",
                      "orig_raid_accuracy", "matched_raid_accuracy", "raid_accuracy_diff", "matched_achieved_fpr"]
        with open(args.output_csv, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(csv_rows)
        print(f"Saved consolidated results: {args.output_csv}")
    else:
        print("No successful runs to write to CSV.")


if __name__ == "__main__":
    main()
