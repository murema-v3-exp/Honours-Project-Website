"""
Runs both punctuation robustness checks (formatting-only-stripped, and
formatting+core-punctuation fully-stripped) across every classifier and
TF-IDF run, then merges the results with all_results.csv into one wide
table

Internally just calls run_all_subset_evaluations.py twice (once per test
file) and merges the two summaries with the original results, rather
than duplicating its model-loading logic.

Usage:
    python run_all_robustness_checks.py \
        --all-results all_results.csv \
        --results-dir results_classifier --tfidf-dir results_tfidf \
        --formatting-stripped-test finetuning_data/test_formatting_stripped.jsonl \
        --full-stripped-test finetuning_data/test_full_stripped.jsonl \
        --output robustness_results.csv
"""

import argparse
import csv
import os
import subprocess
import sys


def run_subset_eval(all_results, results_dir, tfidf_dir, test_file, output, batch_size, max_length):
    cmd = [
        sys.executable, "run_all_subset_evaluations.py",
        "--all-results", all_results,
        "--results-dir", results_dir,
        "--test-file", test_file,
        "--output", output,
        "--batch-size", str(batch_size),
        "--max-length", str(max_length),
    ]
    if tfidf_dir:
        cmd += ["--tfidf-dir", tfidf_dir]
    print(f"\n{'='*70}\nRunning: {' '.join(cmd)}\n{'='*70}")
    result = subprocess.run(cmd)
    if result.returncode != 0:
        print(f"WARNING: run_all_subset_evaluations.py exited with code {result.returncode} "
              f"for {test_file} -- partial results (if any) will still be merged below.")


def load_csv_by_run_name(path):
    if not os.path.exists(path):
        print(f"WARNING: {path} not found -- that check's columns will be empty in the merged output")
        return {}
    with open(path, newline="") as f:
        return {row["run_name"]: row for row in csv.DictReader(f)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--all-results", default="all_results.csv")
    ap.add_argument("--results-dir", default="results_classifier")
    ap.add_argument("--tfidf-dir", default=None)
    ap.add_argument("--formatting-stripped-test", required=True)
    ap.add_argument("--full-stripped-test", required=True)
    ap.add_argument("--output", default="robustness_results.csv")
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--max-length", type=int, default=256)
    ap.add_argument("--skip-runs", action="store_true",
                     help="Skip actually running the checks -- just re-merge existing "
                          "subset_eval_formatting.csv / subset_eval_full_stripped.csv "
                          "(useful if you already ran them and just want to re-merge)")
    args = ap.parse_args()

    formatting_summary = "subset_eval_formatting.csv"
    full_summary = "subset_eval_full_stripped.csv"

    if not args.skip_runs:
        run_subset_eval(args.all_results, args.results_dir, args.tfidf_dir,
                         args.formatting_stripped_test, formatting_summary,
                         args.batch_size, args.max_length)
        run_subset_eval(args.all_results, args.results_dir, args.tfidf_dir,
                         args.full_stripped_test, full_summary,
                         args.batch_size, args.max_length)

    original = load_csv_by_run_name(args.all_results)
    formatting = load_csv_by_run_name(formatting_summary)
    full = load_csv_by_run_name(full_summary)

    all_run_names = sorted(set(original) | set(formatting) | set(full))

    fieldnames = [
        "run_name", "backbone", "lapt_status", "lapt_language_scope", "classifier_method",
        "orig_accuracy", "orig_raid_accuracy",
        "formatting_stripped_accuracy", "formatting_stripped_recall", "formatting_stripped_raid_accuracy",
        "full_stripped_accuracy", "full_stripped_recall", "full_stripped_raid_accuracy",
        "acc_drop_full_stripped",  # orig_accuracy - full_stripped_accuracy, the headline robustness number
    ]

    with open(args.output, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for run_name in all_run_names:
            o = original.get(run_name, {})
            fm = formatting.get(run_name, {})
            fu = full.get(run_name, {})

            row = {
                "run_name": run_name,
                "backbone": o.get("backbone", ""),
                "lapt_status": o.get("lapt_status", ""),
                "lapt_language_scope": o.get("lapt_language_scope", ""),
                "classifier_method": o.get("classifier_method", ""),
                "orig_accuracy": o.get("accuracy", ""),
                "orig_raid_accuracy": o.get("raid_accuracy", ""),
                "formatting_stripped_accuracy": fm.get("subset_default_accuracy", ""),
                "formatting_stripped_recall": fm.get("subset_default_recall", ""),
                "formatting_stripped_raid_accuracy": fm.get("subset_raid_accuracy", ""),
                "full_stripped_accuracy": fu.get("subset_default_accuracy", ""),
                "full_stripped_recall": fu.get("subset_default_recall", ""),
                "full_stripped_raid_accuracy": fu.get("subset_raid_accuracy", ""),
            }
            try:
                row["acc_drop_full_stripped"] = float(o.get("accuracy", 0)) - float(fu.get("subset_default_accuracy", 0))
            except (ValueError, TypeError):
                row["acc_drop_full_stripped"] = ""
            writer.writerow(row)

    print(f"\nSaved: {args.output} ({len(all_run_names)} runs)")


if __name__ == "__main__":
    main()
