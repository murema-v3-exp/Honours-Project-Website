"""
Runs evaluate_on_subset.py (transformers) or evaluate_tfidf_on_subset.py
(TF-IDF) across every completed run, using the config (model, LAPT
checkpoint, classifier-LoRA flag, RAID threshold) already recorded in
all_results.csv 

TF-IDF coverage requires tfidf_baseline.py to have saved a model.joblib

Usage:
    python run_all_subset_evaluations.py \
        --all-results all_results.csv \
        --results-dir results_classifier \
        --tfidf-dir results_tfidf \
        --test-file finetuning_data/test_full_stripped.jsonl \
        --output subset_eval_summary.csv
"""

import argparse
import csv
import json
import os
import subprocess
import sys

BACKBONE_TO_MODEL = {
    "mBERT": "bert-base-multilingual-cased",
    "XLM-R": "xlm-roberta-base",
}


def run_transformer_eval(row, args):
    run_name = row["run_name"]
    model = BACKBONE_TO_MODEL[row["backbone"]]
    lapt_checkpoint = row.get("lapt_checkpoint") or None
    classifier_lora = str(row.get("classifier_lora", "")).lower() == "true"
    raid_threshold = row.get("raid_threshold")
    final_dir = os.path.join(args.results_dir, run_name, "final")

    if not os.path.isdir(final_dir):
        print(f"SKIP {run_name}: {final_dir} not found")
        return None

    cmd = [
        sys.executable, "evaluate_on_subset.py",
        "--model", model,
        "--final-model-dir", final_dir,
        "--test-file", args.test_file,
        "--batch-size", str(args.batch_size),
        "--max-length", str(args.max_length),
        "--lora", "true" if classifier_lora else "false",
    ]
    if lapt_checkpoint:
        cmd += ["--lapt-checkpoint", lapt_checkpoint]
    if raid_threshold:
        cmd += ["--raid-threshold", raid_threshold]

    print(f"\n[{run_name}] {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"  FAILED: {result.stderr[-500:]}")
        return {"run_name": run_name, "error": "failed"}

    result_path = args.test_file.replace(".jsonl", "") + "_eval_result.json"
    if not os.path.exists(result_path):
        print(f"  WARNING: expected output {result_path} not found")
        return None
    with open(result_path) as f:
        eval_result = json.load(f)
    print(f"  Done: default_acc={eval_result['default_threshold']['accuracy']:.4f}")
    return build_summary_row(run_name, row, eval_result)


def run_tfidf_eval(row, args):
    run_name = row["run_name"]
    if not args.tfidf_dir:
        print(f"SKIP {run_name}: --tfidf-dir not provided")
        return None
    model_path = os.path.join(args.tfidf_dir, run_name, "model.joblib")
    if not os.path.exists(model_path):
        print(f"SKIP {run_name}: {model_path} not found -- was this TF-IDF baseline "
              f"run with the model.joblib persistence step? Older runs predate it.")
        return None

    raid_threshold = row.get("raid_threshold")
    cmd = [sys.executable, "evaluate_tfidf_on_subset.py",
           "--model-path", model_path, "--test-file", args.test_file]
    if raid_threshold:
        cmd += ["--raid-threshold", raid_threshold]

    print(f"\n[{run_name}] {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"  FAILED: {result.stderr[-500:]}")
        return {"run_name": run_name, "error": "failed"}

    result_path = args.test_file.replace(".jsonl", "") + "_tfidf_eval_result.json"
    if not os.path.exists(result_path):
        print(f"  WARNING: expected output {result_path} not found")
        return None
    with open(result_path) as f:
        eval_result = json.load(f)
    print(f"  Done: default_acc={eval_result['default_threshold']['accuracy']:.4f}")
    return build_summary_row(run_name, row, eval_result)


def build_summary_row(run_name, row, eval_result):
    return {
        "run_name": run_name,
        "orig_accuracy": row.get("accuracy"),
        "orig_raid_accuracy": row.get("raid_accuracy"),
        "subset_default_accuracy": eval_result["default_threshold"]["accuracy"],
        "subset_default_recall": eval_result["default_threshold"].get("recall"),
        "subset_raid_accuracy": eval_result.get("raid_threshold_reapplied", {}).get("accuracy"),
        "subset_raid_achieved_fpr": eval_result.get("raid_threshold_reapplied", {}).get("achieved_fpr_on_this_subset"),
        "error": "",
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--all-results", default="all_results.csv")
    ap.add_argument("--results-dir", default="results_classifier")
    ap.add_argument("--tfidf-dir", default=None)
    ap.add_argument("--test-file", required=True,
                     help="The robustness-check test file to evaluate every model against")
    ap.add_argument("--output", default="subset_eval_summary.csv")
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--max-length", type=int, default=256)
    args = ap.parse_args()

    with open(args.all_results, newline="") as f:
        rows = list(csv.DictReader(f))

    summary_rows = []
    for row in rows:
        run_name = row["run_name"]
        backbone = row.get("backbone", "")

        if backbone in BACKBONE_TO_MODEL:
            result = run_transformer_eval(row, args)
        elif backbone.startswith("TF-IDF"):
            result = run_tfidf_eval(row, args)
        else:
            print(f"SKIP {run_name}: unrecognized backbone '{backbone}'")
            result = None

        if result is not None:
            result.setdefault("orig_accuracy", row.get("accuracy"))
            result.setdefault("orig_raid_accuracy", row.get("raid_accuracy"))
            summary_rows.append(result)

    fieldnames = ["run_name", "orig_accuracy", "orig_raid_accuracy", "subset_default_accuracy",
                  "subset_default_recall", "subset_raid_accuracy", "subset_raid_achieved_fpr", "error"]
    with open(args.output, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in summary_rows:
            writer.writerow({k: row.get(k, "") for k in fieldnames})

    print(f"\nSaved: {args.output} ({len(summary_rows)} runs)")


if __name__ == "__main__":
    main()
