"""
TF-IDF counterpart to run_all_length_matched_evals.py, calling the actual
evaluate_tfidf_on_subset.py via subprocess for
each TF-IDF baseline, so the two scripts stay in sync.

Reads each TF-IDF baseline's model path and original RAID threshold
directly from all_results.csv, to avoid retyping precise threshold
values by hand.

Writes a CSV with the same column names as run_all_length_matched_evals.py's
output, so the two can be concatenated for full 22-model coverage.

TF-IDF's original
RAID-calibrated threshold search was unreachable.
Reapplying that "threshold" to a new subset doesn't carry the same clean
interpretation it does for the transformer models. This script still
runs it for consistency but flags every row's inherited-unreachable
status (raid_threshold_inherited_unreachable column). Treat
default-threshold accuracy as the more meaningful comparison for TF-IDF.

Assumptions:
  - TF-IDF rows have backbone values "TF-IDF-word" and "TF-IDF-char"
    (matching generate_graphs.py's BACKBONE_COLORS keys)
  - Each run's saved pipeline is at {tfidf-dir}/{run_name}/model.joblib

Usage:
    python run_all_tfidf_matched_evals.py \
        --all-results all_results.csv \
        --tfidf-dir results_tfidf \
        --test-file repetition_matched_test.jsonl \
        --output-csv tfidf_repetition_confound_results.csv
"""

import argparse
import csv
import json
import os
import subprocess
import sys

TFIDF_BACKBONE_VALUES = {"TF-IDF-word", "TF-IDF-char"}


def load_csv(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def fnum(row, key, default=None):
    v = row.get(key)
    if v is None or v == "":
        return default
    try:
        return float(v)
    except ValueError:
        return default


def fbool(row, key):
    return str(row.get(key, "")).strip().lower() == "true"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--all-results", default="all_results.csv")
    ap.add_argument("--tfidf-dir", default="results_tfidf",
                     help="Directory containing each TF-IDF run's model.joblib subfolder")
    ap.add_argument("--test-file", required=True, help="Matched-subset test file (JSONL)")
    ap.add_argument("--eval-script", default="evaluate_tfidf_on_subset.py")
    ap.add_argument("--output-csv", default="tfidf_matched_results.csv")
    ap.add_argument("--dry-run", action="store_true",
                     help="Print the commands that would run without actually running them")
    args = ap.parse_args()

    rows = load_csv(args.all_results)
    tfidf_rows = [r for r in rows if r["backbone"] in TFIDF_BACKBONE_VALUES]
    print(f"Found {len(tfidf_rows)} TF-IDF row(s) in {args.all_results}: "
          f"{[r['run_name'] for r in tfidf_rows]}")
    if not tfidf_rows:
        print(f"No rows with backbone in {TFIDF_BACKBONE_VALUES} found -- "
              f"check TFIDF_BACKBONE_VALUES matches your actual all_results.csv values.")
        return

    test_stem = os.path.basename(args.test_file).replace(".jsonl", "")
    failures = []
    csv_rows = []

    for r in tfidf_rows:
        run_name = r["run_name"]
        model_path = os.path.join(args.tfidf_dir, run_name, "model.joblib")
        raid_threshold = r.get("raid_threshold")
        inherited_unreachable = fbool(r, "raid_threshold_unreachable")

        cmd = [sys.executable, args.eval_script,
               "--model-path", model_path,
               "--test-file", args.test_file]
        if raid_threshold:
            cmd += ["--raid-threshold", raid_threshold]

        print(f"[{run_name}] {' '.join(cmd)}")
        if inherited_unreachable:
            print(f"  NOTE: original RAID threshold for this run was UNREACHABLE (chance-level) "
                  f"-- the RAID-calibrated result below inherits that caveat.")
        if args.dry_run:
            continue

        result = subprocess.run(cmd)
        if result.returncode != 0:
            print(f"  !! FAILED: {run_name} (exit code {result.returncode})")
            failures.append(run_name)
            print()
            continue
        print()

        result_path = f"{test_stem}_{run_name}_tfidf_eval_result.json"
        if not os.path.exists(result_path):
            print(f"  !! Expected output {result_path} not found -- skipping from CSV")
            failures.append(run_name)
            continue

        with open(result_path) as f:
            eval_result = json.load(f)

        default_block = eval_result.get("default_threshold", {})
        raid_block = eval_result.get("raid_threshold_reapplied", {})

        orig_accuracy = fnum(r, "accuracy")
        orig_raid_accuracy = fnum(r, "raid_accuracy")
        matched_accuracy = default_block.get("accuracy")
        matched_raid_accuracy = raid_block.get("accuracy")

        csv_rows.append({
            "run_name": run_name,
            "backbone": r["backbone"],
            "lapt_status": r.get("lapt_status", ""),
            "lapt_language_scope": r.get("lapt_language_scope", ""),
            "classifier_method": r.get("classifier_method", ""),
            "n_examples_matched": eval_result.get("n_examples"),
            "orig_accuracy": orig_accuracy,
            "matched_accuracy": matched_accuracy,
            "accuracy_diff": (matched_accuracy - orig_accuracy)
                             if (matched_accuracy is not None and orig_accuracy is not None) else "",
            "orig_raid_accuracy": orig_raid_accuracy,
            "matched_raid_accuracy": matched_raid_accuracy,
            "raid_accuracy_diff": (matched_raid_accuracy - orig_raid_accuracy)
                                  if (matched_raid_accuracy is not None and orig_raid_accuracy is not None) else "",
            "matched_achieved_fpr": raid_block.get("achieved_fpr_on_this_subset", ""),
            "raid_threshold_inherited_unreachable": inherited_unreachable,
        })

    if args.dry_run:
        print("\nDry run complete -- no evaluations were actually executed.")
        return

    print(f"\nDone. {len(tfidf_rows) - len(failures)}/{len(tfidf_rows)} succeeded.")
    if failures:
        print(f"Failed runs: {failures}")

    if csv_rows:
        # Same core fieldnames as run_all_length_matched_evals.py's output, plus one
        # TF-IDF-specific caveat column, so the two CSVs align for concatenation.
        fieldnames = ["run_name", "backbone", "lapt_status", "lapt_language_scope", "classifier_method",
                      "n_examples_matched", "orig_accuracy", "matched_accuracy", "accuracy_diff",
                      "orig_raid_accuracy", "matched_raid_accuracy", "raid_accuracy_diff",
                      "matched_achieved_fpr", "raid_threshold_inherited_unreachable"]
        with open(args.output_csv, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(csv_rows)
        print(f"Saved consolidated results: {args.output_csv}")
    else:
        print("No successful runs to write to CSV.")


if __name__ == "__main__":
    main()
