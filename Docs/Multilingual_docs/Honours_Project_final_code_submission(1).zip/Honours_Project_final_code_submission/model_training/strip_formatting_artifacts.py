"""
Neutralizes formatting/structural artifacts identified as a confound

Optionally (--strip-core-punctuation), also removes commas, colons, and
semicolons specifically, not all punctuation.

Same purpose as build_length_matched_test.py's length control, applied to
a different confound: produce a test set where the artifact is
neutralized in both classes uniformly, then re-evaluate already-trained
models against it with evaluate_on_subset.py.

Usage:
    python strip_formatting_artifacts.py --input test.jsonl --output test_formatting_stripped.jsonl
    python strip_formatting_artifacts.py --input test.jsonl --output test_full_stripped.jsonl --strip-core-punctuation
"""

import argparse
import json
import re


LEADING_LIST_MARKER = re.compile(r"^\s*(\d+[\.\)]|[-*\u2022])\s*")


def normalize_text(text, strip_core_punctuation=False):
    # Collapse newlines into spaces 
    text = text.replace("\n", " ")

    # Strip a leading list marker (numbered "1."/"1)" or bullet "-"/"*"/ "\u2022") 
    text = LEADING_LIST_MARKER.sub("", text)

    # Markdown-style emphasis/header chars: asterisks ~8x more common in
    # machine text, hashes present almost exclusively there.
    text = text.replace("*", "").replace("#", "")

    if strip_core_punctuation:
        # Only these three carry real residual signal
        text = text.replace(",", "").replace(";", "").replace(":", "")

    text = re.sub(r"\s+", " ", text).strip()
    return text


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", default=None)
    ap.add_argument("--strip-core-punctuation", action="store_true",
                     help="Also remove commas, colons, semicolons -- see module docstring")
    args = ap.parse_args()
    output = args.output or args.input.replace(".jsonl", "_formatting_stripped.jsonl")

    n = 0
    with open(args.input, encoding="utf-8") as fin, open(output, "w", encoding="utf-8") as fout:
        for line in fin:
            line = line.strip()
            if not line:
                continue
            row = json.loads(line)
            row["text"] = normalize_text(row["text"], args.strip_core_punctuation)
            fout.write(json.dumps(row, ensure_ascii=False) + "\n")
            n += 1

    mode = "formatting + core punctuation (commas/colons/semicolons)" if args.strip_core_punctuation else "formatting only"
    print(f"Normalized {n} examples ({mode}) -> {output}")


if __name__ == "__main__":
    main()
