import json
from pathlib import Path
import time

import joblib
import numpy as np
import pandas as pd
from scipy.stats import loguniform
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import PredefinedSplit, RandomizedSearchCV
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    classification_report,
    confusion_matrix,
    roc_auc_score,
    roc_curve,
)


# Configuration

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "finetuning_data"
RESULTS_ROOT = PROJECT_ROOT / "results_tfidf"

TRAIN_FILE = DATA_DIR / "train.jsonl"
VALID_FILE = DATA_DIR / "val.jsonl"  
TEST_FILE = DATA_DIR / "test.jsonl"

SEED = 42
N_SEARCH_ITER = 20  # cheap here (seconds/trial), so generous vs the transformer scripts' 8-trial budget

# Labels are the strings "human"/"machine" in the dataset. This mapping matches the transformer
# scripts' convention (0=human, 1=machine) so results are comparable.
LABEL2ID = {"human": 0, "machine": 1}
ID2LABEL = {0: "Human", 1: "Machine"}


# Load JSONL

def load_jsonl(filename):
    texts = []
    labels = []
    langs = []

    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            item = json.loads(line)
            texts.append(item["text"])
            labels.append(LABEL2ID[item["label"]])
            langs.append(item["lang"])

    return texts, labels, langs



# One full baseline run: search -> refit on train-only -> evaluate -> save

def calibrate_threshold_for_fpr(val_probs, val_labels, target_fpr=0.05):
    """RAID protocol: calibrate on VAL, apply to test. Same logic as
    finetune_classifier_bohb.py's version, kept for consistency across
    the TF-IDF/mBERT/XLM-R comparison."""
    fpr, tpr, thresholds = roc_curve(val_labels, val_probs)
    idx = np.argmin(np.abs(fpr - target_fpr))
    threshold = float(thresholds[idx])
    achieved_fpr = float(fpr[idx])
    unreachable = threshold > 1.0  # sklearn's synthetic max(score)+1 entry
    if unreachable:
        threshold = 1.0
    return threshold, achieved_fpr, unreachable


def run_tfidf_baseline(
    variant_name,
    param_distributions,
    train_texts, train_labels, train_langs,
    val_texts, val_labels,
    test_texts, test_labels, test_langs,
):
    print("\n" + "#" * 70)
    print(f"# {variant_name}")
    print("#" * 70)

    results_dir = RESULTS_ROOT / variant_name
    results_dir.mkdir(parents=True, exist_ok=True)

    # Hyperparameter search. Not k-fold CV.
    search_texts = train_texts + val_texts
    search_labels = train_labels + val_labels
    test_fold = [-1] * len(train_texts) + [0] * len(val_texts)  # -1 = never used for validation
    ps = PredefinedSplit(test_fold)

    pipeline = Pipeline([
        ("tfidf", TfidfVectorizer(lowercase=True)),
        ("clf", LogisticRegression(max_iter=2000, random_state=SEED, class_weight="balanced")),
    ])

    search = RandomizedSearchCV(
        pipeline,
        param_distributions=param_distributions,
        n_iter=N_SEARCH_ITER,
        cv=ps,
        scoring="f1",
        random_state=SEED,
        n_jobs=-1,
        refit=False,  # refit manually below, train-only 
        verbose=1,
    )
    search_start = time.time()
    search.fit(search_texts, search_labels)
    search_wall_clock_seconds = time.time() - search_start

    best_params = search.best_params_
    best_val_f1 = search.best_score_
    print(f"\nBest params ({variant_name}): {best_params}")
    print(f"Best val F1: {best_val_f1:.4f}")
    print(f"Search wall-clock: {search_wall_clock_seconds:.1f}s ({N_SEARCH_ITER} trials)")

    # refit=False above is deliberate: RandomizedSearchCV's default refit trains on
    # search_texts (train+val combined), which would leak val data into the final
    # fit. Refitting manually on train_texts only keeps this comparable to the
    # transformer baselines, which use val purely for selection.
    final_pipeline = Pipeline([
        ("tfidf", TfidfVectorizer(lowercase=True)),
        ("clf", LogisticRegression(max_iter=2000, random_state=SEED, class_weight="balanced")),
    ])
    final_pipeline.set_params(**best_params)
    refit_start = time.time()
    final_pipeline.fit(train_texts, train_labels)
    refit_wall_clock_seconds = time.time() - refit_start
    total_wall_clock_seconds = search_wall_clock_seconds + refit_wall_clock_seconds
    print(f"Final refit (train-only) wall-clock: {refit_wall_clock_seconds:.1f}s")

    # Persist the fitted pipeline (vectorizer + classifier together) so it can be
    # reloaded later for post-hoc checks against a different test file, without retraining.
    model_path = results_dir / "model.joblib"
    joblib.dump(final_pipeline, model_path)
    print(f"Saved fitted pipeline: {model_path}")

    vectorizer = final_pipeline.named_steps["tfidf"]
    model = final_pipeline.named_steps["clf"]

    
    # Validation (train-only-fit model, on val
    val_pred = final_pipeline.predict(val_texts)
    print("\n" + "=" * 60)
    print("Validation (train-only-fit model)")
    print("=" * 60)
    print(f"Accuracy: {accuracy_score(val_labels, val_pred):.4f}")


    # Test
    test_pred = final_pipeline.predict(test_texts)
    test_proba = final_pipeline.predict_proba(test_texts)[:, 1] 

    accuracy = accuracy_score(test_labels, test_pred)
    precision, recall, f1, _ = precision_recall_fscore_support(
        test_labels, test_pred, average="binary", pos_label=1,
    )
    auc = roc_auc_score(test_labels, test_proba)

    # RAID-style evaluation: calibrate threshold to 5% FPR on val (never test),
    # apply to test. Same protocol and fields as finetune_classifier_bohb.py.
    val_proba = final_pipeline.predict_proba(val_texts)[:, 1]
    val_labels_arr = np.array(val_labels)
    raid_threshold, val_achieved_fpr, threshold_unreachable = calibrate_threshold_for_fpr(
        val_proba, val_labels_arr, target_fpr=0.05
    )
    print(f"\nRAID-style threshold calibration: target FPR=5%, calibrated on val, "
          f"threshold={raid_threshold:.4f}, actual val FPR={val_achieved_fpr:.4f}"
          f"{' (UNREACHABLE)' if threshold_unreachable else ''}")

    test_labels_arr = np.array(test_labels)
    test_pred_raid = (test_proba >= raid_threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(test_labels_arr, test_pred, labels=[0, 1]).ravel()
    raid_tn, raid_fp, raid_fn, raid_tp = confusion_matrix(test_labels_arr, test_pred_raid, labels=[0, 1]).ravel()
    test_achieved_fpr_at_raid_threshold = raid_fp / (raid_fp + raid_tn) if (raid_fp + raid_tn) > 0 else None

    raid_style_results = {
        "target_fpr": 0.05,
        "threshold": raid_threshold,
        "threshold_unreachable": threshold_unreachable,
        "val_achieved_fpr_at_threshold": val_achieved_fpr,
        "test_achieved_fpr_at_threshold": test_achieved_fpr_at_raid_threshold,
        "test_accuracy_at_calibrated_threshold": accuracy_score(test_labels_arr, test_pred_raid),
        "test_confusion_matrix_at_calibrated_threshold": {
            "tn": int(raid_tn), "fp": int(raid_fp), "fn": int(raid_fn), "tp": int(raid_tp)
        },
    }

    # Save ROC curve + raw per-example predictions in the same format as
    # finetune_classifier_bohb.py, so later analysis code can load either identically.
    fpr_curve, tpr_curve, roc_thresholds = roc_curve(test_labels_arr, test_proba)
    roc_thresholds_safe = np.clip(roc_thresholds, a_min=None, a_max=1.0)
    with open(results_dir / "roc_curve.json", "w") as f:
        json.dump({"fpr": fpr_curve.tolist(), "tpr": tpr_curve.tolist(),
                    "thresholds": roc_thresholds_safe.tolist()}, f)

    import csv
    with open(results_dir / "test_predictions.csv", "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["true_label", "probability_machine", "language", "pred_default_0.5", "pred_raid_calibrated"])
        for prob, label, lang, pred_d, pred_r in zip(test_proba, test_labels_arr, test_langs, test_pred, test_pred_raid):
            writer.writerow([int(label), float(prob), lang, int(pred_d), int(pred_r)])

    print("\n" + "=" * 60)
    print("Test Results")
    print("=" * 60)
    print(f"Accuracy : {accuracy:.4f}")
    print(f"Precision: {precision:.4f}")
    print(f"Recall   : {recall:.4f}")
    print(f"F1       : {f1:.4f}")
    print(f"ROC-AUC  : {auc:.4f}")

    print("\nClassification Report\n")
    report = classification_report(test_labels, test_pred, target_names=["Human", "Machine"], digits=4)
    print(report)

    print("Confusion Matrix\n")
    cm = confusion_matrix(test_labels, test_pred)
    print(cm)

  
    # Per-language metrics
    print("\n" + "=" * 60)
    print("Per-language Results")
    print("=" * 60)

    test_labels_arr = np.array(test_labels)
    test_pred_arr = np.array(test_pred)
    test_langs_arr = np.array(test_langs)

    language_results = []
    for lang in sorted(set(test_langs)):
        mask = test_langs_arr == lang
        y_true = test_labels_arr[mask]
        y_pred = test_pred_arr[mask]

        acc = accuracy_score(y_true, y_pred)
        p, r, f, _ = precision_recall_fscore_support(
            y_true, y_pred, average="binary", pos_label=1, zero_division=0,
        )

        print(f"{lang:>3} | Accuracy={acc:.4f} Precision={p:.4f} Recall={r:.4f} F1={f:.4f}")
        language_results.append({
            "language": lang, "accuracy": acc, "precision": p, "recall": r, "f1": f,
        })


    # Most informative features
    feature_names = np.array(vectorizer.get_feature_names_out())
    weights = model.coef_[0]

    top_machine = np.argsort(weights)[-30:][::-1]
    top_human = np.argsort(weights)[:30]

    print("\n" + "=" * 60)
    print("Top HUMAN features")
    print("=" * 60)
    for idx in top_human:
        print(f"{feature_names[idx]!r:30s}{weights[idx]: .4f}")

    print("\n" + "=" * 60)
    print("Top MACHINE features")
    print("=" * 60)
    for idx in top_machine:
        print(f"{feature_names[idx]!r:30s}{weights[idx]: .4f}")

    # Save results, matching finetune_classifier_bohb.py's conventions.
    metrics = {
        "accuracy": accuracy, "precision": precision, "recall": recall, "f1": f1, "roc_auc": auc,
        "total_wall_clock_seconds": total_wall_clock_seconds,
    }
    with open(results_dir / "metrics.json", "w") as f:
        json.dump(metrics, f, indent=4)

    with open(results_dir / "classification_report.txt", "w") as f:
        f.write(report)

    pd.DataFrame(language_results).to_csv(results_dir / "per_language_results.csv", index=False)

    baseline_config = {
        "model": f"TF-IDF ({variant_name}) + Logistic Regression",
        "task": "human_machine_detection",
        "dataset": "FineWeb-2 + Gemma",
        "language": sorted(set(train_langs) | set(test_langs)),
        "search": {
            "method": "RandomizedSearchCV, validated on the fixed val set via PredefinedSplit "
                      "(not k-fold, to match the transformer baselines' model-selection convention)",
            "n_iter": N_SEARCH_ITER,
            "best_params": {k: (list(v) if isinstance(v, tuple) else v) for k, v in best_params.items()},
            "best_val_f1": best_val_f1,
        },
        "resource_usage": {
            "search_wall_clock_seconds": search_wall_clock_seconds,
            "refit_wall_clock_seconds": refit_wall_clock_seconds,
            "total_wall_clock_seconds": total_wall_clock_seconds,
        },
        "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
        "raid_style_evaluation": raid_style_results,
        "results": {
            "test_accuracy": round(accuracy, 4),
            "test_f1": round(f1, 4),
            "roc_auc": round(auc, 4),
        },
        "seed": SEED,
    }
    with open(results_dir / "baseline_config.json", "w") as f:
        json.dump(baseline_config, f, indent=2)

    print(f"\nSaved results to {results_dir}")
    return metrics


if __name__ == "__main__":
    train_texts, train_labels, train_langs = load_jsonl(TRAIN_FILE)
    val_texts, val_labels, val_langs = load_jsonl(VALID_FILE)
    test_texts, test_labels, test_langs = load_jsonl(TEST_FILE)

    print(f"Train: {len(train_texts)}, Val: {len(val_texts)}, Test: {len(test_texts)}")

    # Variant 1: word-level (the original baseline, now with search)
    word_level_params = {
        "tfidf__ngram_range": [(1, 1), (1, 2), (1, 3)],
        "tfidf__min_df": [1, 2, 3],
        "tfidf__max_df": [0.9, 0.95, 1.0],
        "tfidf__max_features": [10000, 20000, 30000],
        "tfidf__sublinear_tf": [True, False],
        "clf__C": loguniform(1e-2, 1e2),
    }

    #  Variant 2: char-level: addresses agglutinative morphology: shares
    # sub-word patterns across inflected forms that whole-word n-grams can't,
    # since isiXhosa/isiZulu prefixing/concatenation makes each inflected form
    # otherwise a distinct word-level feature
    char_level_params = {
        "tfidf__analyzer": ["char_wb"],  # fixed -- this IS the variant's defining property
        "tfidf__ngram_range": [(2, 4), (3, 5), (2, 5)],
        "tfidf__min_df": [2, 3, 5],
        "tfidf__max_features": [10000, 20000, 30000],
        "tfidf__sublinear_tf": [True, False],
        "clf__C": loguniform(1e-2, 1e2),
    }

    word_metrics = run_tfidf_baseline(
        "TFIDF_WordLevel_Baseline", word_level_params,
        train_texts, train_labels, train_langs,
        val_texts, val_labels,
        test_texts, test_labels, test_langs,
    )
    char_metrics = run_tfidf_baseline(
        "TFIDF_CharLevel_Baseline", char_level_params,
        train_texts, train_labels, train_langs,
        val_texts, val_labels,
        test_texts, test_labels, test_langs,
    )

    print("\n" + "#" * 70)
    print("# SUMMARY")
    print("#" * 70)
    print(f"{'Variant':<28} {'Test Acc':>10} {'Test F1':>10} {'ROC-AUC':>10} {'Time (s)':>10}")
    print(f"{'Word-level':<28} {word_metrics['accuracy']:>10.4f} {word_metrics['f1']:>10.4f} {word_metrics['roc_auc']:>10.4f} {word_metrics['total_wall_clock_seconds']:>10.1f}")
    print(f"{'Char-level':<28} {char_metrics['accuracy']:>10.4f} {char_metrics['f1']:>10.4f} {char_metrics['roc_auc']:>10.4f} {char_metrics['total_wall_clock_seconds']:>10.1f}")
