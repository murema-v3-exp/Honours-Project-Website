import pathlib
import sys
import json

import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))


def confusion_counts(df, label_col="label", pred_col="predicted_label"):
    #Returns TP, TN, FP, FN. Positive class = 1 (machine-generated).
    tp = int(((df[label_col] == 1) & (df[pred_col] == 1)).sum())
    tn = int(((df[label_col] == 0) & (df[pred_col] == 0)).sum())
    fp = int(((df[label_col] == 0) & (df[pred_col] == 1)).sum())
    fn = int(((df[label_col] == 1) & (df[pred_col] == 0)).sum())
    return {"TP": tp, "TN": tn, "FP": fp, "FN": fn}


def main():
    files = {
        "Log-Likelihood": "outputs/predictions/log_likelihood_predictions.csv",
        "Curvature (T5-base)": "outputs/predictions/curvature_predictions.csv",
        "Curvature (T5-large)": "outputs/predictions/curvature_t5large_predictions.csv",
        "TF-IDF (self-trained)": "outputs/predictions/tfidf_predictions.csv",
        "TF-IDF (shared, domain-transfer)": "outputs/predictions/shared_tfidf_predictions.csv",
    }

    results = {}
    for name, path in files.items():
        p = pathlib.Path(path)
        if not p.exists():
            print(f"SKIP {name}: {path} not found")
            continue
        df = pd.read_csv(p)
        counts = confusion_counts(df)
        results[name] = counts
        total = sum(counts.values())
        print(f"\n{name} (n={total}):")
        print(f"  TP={counts['TP']}  TN={counts['TN']}  FP={counts['FP']}  FN={counts['FN']}")
        print(f"  Predicted {counts['TP']}/{counts['TP']+counts['FN']} machine samples correctly (recall)")
        print(f"  Of {counts['TP']+counts['FP']} predicted-machine, {counts['TP']} were actually machine (precision)")

    output_path = pathlib.Path("outputs/metrics/confusion_matrices.json")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved → {output_path}")

    # Print a LaTeX-ready table
    print("\n" + "=" * 60)
    print("  LaTeX table rows")
    print("=" * 60)
    for name, counts in results.items():
        print(f"    {name} & {counts['TP']} & {counts['TN']} & {counts['FP']} & {counts['FN']} \\\\")


if __name__ == "__main__":
    main()