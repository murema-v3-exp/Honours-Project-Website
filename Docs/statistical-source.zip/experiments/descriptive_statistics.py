import json
import re
import statistics

# Input file
file_path = ["machine_samples.jsonl", "human_samples.jsonl"]

word_counts = []



for file in file_path:
    with open(file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()

            if not line:
                continue

            # Read one JSON object
            record = json.loads(line)

            # Only count words in the "text" field
            text = record.get("text", "")

            # Count words
            words = re.findall(r"\b[\w'-]+\b", text)

            word_counts.append(len(words))

    # Calculate statistics
    if word_counts:
        average_words = statistics.mean(word_counts)
        median_words = statistics.median(word_counts)
        minimum_words = min(word_counts)
        maximum_words = max(word_counts)
        sum_of_words = sum(word_counts)


        print(f"Number of samples: {len(word_counts)}")
        print(f"Average number of words: {average_words:.2f}")
        print(f"Median number of words: {median_words:.2f}")
        print(f"Minimum number of words: {minimum_words}")
        print(f"Maximum number of words: {maximum_words}")
        print(f"Sum of number of words: {sum_of_words}")

    else:
        print("No valid text samples found.")


    print("---------------------------------------------------")
    word_counts = []
