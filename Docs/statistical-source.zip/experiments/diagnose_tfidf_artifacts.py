

#Checks whether the TF-IDF baseline's near-perfect AUROC is driven by
#trivial formatting artifacts (e.g. Markdown bold headers in Gemma
#output that don't appear in human XSum text) rather than genuine
#generator-style signal.



import pathlib
import sys
import re
from collections import Counter

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from src.data.data_loader import load_dataset


def check_pattern(texts, labels, pattern, name):
    #Reports what fraction of human vs. machine texts contain a pattern.
    human_matches = sum(1 for t, l in zip(texts, labels) if l == 0 and re.search(pattern, t))
    machine_matches = sum(1 for t, l in zip(texts, labels) if l == 1 and re.search(pattern, t))
    n_human = sum(1 for l in labels if l == 0)
    n_machine = sum(1 for l in labels if l == 1)

    print(f"\n{name} (pattern: {pattern!r})")
    print(f"  Human:   {human_matches}/{n_human} ({100*human_matches/n_human:.1f}%)")
    print(f"  Machine: {machine_matches}/{n_machine} ({100*machine_matches/n_machine:.1f}%)")

    if abs(human_matches/n_human - machine_matches/n_machine) > 0.5:
        print(f"  *** LARGE IMBALANCE likely a trivial discriminating artifact ***")


def top_discriminating_ngrams(texts, labels, n_top=20):
    #Fits a quick TF-IDF + logistic regression and shows the highest-weight
    #features, so we can eyeball whether they look like real style
    #differences or formatting artifacts.
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression
    import numpy as np

    vectorizer = TfidfVectorizer(max_features=10000, ngram_range=(1, 2), stop_words="english")
    X = vectorizer.fit_transform(texts)
    clf = LogisticRegression(max_iter=1000, random_state=42)
    clf.fit(X, labels)

    feature_names = np.array(vectorizer.get_feature_names_out())
    coefs = clf.coef_[0]

    top_machine_idx = np.argsort(coefs)[-n_top:][::-1]
    top_human_idx = np.argsort(coefs)[:n_top]

    print(f"\nTop {n_top} features pushing toward MACHINE prediction:")
    for idx in top_machine_idx:
        print(f"  {feature_names[idx]!r:30s}  weight={coefs[idx]:.3f}")

    print(f"\nTop {n_top} features pushing toward HUMAN prediction:")
    for idx in top_human_idx:
        print(f"  {feature_names[idx]!r:30s}  weight={coefs[idx]:.3f}")


def main():
    samples = load_dataset("data/processed/dataset.jsonl", split=None)
    texts = [s.text for s in samples]
    labels = [s.label for s in samples]

    print("=" * 60)
    print("  Checking for trivial formatting artifacts")
    print("=" * 60)

    check_pattern(texts, labels, r"\*\*", "Markdown bold (**text**)")
    check_pattern(texts, labels, r"^#+\s", "Markdown headers (# )")
    check_pattern(texts, labels, r"\n\n", "Double newlines (paragraph breaks)")
    check_pattern(texts, labels, r"^\*\*.*\*\*", "Bold headline at start of text")

    print("\n" + "=" * 60)
    print("  Top discriminating features (full dataset, exploratory)")
    print("=" * 60)
    top_discriminating_ngrams(texts, labels)


if __name__ == "__main__":
    main()