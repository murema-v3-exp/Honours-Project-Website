import pathlib
import sys

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, roc_auc_score

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))


def load_predictions(path):
    df = pd.read_csv(path)
    return df["label"].to_numpy(), df["score"].to_numpy()


def plot_combined_roc(output_path="outputs/plots/combined_roc.png"):
    ll_labels, ll_scores = load_predictions("outputs/predictions/log_likelihood_predictions.csv")
    curv_labels, curv_scores = load_predictions("outputs/predictions/curvature_predictions.csv")

    fig, ax = plt.subplots(figsize=(6, 5))

    for labels, scores, name, color in [
        (ll_labels, ll_scores, "Log-Likelihood", "#1f77b4"),
        (curv_labels, curv_scores, "Curvature", "#d62728"),
    ]:
        fpr, tpr, _ = roc_curve(labels, scores)
        auroc = roc_auc_score(labels, scores)
        ax.plot(fpr, tpr, lw=2, color=color, label=f"{name} (AUROC = {auroc:.3f})")

    ax.plot([0, 1], [0, 1], "k--", lw=1, label="Random chance")
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title("ROC Comparison: Log-Likelihood vs. Curvature")
    ax.legend(loc="lower right")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()

    pathlib.Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    print(f"Combined ROC saved → {output_path}")


def plot_score_distributions(output_path="outputs/plots/score_distributions.png"):
    ll_labels, ll_scores = load_predictions("outputs/predictions/log_likelihood_predictions.csv")
    curv_labels, curv_scores = load_predictions("outputs/predictions/curvature_predictions.csv")

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))

    for ax, labels, scores, name in [
        (axes[0], ll_labels, ll_scores, "Log-Likelihood"),
        (axes[1], curv_labels, curv_scores, "Curvature"),
    ]:
        human_scores = scores[labels == 0]
        machine_scores = scores[labels == 1]
        ax.hist(human_scores, bins=25, alpha=0.6, label="Human-written", color="#2196F3")
        ax.hist(machine_scores, bins=25, alpha=0.6, label="Machine-generated", color="#F44336")
        ax.set_xlabel("Detection score")
        ax.set_ylabel("Count")
        ax.set_title(name)
        ax.legend()
        ax.grid(True, alpha=0.3)

    fig.tight_layout()
    pathlib.Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    print(f"Score distributions saved → {output_path}")


if __name__ == "__main__":
    plot_combined_roc()
    plot_score_distributions()



