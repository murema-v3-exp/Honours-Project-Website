# getting my imports ready
import json
import pathlib
import random
import pandas as pd
from datasets import load_dataset
from tqdm import tqdm

# ── Configuration ─────────────────────────────────────────────────────────────
SEED = 42
N_SAMPLES = 250
MIN_WORDS = 100  # shorter texts give noisy log-likelihood estimates
MAX_WORDS = 600  # longer texts make curvature scoring very slow (25 perturbations each)
N_TRAIN = 75
N_VAL = 75
N_TEST = 100  # test is weighted heavier, this is where AUROC is reported
OUTPUT_DIR = pathlib.Path("data/processed")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

random.seed(SEED)

# ── 1. Download ────────────────────────────────────────────────────────────────
print("Step 1: Downloading XSum validation split from HuggingFace...")
dataset = load_dataset("EdinburghNLP/xsum", split="validation", trust_remote_code=True)
print(f"        Downloaded {len(dataset):,} articles\n")

# ── 2. Inspect ─────────────────────────────────────────────────────────────────
print("Step 2: Inspecting a sample entry...")
sample = dataset[0]
print(f"  ID : {sample['id']}")
print(f"  Document: {sample['document'][:200]}...")
print(f"  Summary : {sample['summary']}\n")

word_counts = [len(e["document"].split()) for e in dataset]
print("  Word count distribution across full dataset:")
print(f"  Min : {min(word_counts)}")
print(f"  Max : {max(word_counts)}")
print(f"  Mean : {sum(word_counts) / len(word_counts):.0f}")
print(f"  Samples within [{MIN_WORDS}, {MAX_WORDS}] words: "
      f"{sum(MIN_WORDS <= w <= MAX_WORDS for w in word_counts):,}\n")

# ── 3. Filter ──────────────────────────────────────────────────────────────────
print("Step 3: Filtering to quality samples...")
seen_ids = set()
filtered = []

for entry in tqdm(dataset, desc="  Filtering"):
    doc = entry["document"].strip()
    summary = entry["summary"].strip()
    wc = len(doc.split())

    # word length must be within range
    if not (MIN_WORDS <= wc <= MAX_WORDS):
        continue

    # summary must be usable as a generation prompt
    if len(summary.split()) < 5:
        continue

    # no duplicates
    if entry["id"] in seen_ids:
        continue

    # no encoding issues
    try:
        doc.encode("utf-8")
    except UnicodeEncodeError:
        continue

    seen_ids.add(entry["id"])
    filtered.append({
        "id": f"xsum_{entry['id']}",
        "text": doc,
        "prompt": summary,
        "label": 0,
        "language": "en",
        "source": "xsum_bbc",
        "generator": None,
        "prompt_id": f"xsum_{entry['id']}",
        "split": None,
    })

print(f"  Passed filters: {len(filtered):,} articles\n")

# ── 4. Sample ──────────────────────────────────────────────────────────────────
print(f"Step 4: Randomly selecting {N_SAMPLES} samples (seed={SEED})...")
random.shuffle(filtered)
selected = filtered[:N_SAMPLES]
print(f"  Selected: {len(selected)}\n")

# ── 5. Assign splits ───────────────────────────────────────────────────────────
print("Step 5: Assigning train / validation / test splits...")
for i, entry in enumerate(selected):
    if i < N_TRAIN:
        entry["split"] = "train"
    elif i < N_TRAIN + N_VAL:
        entry["split"] = "validation"
    else:
        entry["split"] = "test"

# ── 6. Save ────────────────────────────────────────────────────────────────────
print("Step 6: Saving to disk...")
jsonl_path = OUTPUT_DIR / "human_samples.jsonl"
csv_path = OUTPUT_DIR / "human_samples.csv"

with open(jsonl_path, "w") as f:
    for entry in selected:
        f.write(json.dumps(entry) + "\n")

pd.DataFrame(selected).to_csv(csv_path, index=False)
print(f"  Saved JSONL : {jsonl_path}")
print(f"  Saved CSV : {csv_path}\n")

# ── 7. Verify ──────────────────────────────────────────────────────────────────
print("Step 7: Verification report...")
df = pd.DataFrame(selected)
wc = df["text"].apply(lambda x: len(x.split()))

print(f"  Total samples : {len(df)}")
print(f"  Label distribution:\n{df['label'].value_counts().to_string()}")
print(f"  Split distribution:\n{df['split'].value_counts().to_string()}")
print(f"  Word count min : {wc.min()}")
print(f"  Word count max : {wc.max()}")
print(f"  Word count mean : {wc.mean():.0f}")
print(f"  Null texts   : {df['text'].isna().sum()}")
print(f"  Duplicate IDs : {df['id'].duplicated().sum()}")

assert len(df) == N_SAMPLES, "Sample count mismatch"
assert df["label"].unique().tolist() == [0], "Human samples must all be label 0"
assert df["id"].duplicated().sum() == 0, "Duplicate IDs found"
assert df["text"].isna().sum() == 0, "Null texts found"
assert set(df["split"].unique()) == {"train", "validation", "test"}, "Missing splits"

print("\n✓ All checks passed. Dataset preparation complete.")
