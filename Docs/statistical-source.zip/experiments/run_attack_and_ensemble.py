

import argparse
import pathlib
import sys

import mlflow

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from src.data.data_loader import load_dataset
from src.statistical.scorer import get_scorer
from src.statistical.perturbation import PerturbationGenerator
from src.statistical.log_likelihood import LogLikelihoodDetector
from src.statistical.curvature import CurvatureDetector
from src.evaluation.metrics import compute_auroc
from src.attacks.paraphrase_attack import (
    ParaphraseAttacker,
    ParaphraseAttackConfig,
    build_paraphrase_attacked_dataset,
)
from src.ensemble.ensemble_classifier import (
    split_dataset_for_ensemble,
    fit_ensemble_classifier,
    predict_ensemble_probabilities,
)


def parse_ensemble_args():
    p = argparse.ArgumentParser()
    p.add_argument("--real", action="store_true")
    p.add_argument("--scorer", default="meta-llama/Llama-3.2-3B")
    p.add_argument("--mask-model", default="t5-large")
    p.add_argument("--device", default="auto")
    p.add_argument("--k", type=int, default=30)
    p.add_argument("--mask-ratio", type=float, default=0.15)
    p.add_argument("--data", default="data/processed/dataset.jsonl")
    p.add_argument("--cache-dir", default="outputs/perturbation_cache")
    p.add_argument("--seed", type=int, default=42)
    return p.parse_args()


def samples_to_dicts(detection_samples):
    #Converts DetectionSample dataclass objects to plain dicts so the
    #rest of the pipeline (ensemble, attack) can use dict-style access.
    return [
        {
            "id": s.id, "text": s.text, "label": s.label,
            "language": s.language, "source": s.source,
            "generator": s.generator, "prompt_id": s.prompt_id, "split": s.split,
        }
        for s in detection_samples
    ]


def score_dataset(samples, log_detector, curv_detector, text_field="text"):
    #Adds loglik_score / curvature_score to each sample dict in place,
    # using .score_one(),  the real detector interface.
    for sample in samples:
        sample["loglik_score"] = log_detector.score_one(sample[text_field])
        sample["curvature_score"] = curv_detector.score_one(sample[text_field])
    return samples


def run_attack_and_ensemble_experiment(dataset, log_detector, curv_detector, device):
    with mlflow.start_run(run_name="clean_eval", tags={"attack": "none"}):
        clean_scored = score_dataset(dataset, log_detector, curv_detector)
        true_labels = [sample["label"] for sample in clean_scored]

        loglik_auroc = compute_auroc(
            true_labels, [sample["loglik_score"] for sample in clean_scored]
        )
        curvature_auroc = compute_auroc(
            true_labels, [sample["curvature_score"] for sample in clean_scored]
        )
        mlflow.log_metric("loglik_auroc_clean", loglik_auroc)
        mlflow.log_metric("curvature_auroc_clean", curvature_auroc)

        fit_samples, eval_samples = split_dataset_for_ensemble(clean_scored)
        ensemble_classifier = fit_ensemble_classifier(fit_samples)
        ensemble_probabilities = predict_ensemble_probabilities(ensemble_classifier, eval_samples)
        ensemble_auroc = compute_auroc(
            [sample["label"] for sample in eval_samples], ensemble_probabilities
        )
        mlflow.log_metric("ensemble_auroc_clean", ensemble_auroc)
        for feature_name, weight in ensemble_classifier.feature_weights.items():
            mlflow.log_param(f"ensemble_weight_{feature_name}", weight)

        print("Clean:      loglik=%.4f curvature=%.4f ensemble=%.4f"
              % (loglik_auroc, curvature_auroc, ensemble_auroc))

    with mlflow.start_run(run_name="paraphrase_attack_eval", tags={"attack": "paraphrase"}):
        attacker = ParaphraseAttacker(ParaphraseAttackConfig(device=None if device == "auto" else device))
        attacked_dataset = build_paraphrase_attacked_dataset(dataset, attacker)
        attacked_scored = score_dataset(
            attacked_dataset, log_detector, curv_detector, text_field="paraphrased_text"
        )

        attacked_labels = [sample["label"] for sample in attacked_scored]
        loglik_auroc_attacked = compute_auroc(
            attacked_labels, [sample["loglik_score"] for sample in attacked_scored]
        )
        curvature_auroc_attacked = compute_auroc(
            attacked_labels, [sample["curvature_score"] for sample in attacked_scored]
        )
        mlflow.log_metric("loglik_auroc_paraphrased", loglik_auroc_attacked)
        mlflow.log_metric("curvature_auroc_paraphrased", curvature_auroc_attacked)

        fit_sample_ids = {id(sample) for sample in fit_samples}
        eval_attacked_samples = [s for s in attacked_scored if id(s) not in fit_sample_ids]
        ensemble_probabilities_attacked = predict_ensemble_probabilities(
            ensemble_classifier, eval_attacked_samples
        )
        ensemble_auroc_attacked = compute_auroc(
            [sample["label"] for sample in eval_attacked_samples], ensemble_probabilities_attacked
        )
        mlflow.log_metric("ensemble_auroc_paraphrased", ensemble_auroc_attacked)

        print("Paraphrase: loglik=%.4f curvature=%.4f ensemble=%.4f"
              % (loglik_auroc_attacked, curvature_auroc_attacked, ensemble_auroc_attacked))


if __name__ == "__main__":
    args = parse_ensemble_args()

    print("Loading dataset...")
    raw_samples = load_dataset(args.data, split=None)
    all_samples = samples_to_dicts(raw_samples)  # <-- the critical fix

    scorer = get_scorer({
        "use_mock": not args.real,
        "model_id": args.scorer,
        "device": args.device,
        "seed": args.seed,
    })

    perturber = PerturbationGenerator(
        model_id=args.mask_model,
        device=args.device,
        k=args.k,
        mask_ratio=args.mask_ratio,
        seed=args.seed,
        cache_dir=args.cache_dir,
    )

    log_detector = LogLikelihoodDetector(scorer, min_tokens=10)
    curv_detector = CurvatureDetector(scorer, perturber, min_tokens=10)

    run_attack_and_ensemble_experiment(all_samples, log_detector, curv_detector, args.device)

    print("Attack and Ensemble complete.")