import argparse
import json
import logging
import pathlib
import sys
import time
import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from src.data.data_loader import load_dataset, get_texts_and_labels
from src.statistical.scorer import get_scorer
from src.statistical.perturbation import PerturbationGenerator, MockPerturbationGenerator
from src.statistical.curvature import CurvatureDetector
from src.evaluation.metrics import full_evaluation, print_results, plot_roc_curve
from src.evaluation.reporting import save_predictions, save_metrics

logging.basicConfig(
    level = logging.INFO,
    format = "%(asctime)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger(__name__)


def parse_args():
    p = argparse.ArgumentParser(description="DetectGPT curvature detector")
    p.add_argument("--real",       action="store_true",
                   help="Use real models instead of mocks")
    p.add_argument("--scorer",     default="gpt2",
                   help="HuggingFace model ID for the scoring backbone")
    p.add_argument("--mask-model", default="t5-large",
                   help="HuggingFace model ID for T5 mask-filling")
    p.add_argument("--device",     default="auto")
    p.add_argument("--k",          type=int, default=25,
                   help="Number of perturbations per text")
    p.add_argument("--mask-ratio", type=float, default=0.15,
                   help="Fraction of tokens to mask per perturbation")
    p.add_argument("--strategy",   default="youden_j",
                   choices=["youden_j", "val_f1"])
    p.add_argument("--data",       default="data/processed/dataset.jsonl")
    p.add_argument("--cache-dir",  default="outputs/perturbation_cache")
    p.add_argument("--bootstrap-n", type=int, default=1000)
    p.add_argument("--seed",       type=int, default=42)
    return p.parse_args()


def main():
    args = parse_args()

    print("\n" + "="*60)
    print("  DetectGPT Curvature Detector — Full Experiment")
    print("="*60)

    config = {
        "method" : "curvature",
        "use_mock" : not args.real,
        "scorer_id" : args.scorer if args.real else "mock",
        "mask_model" : args.mask_model if args.real else "mock",
        "device" : args.device,
        "k" : args.k,
        "mask_ratio" : args.mask_ratio,
        "strategy" : args.strategy,
        "bootstrap_n" : args.bootstrap_n,
        "seed" : args.seed,
    }
    print(f"\nConfig: {json.dumps(config, indent=2)}\n")

    # ── Load data ─────────────────────────────────────────────────────────────
    val_samples = load_dataset(args.data, split="validation")
    test_samples = load_dataset(args.data, split="test")
    val_texts,  val_labels = get_texts_and_labels(val_samples)
    test_texts, test_labels = get_texts_and_labels(test_samples)

    # extract IDs for cache keying
    val_ids = [s.id for s in val_samples]
    test_ids = [s.id for s in test_samples]

    # ── loading scorer ───────────────
    scorer = get_scorer({
        "use_mock" : not args.real,
        "model_id" : args.scorer,
        "device" : args.device,
        "seed" : args.seed,
    })

    # ── loading the perturbation generator ────────────
    if args.real:
        print("Loading T5 perturbation model...")
        perturber = PerturbationGenerator(
            model_id = args.mask_model,
            device = args.device,
            k = args.k,
            mask_ratio = args.mask_ratio,
            seed = args.seed,
            cache_dir = args.cache_dir,
        )
    else:
        print("Using mock perturbation generator.")
        perturber = MockPerturbationGenerator(k=args.k, seed=args.seed)

    # ── initialise detector ───────────────
    detector = CurvatureDetector(scorer, perturber, min_tokens=10)

    # ── calibrate on validation only ───────────
    print("\nStep 1 — Calibrating threshold on validation set...")
    print("NOTE: Each text requires k Llama forward passes.")
    print(f"      Estimated time: {len(val_texts) * args.k * 0.5 / 60:.0f}–"
          f"{len(val_texts) * args.k * 1.0 / 60:.0f} minutes for real mode.")
    t0 = time.time()
    detector.calibrate(
        val_texts,
        val_labels,
        val_ids = val_ids,
        strategy = args.strategy,
    )
    print(f"Calibration done in {time.time()-t0:.1f}s")
    from src.evaluation.metrics import plot_threshold_sensitivity
    plot_threshold_sensitivity(
        val_labels=np.array(val_labels),
        val_scores=detector._val_scores,
        threshold=detector.threshold,
        detector_name="DetectGPT Curvature (GPT-2)",
        output_path="outputs/plots/curv_threshold_sensitivity.png",
    )

    # ── Score and predict on test ──────────
    print("\nStep 2 — Scoring test set...")
    t0 = time.time()
    test_scores = detector.score_texts(test_texts, ids=test_ids, verbose=True)
    test_preds, _ = detector.predict(test_texts, ids=test_ids, scores=test_scores)
    print(f"Test scoring done in {time.time()-t0:.1f}s")

    # ── evaluate ───────────────
    print("\nStep 3 — Computing metrics...")
    metrics = full_evaluation(
        labels = np.array(test_labels),
        predictions = test_preds,
        scores = test_scores,
        bootstrap_n = args.bootstrap_n,
        bootstrap_seed = args.seed,
    )
    print_results(metrics, detector_name="DetectGPT Curvature Detector")

    # ── save outputs ─────────────
    save_predictions(test_samples, test_preds, test_scores, "curvature")
    save_metrics(metrics, "curvature", detector.threshold, config)

    # plot ROC curve
    plot_roc_curve(
        labels = np.array(test_labels),
        scores = test_scores,
        detector_name = f"Curvature / DetectGPT ({args.scorer})",
        output_path = "outputs/plots/curvature_roc.png",
    )

    # ── MLflow ──────────────
    try:
        import mlflow
        with mlflow.start_run(run_name="curvature_detectgpt"):
            mlflow.log_params(config)
            mlflow.log_metrics(metrics)
            mlflow.log_metric("threshold", detector.threshold)
            mlflow.log_artifacts("outputs/predictions")
            mlflow.log_artifacts("outputs/metrics")
            mlflow.log_artifacts("outputs/plots")
        print("\nMLflow run logged.")
    except Exception as e:
        logger.warning(f"MLflow logging skipped: {e}")

    print("\n" + "="*60)
    print("  Experiment complete.")
    print("="*60 + "\n")

    return metrics


if __name__ == "__main__":
    main()