
#this is a standalone demo of the sentence-level highlighter, using the finalized log-likelihood detector and its calibrated threshold (-2.0031). Loads a
#few test-set samples, highlights sentences scored above the threshold, and saves the result as an HTML file you can open directly in a browser.




import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from src.data.data_loader import load_dataset
from src.statistical.scorer import get_scorer
from src.utils.sentence_highlighter import render_highlighted_html

CALIBRATED_THRESHOLD = -2.0030773220245353  # from outputs/metrics/log_likelihood_metrics.json


def main():
    print("Loading test samples...")
    test_samples = load_dataset("data/processed/dataset.jsonl", split="test")

    # Pick a small, illustrative mix: 2 human, 2 machine
    human_samples = [s for s in test_samples if s.label == 0][:2]
    machine_samples = [s for s in test_samples if s.label == 1][:2]
    demo_samples = human_samples + machine_samples

    print("Loading Llama scorer (this loads the real model — takes a moment)...")
    scorer = get_scorer({
        "use_mock": False,
        "model_id": "meta-llama/Llama-3.2-3B",
        "device": "auto",
        "seed": 42,
    })

    html_parts = ["<html><head><meta charset='utf-8'><style>",
                  "body { font-family: sans-serif; max-width: 800px; margin: 40px auto; line-height: 1.6; }",
                  "h2 { border-bottom: 2px solid #333; padding-bottom: 5px; }",
                  ".meta { color: #666; font-size: 0.9em; margin-bottom: 10px; }",
                  "mark { padding: 2px 4px; border-radius: 3px; }",
                  "</style></head><body>",
                  "<h1>Sentence Highlighter Demo</h1>",
                  f"<p class='meta'>Threshold: {CALIBRATED_THRESHOLD:.4f} (Youden's J, validation-calibrated). "
                  f"Sentences scored above this threshold are highlighted as likely machine-generated. "
                  f"This is a diagnostic/qualitative tool — see Limitations for caveats on sentence-level "
                  f"calibration.</p>"]

    for i, sample in enumerate(demo_samples):
        true_label = "Human-written" if sample.label == 0 else "Machine-generated"
        print(f"Highlighting sample {i+1}/{len(demo_samples)} (true label: {true_label})...")

        highlighted = render_highlighted_html(
            sample.text, scorer.score, CALIBRATED_THRESHOLD
        )
        html_parts.append(f"<h2>Sample {i+1} — True label: {true_label}</h2>")
        html_parts.append(f"<p class='meta'>ID: {sample.id}</p>")
        html_parts.append(f"<p>{highlighted}</p>")

    html_parts.append("</body></html>")

    output_path = pathlib.Path("outputs/highlighter_demo.html")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(html_parts), encoding="utf-8")

    print(f"\nDone. Open in a browser: {output_path.resolve()}")


if __name__ == "__main__":
    main()