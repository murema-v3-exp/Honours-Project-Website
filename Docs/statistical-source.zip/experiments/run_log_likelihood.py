import argparse
import json
import logging
import pathlib
import sys
import time
import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from src.data.data_loader import load_dataset, get_texts_and_labels
from src.statistical.scorer import get_scorer
from src.statistical.log_likelihood import LogLikelihoodDetector
from src.evaluation.metrics import (
    full_evaluation,
    print_results,
    plot_score_distributions,
)
from src.evaluation.reporting    import save_predictions, save_metrics

logging.basicConfig(
    level= logging.INFO,
    format = "%(asctime)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger(__name__)


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--real",     action="store_true",
                   help="Use real Llama instead of mock")
    p.add_argument("--model",    default="meta-llama/Llama-3.2-1B")
    p.add_argument("--device",   default="auto")
    p.add_argument("--strategy", default="youden_j",
                   choices=["youden_j","val_f1"])
    p.add_argument("--data",     default="data/processed/dataset.jsonl")
    p.add_argument("--bootstrap-n", type=int, default=1000)
    p.add_argument("--seed",     type=int, default=42)
    return p.parse_args()


def main():
    args = parse_args()

    print("\n" + "="*60)
    print("  Log-Likelihood Detector — Full Experiment")
    print("="*60)

    config = {
        "method" : "log_likelihood",
        "use_mock" : not args.real,
        "model_id" : args.model if args.real else "mock",
        "device" : args.device,
        "strategy" : args.strategy,
        "bootstrap_n" : args.bootstrap_n,
        "seed" : args.seed,
    }
    print(f"\nConfig: {json.dumps(config, indent=2)}\n")

    # load splits
    val_samples = load_dataset(args.data, split="validation")
    test_samples = load_dataset(args.data, split="test")
    val_texts, val_labels = get_texts_and_labels(val_samples)
    test_texts, test_labels = get_texts_and_labels(test_samples)

    # scorer and detector
    scorer = get_scorer({
        "use_mock": not args.real,
        "model_id": args.model,
        "device": args.device,
        "seed": args.seed,
    })
    detector = LogLikelihoodDetector(scorer, min_tokens=10)

    # calibrate on validation only
    print("\nStep 1 — Calibrating threshold on validation set...")
    t0 = time.time()
    detector.calibrate(val_texts, val_labels, strategy=args.strategy)
    print(f"Done in {time.time() - t0:.1f}s")

    from src.evaluation.metrics import plot_threshold_sensitivity
    plot_threshold_sensitivity(
        val_labels=np.array(val_labels),
        val_scores=detector._val_scores,
        threshold=detector.threshold,
        detector_name="Log-Likelihood (Llama)",
        output_path="outputs/plots/ll_threshold_sensitivity.png",
    )

    # score and predict on test — test set touched exactly once
    print("\nStep 2 — Scoring test set...")
    t0 = time.time()
    test_scores = detector.score_texts(test_texts, verbose=True)
    test_preds, _ = detector.predict(test_texts, scores=test_scores)
    print(f"Done in {time.time() - t0:.1f}s")

    # score distributions
    human_scores = test_scores[np.array(test_labels) == 0]
    machine_scores = test_scores[np.array(test_labels) == 1]

    plot_score_distributions(
        human_scores,
        machine_scores,
        threshold=detector.threshold,
        detector_name="Log-Likelihood (GPT-2)",
        output_path="outputs/plots/ll_score_distributions.png",
    )

    # evaluate
    print("\nStep 3 — Computing metrics...")
    metrics = full_evaluation(
        labels=np.array(test_labels),
        predictions=test_preds,
        scores=test_scores,
        bootstrap_n=args.bootstrap_n,
        bootstrap_seed=args.seed,
    )
    print_results(metrics, detector_name="Log-Likelihood Detector")
    from src.evaluation.metrics import plot_roc_curve
    plot_roc_curve(
        labels=np.array(test_labels),
        scores=test_scores,
        detector_name="Log-Likelihood (GPT-2)",
        output_path="outputs/plots/log_likelihood_roc.png",
    )

    # save outputs
    save_predictions(test_samples, test_preds, test_scores, "log_likelihood")
    save_metrics(metrics, "log_likelihood", detector.threshold, config)

    # MLflow
    try:
        import mlflow
        with mlflow.start_run(run_name="log_likelihood"):
            mlflow.log_params(config)
            mlflow.log_metrics(metrics)
            mlflow.log_metric("threshold", detector.threshold)
        print("\nMLflow run logged.")
    except Exception as e:
        logger.warning(f"MLflow logging skipped: {e}")

    print("\n" + "=" * 60)
    print("  Experiment complete.")
    print("=" * 60 + "\n")

    return metrics



if __name__ == "__main__":
    main()