

import argparse
import json
import pathlib
import sys

import joblib
import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from src.data.data_loader import load_dataset, get_texts_and_labels
from src.evaluation.metrics import full_evaluation, print_results, plot_roc_curve
from src.evaluation.reporting import save_metrics


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--model-path", required=True,
                    help="Path to Murema's frozen .joblib model file")
    p.add_argument("--data", default="data/processed/dataset.jsonl")
    return p.parse_args()


def main():
    args = parse_args()

    print("\n" + "=" * 60)
    print("  Shared TF-IDF Baseline (group model, applied to our test set)")
    print("=" * 60)

    print(f"\nLoading frozen model: {args.model_path}")
    model = joblib.load(args.model_path)

    test_samples = load_dataset(args.data, split="test")
    test_texts, test_labels = get_texts_and_labels(test_samples)
    print(f"Test set: {len(test_texts)} samples")

    # (importanrt)we pass raw, uncleaned text, the model card explicitly says
    # not to lowercase/tokenise/clean before prediction.
    predictions = model.predict(test_texts)
    probabilities = model.predict_proba(test_texts)[:, 1]

    print("\nComputing metrics...")
    metrics = full_evaluation(
        labels=np.array(test_labels),
        predictions=np.array(predictions),
        scores=np.array(probabilities),
        bootstrap_n=1000,
        bootstrap_seed=42,
    )
    print_results(metrics, detector_name="Shared TF-IDF Baseline")

    plot_roc_curve(
        labels=np.array(test_labels),
        scores=np.array(probabilities),
        detector_name="Shared TF-IDF Baseline",
        output_path="outputs/plots/shared_tfidf_roc.png",
    )

    config = {
        "method": "shared_tfidf_baseline",
        "model_source": "murema-v3-exp/llm-text-detection (final-tfidf-baseline branch)",
        "model_file": "tfidf_wordchar.joblib",
        "trained_on": "group shared baseline dataset (not our XSum/Gemma dataset)",
        "test_samples": len(test_texts),
        "note": "Domain-transfer evaluation — model was not trained on this project's dataset.",
    }
    save_metrics(metrics, "shared_tfidf", threshold=0.5, config=config)

    import pandas as pd
    output_dir = pathlib.Path("outputs/predictions")
    output_dir.mkdir(parents=True, exist_ok=True)
    records = []
    for sample, pred, prob in zip(test_samples, predictions, probabilities):
        records.append({
            "id": sample.id,
            "label": sample.label,
            "predicted_label": int(pred),
            "score": float(prob),
            "method": "shared_tfidf",
            "split": sample.split,
        })
    pd.DataFrame(records).to_csv(output_dir / "shared_tfidf_predictions.csv", index=False)
    print(f"\nSaved predictions → {output_dir / 'shared_tfidf_predictions.csv'}")

    print("\n" + "=" * 60)
    print("  Shared TF-IDF baseline complete.")
    print("=" * 60 + "\n")

    return metrics


if __name__ == "__main__":
    main()