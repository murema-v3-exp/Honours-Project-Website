

#Computes McNemar's test and DeLong's test comparing the log-likelihood
# and curvature detectors on the same test set, using the already-saved
# prediction CSVs. Both test functions already exist in
# src/evaluation/metrics.py :this script just loads the two prediction
# files, aligns them by sample id, and calls both tests.




import pathlib
import sys
import json

import numpy as np
import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from src.evaluation.metrics import mcnemar_test, delong_test


def load_and_align(loglik_path: str, curvature_path: str) -> pd.DataFrame:
    #Loads both prediction CSVs and joins them on sample id, so everyrow has both detectors' prediction/score for the same text.
    loglik_df = pd.read_csv(loglik_path)
    curvature_df = pd.read_csv(curvature_path)

    merged = loglik_df.merge(
        curvature_df,
        on="id",
        suffixes=("_loglik", "_curvature"),
        how="inner",
    )

    assert len(merged) == len(loglik_df) == len(curvature_df), (
        f"Sample count mismatch after join: loglik={len(loglik_df)}, "
        f"curvature={len(curvature_df)}, merged={len(merged)}. "
        f"Check both prediction files come from the same test split."
    )
    assert (merged["label_loglik"] == merged["label_curvature"]).all(), (
        "Label mismatch after join :the two files may not be scoring "
        "the same underlying samples."
    )

    return merged


def main():
    loglik_path = "outputs/predictions/log_likelihood_predictions.csv"
    curvature_path = "outputs/predictions/curvature_predictions.csv"

    print(f"Loading predictions:\n  {loglik_path}\n  {curvature_path}\n")
    merged = load_and_align(loglik_path, curvature_path)
    print(f"Aligned {len(merged)} samples with both detectors' predictions.\n")

    labels = merged["label_loglik"].to_numpy()
    preds_loglik = merged["predicted_label_loglik"].to_numpy()
    preds_curvature = merged["predicted_label_curvature"].to_numpy()
    scores_loglik = merged["score_loglik"].to_numpy()
    scores_curvature = merged["score_curvature"].to_numpy()

    print("=" * 60)
    print("  McNemar's Test (prediction disagreement)")
    print("=" * 60)
    mcnemar_result = mcnemar_test(
        labels, preds_loglik, preds_curvature,
        name_a="Log-Likelihood", name_b="Curvature",
    )
    print(json.dumps(mcnemar_result, indent=2))

    print("\n" + "=" * 60)
    print("  DeLong's Test (AUROC comparison)")
    print("=" * 60)
    delong_result = delong_test(labels, scores_loglik, scores_curvature)
    print(json.dumps(delong_result, indent=2))

    # Save both results to disk for the paper
    output_path = pathlib.Path("outputs/metrics/statistical_comparison.json")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w") as f:
        json.dump({"mcnemar": mcnemar_result, "delong": delong_result}, f, indent=2)
    print(f"\nSaved combined results → {output_path}")

    # Also surface a few qualitative disagreement examples for Table 4
    disagreements = merged[
        merged["predicted_label_loglik"] != merged["predicted_label_curvature"]
    ]
    print(f"\n{len(disagreements)} samples where the two detectors disagreed.")
    if len(disagreements) > 0:
        sample_cols = ["id", "label_loglik", "predicted_label_loglik", "predicted_label_curvature"]
        print(disagreements[sample_cols].head(10).to_string(index=False))
        disagreements.to_csv("outputs/predictions/detector_disagreements.csv", index=False)
        print("\nFull disagreement list saved → outputs/predictions/detector_disagreements.csv")


if __name__ == "__main__":
    main()