
#Trains a TF-IDF + logistic regression baseline on the SAME dataset
#splits used by the log-likelihood and curvature detectors, so its
#results are directly comparable in the primary Results table.


import json
import pathlib
import sys

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from src.data.data_loader import load_dataset, get_texts_and_labels
from src.evaluation.metrics import full_evaluation, print_results, plot_roc_curve
from src.evaluation.reporting import save_metrics


def main():
    print("\n" + "=" * 60)
    print("  TF-IDF Logistic Regression Baseline")
    print("=" * 60)

    data_path = "data/processed/dataset.jsonl"

    train_samples = load_dataset(data_path, split="train")
    test_samples = load_dataset(data_path, split="test")

    train_texts, train_labels = get_texts_and_labels(train_samples)
    test_texts, test_labels = get_texts_and_labels(test_samples)

    print(f"\nTrain: {len(train_texts)} samples | Test: {len(test_texts)} samples")

    # Fit TF-IDF on the TRAINING split only the test split's vocabulary
    # must never leak into vectorizer fitting, matching the same
    # train/test discipline used by the zero-shot detectors' threshold
    # calibration.
    print("\nFitting TF-IDF vectorizer on training split...")
    vectorizer = TfidfVectorizer(
        max_features=10000,
        ngram_range=(1, 2),
        stop_words="english",
        sublinear_tf=True,
    )
    X_train = vectorizer.fit_transform(train_texts)
    X_test = vectorizer.transform(test_texts)

    print("Fitting logistic regression classifier...")
    classifier = LogisticRegression(
        C=1.0,
        max_iter=1000,
        random_state=42,
    )
    classifier.fit(X_train, train_labels)

    # Score and predict on test
    test_scores = classifier.predict_proba(X_test)[:, 1]  # P(machine-generated)
    test_preds = classifier.predict(X_test)

    print("\nComputing metrics...")
    metrics = full_evaluation(
        labels=np.array(test_labels),
        predictions=test_preds,
        scores=test_scores,
        bootstrap_n=1000,
        bootstrap_seed=42,
    )
    print_results(metrics, detector_name="TF-IDF Logistic Regression")

    plot_roc_curve(
        labels=np.array(test_labels),
        scores=test_scores,
        detector_name="TF-IDF Logistic Regression",
        output_path="outputs/plots/tfidf_roc.png",
    )

    config = {
        "method": "tfidf_logistic_regression",
        "vectorizer": "TfidfVectorizer",
        "max_features": 10000,
        "ngram_range": [1, 2],
        "classifier": "LogisticRegression",
        "C": 1.0,
        "random_state": 42,
        "train_samples": len(train_texts),
        "test_samples": len(test_texts),
    }

    save_metrics(metrics, "tfidf", threshold=0.5, config=config)

    #saving predictions in the same format as the other detectors, so the
    # McNemar/DeLong comparison script can be extended to include TF-IDF
    # with minimal changes if you want a three-way comparison later.
    import pandas as pd
    output_dir = pathlib.Path("outputs/predictions")
    output_dir.mkdir(parents=True, exist_ok=True)
    records = []
    for sample, pred, score in zip(test_samples, test_preds, test_scores):
        records.append({
            "id": sample.id,
            "label": sample.label,
            "predicted_label": int(pred),
            "score": float(score),
            "method": "tfidf",
            "split": sample.split,
            "language": sample.language,
        })
    pd.DataFrame(records).to_csv(output_dir / "tfidf_predictions.csv", index=False)
    print(f"\nSaved predictions → {output_dir / 'tfidf_predictions.csv'}")

    print("\n" + "=" * 60)
    print("  TF-IDF baseline complete.")
    print("=" * 60 + "\n")

    return metrics


if __name__ == "__main__":
    main()