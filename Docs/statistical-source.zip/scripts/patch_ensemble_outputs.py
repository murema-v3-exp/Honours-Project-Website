path = "experiments/run_attack_and_ensemble.py"
with open(path) as f:
    content = f.read()

# 1. Add the reporting import alongside the others
content = content.replace(
    "from src.evaluation.metrics import compute_auroc",
    "from src.evaluation.metrics import compute_auroc\n"
    "from src.evaluation.reporting import save_metrics"
)

# 2. Save clean-eval metrics to disk (after the clean mlflow block's prints)
old_clean_print = '''        print(
            "Clean:      loglik=%.4f curvature=%.4f ensemble=%.4f"
            % (loglik_auroc, curvature_auroc, ensemble_auroc)
        )'''
new_clean_print = old_clean_print + '''

        save_metrics(
            {"loglik_auroc": loglik_auroc, "curvature_auroc": curvature_auroc,
             "ensemble_auroc": ensemble_auroc, **ensemble_classifier.feature_weights},
            method="ensemble_clean",
            threshold=0.5,
            config={"attack": "none", "mask_model": mask_model, "device": device,
                    "k": k, "mask_ratio": mask_ratio, "seed": seed},
        )'''
content = content.replace(old_clean_print, new_clean_print)

# 3. Save attacked-eval metrics to disk (after the attack mlflow block's prints)
old_attack_print = '''        print(
            "Paraphrase: loglik=%.4f curvature=%.4f ensemble=%.4f"
            % (loglik_auroc_attacked, curvature_auroc_attacked, ensemble_auroc_attacked)
        )'''
new_attack_print = old_attack_print + '''

        save_metrics(
            {"loglik_auroc": loglik_auroc_attacked, "curvature_auroc": curvature_auroc_attacked,
             "ensemble_auroc": ensemble_auroc_attacked},
            method="ensemble_paraphrased",
            threshold=0.5,
            config={"attack": "paraphrase", "mask_model": mask_model, "device": device,
                    "k": k, "mask_ratio": mask_ratio, "seed": seed},
        )'''
content = content.replace(old_attack_print, new_attack_print)

with open(path, "w") as f:
    f.write(content)
print("Patched run_attack_and_ensemble.py — now writes outputs/metrics/ensemble_clean_metrics.json and ensemble_paraphrased_metrics.json")
