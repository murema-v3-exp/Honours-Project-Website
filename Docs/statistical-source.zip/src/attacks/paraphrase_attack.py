
#Paraphrasing attack stress-tests the log-likelihood and curvature
# detectors by paraphrasing machine-generated text and re-scoring it.



from dataclasses import dataclass
from typing import List
import torch
from transformers import T5ForConditionalGeneration, T5Tokenizer

PARAPHRASE_MODEL_NAME = "humarin/chatgpt_paraphraser_on_T5_base"


def detect_device() -> str:
    #Same auto-detection pattern as the existing statistical scorers:
    if torch.backends.mps.is_available():
        return "mps"
    if torch.cuda.is_available():
        return "cuda"
    return "cpu"


@dataclass
class ParaphraseAttackConfig:
    model_name: str = PARAPHRASE_MODEL_NAME
    num_beams: int = 5
    max_length: int = 256
    temperature: float = 0.7
    device: str = None  # auto-detected if left as None

    def __post_init__(self):
        if self.device is None:
            self.device = detect_device()


class ParaphraseAttacker:

    def __init__(self, config: ParaphraseAttackConfig = None):
        self.config = config or ParaphraseAttackConfig()
        self.tokenizer = T5Tokenizer.from_pretrained(self.config.model_name)
        self.model = T5ForConditionalGeneration.from_pretrained(
            self.config.model_name
        ).to(self.config.device)
        self.model.eval()

    @torch.no_grad()
    def paraphrase_text(self, source_text: str) -> str:
        #Paraphrases a single document. For long multi-sentence documents,

        prompt = f"paraphrase: {source_text}"
        input_ids = self.tokenizer(
            prompt, return_tensors="pt", truncation=True, max_length=512, padding=True
        ).to(self.config.device)

        generated_ids = self.model.generate(
            **input_ids,
            max_length=self.config.max_length,
            num_beams=self.config.num_beams,
            temperature=self.config.temperature,
            do_sample=True,
            early_stopping=True,
        )
        return self.tokenizer.decode(generated_ids[0], skip_special_tokens=True)

    def paraphrase_batch(self, source_texts: List[str]) -> List[str]:

        return [self.paraphrase_text(text) for text in source_texts]


def build_paraphrase_attacked_dataset(
        samples: List[dict], attacker: ParaphraseAttacker
) -> List[dict]:


    attacked_samples = []
    for sample in samples:
        new_sample = dict(sample)
        if sample.get("label") == 1:
            new_sample["paraphrased_text"] = attacker.paraphrase_text(sample["text"])
        else:
            new_sample["paraphrased_text"] = sample["text"]
        attacked_samples.append(new_sample)
    return attacked_samples
