import json
import pathlib
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class DetectionSample:

    id: str
    text: str
    label: int
    language: str
    source: str
    generator: Optional[str]
    prompt_id: Optional[str]
    split: str

    def __post_init__(self):
        assert self.label in (0, 1), \
            f"Label must be 0 or 1, got {self.label} for sample {self.id}"
        assert self.split in ("train", "validation", "test"), \
            f"Invalid split: {self.split}"
        assert len(self.text.strip()) > 0, \
            f"Empty text for sample {self.id}"


def load_dataset(
        path: str = "data/processed/dataset.jsonl",
        split: Optional[str] = None,
        language: str = "en",
) -> List[DetectionSample]:

    # Loading the detection dataset from JSONL.


    #Returns list of DetectionSample objects


    path = pathlib.Path(path)
    assert path.exists(), \
        f"Dataset not found at {path}. Run prepare_dataset.py first."

    samples = []
    with open(path) as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                raw = json.loads(line)
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid JSON on line {line_num}: {e}")

            # apply filters
            if language and raw.get("language") != language:
                continue
            if split and raw.get("split") != split:
                continue

            samples.append(DetectionSample(
                id=raw["id"],
                text=raw["text"],
                label=raw["label"],
                language=raw.get("language", "en"),
                source=raw.get("source", "unknown"),
                generator=raw.get("generator"),
                prompt_id=raw.get("prompt_id"),
                split=raw["split"],
            ))

    assert len(samples) > 0, \
        f"No samples found for split={split}, language={language}"

    # report what was loaded
    n_human = sum(1 for s in samples if s.label == 0)
    n_machine = sum(1 for s in samples if s.label == 1)
    print(f"Loaded {len(samples)} samples "
          f"(split={split or 'all'}, "
          f"human={n_human}, machine={n_machine})")

    return samples


def get_texts_and_labels(samples: List[DetectionSample]):
    #Convenience function, it extracts parallel lists of texts and labels.
    #Used by detectors and evaluation functions.


    texts = [s.text for s in samples]
    labels = [s.label for s in samples]
    return texts, labels