

#combines log-likelihood and curvature scores (and optionally sentence-level features from sentence_level_scorer.py) via logistic regression into a single machine-generated probability.



from dataclasses import dataclass
from typing import List, Tuple
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

# Default feature set: document-level scores only. Extend with sentence-level
# features (e.g. "loglik_sentence_std") once sentence_level_scorer.py has
# been run over the dataset.
FEATURE_KEYS = ["loglik_score", "curvature_score"]


@dataclass
class EnsembleClassifier:
    model: LogisticRegression
    scaler: StandardScaler
    feature_keys: List[str]
    feature_weights: dict  # e.g. {"loglik_score": w1, "curvature_score": w2}


def split_dataset_for_ensemble(
        samples: List[dict], fit_fraction: float = 0.5, random_state: int = 42
) -> Tuple[List[dict], List[dict]]:

    #Splits the dataset into an ensemble-fit half and an ensemble-eval half.
    #Report AUROC only on the eval half — never evaluate on the fit half.

    #Stratifies on label so both halves preserve the human/machine balance.

    labels = [sample["label"] for sample in samples]
    fit_samples, eval_samples = train_test_split(
        samples, train_size=fit_fraction, stratify=labels, random_state=random_state
    )
    return fit_samples, eval_samples


def _build_feature_matrix(samples: List[dict], feature_keys: List[str]) -> np.ndarray:
    return np.array([[sample[key] for key in feature_keys] for sample in samples])


def fit_ensemble_classifier(
        fit_samples: List[dict], feature_keys: List[str] = None
) -> EnsembleClassifier:
    #Fits the logistic regression on the fit split only.
    feature_keys = feature_keys or FEATURE_KEYS
    features = _build_feature_matrix(fit_samples, feature_keys)
    labels = np.array([sample["label"] for sample in fit_samples])

    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(features)

    model = LogisticRegression()
    model.fit(scaled_features, labels)

    feature_weights = dict(zip(feature_keys, model.coef_[0].tolist()))
    return EnsembleClassifier(
        model=model, scaler=scaler, feature_keys=feature_keys, feature_weights=feature_weights
    )


def predict_ensemble_probabilities(
        classifier: EnsembleClassifier, samples: List[dict]
) -> np.ndarray:

    #Returns predicted probabilities (machine-generated = positive class), same output shape evaluation.metrics already expects from the individual detectors and we pass this straight into compute_auroc().

    features = _build_feature_matrix(samples, classifier.feature_keys)
    scaled_features = classifier.scaler.transform(features)
    return classifier.model.predict_proba(scaled_features)[:, 1]

# --- Example wiring, matching this project's flow ---
#
# fit_samples, eval_samples = split_dataset_for_ensemble(scored_samples)
# classifier = fit_ensemble_classifier(fit_samples)
# probabilities = predict_ensemble_probabilities(classifier, eval_samples)
# auroc, ci_low, ci_high = compute_auroc(
#     y_true=[s["label"] for s in eval_samples], y_score=probabilities
# )
# mlflow.log_metric("ensemble_auroc", auroc)
# mlflow.log_param("ensemble_weight_loglik", classifier.feature_weights["loglik_score"])
# mlflow.log_param("ensemble_weight_curvature", classifier.feature_weights["curvature_score"])
