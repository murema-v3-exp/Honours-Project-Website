from __future__ import annotations
import pathlib
import numpy as np
from typing import Dict, Tuple
from sklearn.metrics import (
    roc_auc_score,
    f1_score,
    precision_score,
    recall_score,
    accuracy_score,
    roc_curve,
)


def compute_auroc(
    labels : np.ndarray,
    scores : np.ndarray,
) -> float:
    return float(roc_auc_score(labels, scores))

def compute_classification_metrics(
    labels : np.ndarray,
    predictions : np.ndarray,
    scores : np.ndarray,
) -> Dict[str, float]:
    return {
        "auroc": compute_auroc(labels, scores),
        "f1": float(f1_score(labels, predictions, zero_division=0)),
        "precision": float(precision_score(labels, predictions, zero_division=0)),
        "recall": float(recall_score(labels, predictions, zero_division=0)),
        "accuracy": float(accuracy_score(labels, predictions)),
    }

def bootstrap_ci(
    labels : np.ndarray,
    scores : np.ndarray,
    n : int = 1000,
    alpha : float = 0.05,
    seed : int = 42,
) -> Tuple[float, float]:
    rng = np.random.default_rng(seed)
    n_total = len(labels)
    aurocs = []

    for _ in range(n):
        idx = rng.integers(0, n_total, size=n_total)
        b_labels = labels[idx]
        b_scores = scores[idx]

        # skip resamples with only one class — AUROC undefined
        if len(np.unique(b_labels)) < 2:
            continue

        aurocs.append(roc_auc_score(b_labels, b_scores))

    aurocs = np.array(aurocs)
    lower = float(np.percentile(aurocs, 100 * alpha / 2))
    upper = float(np.percentile(aurocs, 100 * (1 - alpha / 2)))

    return lower, upper


def full_evaluation(
    labels : np.ndarray,
    predictions : np.ndarray,
    scores : np.ndarray,
    bootstrap_n : int = 1000,
    bootstrap_seed: int = 42,
) -> Dict[str, float]:
    metrics = compute_classification_metrics(labels, predictions, scores)

    ci_lower, ci_upper = bootstrap_ci(
        labels=labels,
        scores=scores,
        n=bootstrap_n,
        seed=bootstrap_seed,
    )
    metrics["auroc_ci_lower"] = ci_lower
    metrics["auroc_ci_upper"] = ci_upper

    return metrics


def print_results(metrics: Dict[str, float], detector_name: str = "detector"):
    #prints evaluation results.
    print(f"\n── {detector_name} results ──")
    print(f"  AUROC : {metrics['auroc']:.4f} "
          f"(95% CI: {metrics['auroc_ci_lower']:.4f}–{metrics['auroc_ci_upper']:.4f})")
    print(f"  F1 : {metrics['f1']:.4f}")
    print(f"  Precision : {metrics['precision']:.4f}")
    print(f"  Recall : {metrics['recall']:.4f}")
    print(f"  Accuracy : {metrics['accuracy']:.4f}")

def plot_roc_curve(
    labels : np.ndarray,
    scores : np.ndarray,
    detector_name : str = "detector",
    output_path : str = "outputs/plots/roc_curve.png",
) -> str:

    #Plots the ROC curve and saves it to disk.
    #Used for paper figures and demo visualisation.

    import matplotlib.pyplot as plt

    fpr, tpr, _ = roc_curve(labels, scores)
    auroc= compute_auroc(labels, scores)

    pathlib.Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(fpr, tpr, lw=2, label=f"{detector_name} (AUROC = {auroc:.3f})")
    ax.plot([0, 1], [0, 1], "k--", lw=1, label="Random chance")
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title("ROC Curve — LLM-Generated Text Detection")
    ax.legend(loc="lower right")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)

    print(f"ROC curve saved → {output_path}")
    return output_path


# This function plots F1, precision, recall and accuracy across all candidate
#     thresholds on the validation set. Marks the selected threshold.
#     This provides evidence that the chosen threshold is principled
#     and shows how performance varies as the threshold shifts.


def plot_threshold_sensitivity(
    val_labels : np.ndarray,
    val_scores : np.ndarray,
    threshold : float,
    detector_name : str = "detector",
    output_path : str = "outputs/plots/threshold_sensitivity.png",
) -> str:
    import matplotlib.pyplot as plt
    from sklearn.metrics import f1_score, precision_score, recall_score, accuracy_score

    pathlib.Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    thresholds = np.unique(val_scores)
    f1s, precs, recs, accs = [], [], [], []

    for theta in thresholds:
        preds = (val_scores >= theta).astype(int)
        f1s.append(f1_score(val_labels, preds, zero_division=0))
        precs.append(precision_score(val_labels, preds, zero_division=0))
        recs.append(recall_score(val_labels, preds, zero_division=0))
        accs.append(accuracy_score(val_labels, preds))

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(thresholds, f1s, label="F1", lw=2)
    ax.plot(thresholds, precs, label="Precision", lw=2)
    ax.plot(thresholds, recs, label="Recall", lw=2)
    ax.plot(thresholds, accs, label="Accuracy", lw=2, linestyle="--")
    ax.axvline(threshold, color="black", linestyle=":", lw=2,
               label=f"Selected threshold = {threshold:.3f}")
    ax.set_xlabel("Threshold")
    ax.set_ylabel("Score")
    ax.set_title(f"Threshold sensitivity — {detector_name}")
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)

    print(f"Threshold sensitivity plot saved → {output_path}")
    return output_path

def plot_score_distributions(
    human_scores : np.ndarray,
    machine_scores: np.ndarray,
    threshold : float,
    detector_name : str = "detector",
    output_path : str = "outputs/plots/score_distributions.png",
) -> str:

    #Plots overlapping score distributions for human and machine text.
    #Shows calibrated threshold as a vertical line.

    import matplotlib.pyplot as plt

    pathlib.Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(human_scores,   bins=30, alpha=0.6, label="Human-written",     color="#2196F3")
    ax.hist(machine_scores, bins=30, alpha=0.6, label="Machine-generated",  color="#F44336")
    ax.axvline(threshold, color="black", linestyle="--", lw=2,
               label=f"Threshold = {threshold:.3f}")
    ax.set_xlabel("Detection score")
    ax.set_ylabel("Count")
    ax.set_title(f"Score distributions — {detector_name}")
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)

    print(f"Score distributions saved → {output_path}")
    return output_path

def mcnemar_test(
    labels : np.ndarray,
    preds_a : np.ndarray,
    preds_b : np.ndarray,
    name_a : str = "detector_a",
    name_b : str = "detector_b",
) -> dict:
    
    #McNemar's test for comparing two binary classifiers on the same test set.
    #Tests whether the disagreements between two detectors are statistically
    #significant. If p > 0.05, the performance difference is not conclusive.

    from scipy.stats import chi2

    # contingency table of disagreements
    # b = A correct, B wrong
    # c = A wrong, B correct
    b = np.sum((preds_a == labels) & (preds_b != labels))
    c = np.sum((preds_a != labels) & (preds_b == labels))

    # McNemar statistic with continuity correction
    if (b + c) == 0:
        return {
            "b" : int(b),
            "c" : int(c),
            "statistic": 0.0,
            "p_value" : 1.0,
            "significant": False,
            "interpretation": "No disagreements — cannot distinguish the detectors."
        }

    statistic = (abs(b - c) - 1) ** 2 / (b + c)
    p_value = 1 - chi2.cdf(statistic, df=1)

    significant = bool(p_value < 0.05)
    if significant:
        better = name_a if b > c else name_b
        interp = f"Significant difference (p={p_value:.4f}). {better} makes fewer errors."
    else:
        interp = f"No significant difference (p={p_value:.4f}). Detectors perform comparably."

    return {
        "b" : int(b),
        "c" : int(c),
        "statistic" : float(statistic),
        "p_value" :float(p_value),
        "significant" : significant,
        "interpretation" : interp,

    }

def delong_test(
    labels : np.ndarray,
    scores_a : np.ndarray,
    scores_b : np.ndarray,
) -> dict:

    #DeLong test for comparing two AUROC values on the same test set
    #More powerful than bootstrapping for AUROC comparison because it
   # uses the analytical covariance structure rather than resampling.



    from scipy.stats import norm

    def compute_midrank(x):
        J = np.argsort(x)
        Z = x[J]
        N = len(x)
        T = np.zeros(N)
        i = 0
        while i < N:
            j = i
            while j < N and Z[j] == Z[i]:
                j += 1
            T[i:j] = 0.5 * (i + j - 1)
            i = j
        T2= np.empty(N)
        T2[J] = T + 1
        return T2

    def fastDeLong(predictions_sorted_transposed, label_1_count):
        m = label_1_count
        n = predictions_sorted_transposed.shape[1] - m
        positive_examples = predictions_sorted_transposed[:, :m]
        negative_examples = predictions_sorted_transposed[:, m:]
        k = predictions_sorted_transposed.shape[0]

        tx = np.empty([k, m], dtype=float)
        ty = np.empty([k, n], dtype=float)
        tz = np.empty([k, m + n], dtype=float)

        for r in range(k):
            tx[r, :] = compute_midrank(positive_examples[r, :])
            ty[r, :] = compute_midrank(negative_examples[r, :])
            tz[r, :] = compute_midrank(predictions_sorted_transposed[r, :])

        aucs = (tz[:, :m].sum(axis=1) / m / n
                - float(m + 1.0) / 2.0 / n)

        v01 = (tz[:, :m] - tx[:, :]) / n
        v10 = 1.0 - (tz[:, m:] - ty[:, :]) / m

        sx = v01.dot(v01.T) / (m - 1)
        sy = v10.dot(v10.T) / (n - 1)

        delongcov = sx / m + sy / n
        return aucs, delongcov

    label_1_count = int(labels.sum())
    sorted_idx= np.argsort(-labels)
    preds_T = np.vstack([scores_a, scores_b])[:, sorted_idx]

    aucs, cov = fastDeLong(preds_T, label_1_count)
    diff = aucs[0] - aucs[1]
    se = np.sqrt(cov[0, 0] + cov[1, 1] - 2 * cov[0, 1])

    if se == 0:
        return {"auroc_a": aucs[0], "auroc_b": aucs[1],
                "difference": diff, "p_value": 1.0,
                "significant": False,
                "interpretation": "Cannot compute — zero standard error."}

    z = diff / se
    p_value = 2 * (1 - norm.cdf(abs(z)))

    return {
        "auroc_a": float(aucs[0]),
        "auroc_b": float(aucs[1]),
        "difference" : float(diff),
        "z_statistic": float(z),
        "p_value": float(p_value),
        "significant": bool(p_value < 0.05),
        "interpretation" : (
            f"AUROC difference {diff:+.4f} is "
            f"{'significant' if p_value < 0.05 else 'not significant'} "
            f"(z={z:.3f}, p={p_value:.4f})."
        ),
    }
