from __future__ import annotations
import json
import pathlib
from typing import List, Dict, Any
import numpy as np
import pandas as pd

def save_predictions(
    samples : List[Any],
    predictions : np.ndarray,
    scores : np.ndarray,
    method : str,
    output_dir : str = "outputs/predictions",
) -> str:
    #Save predictions to CSV and JSONL.
    output_dir = pathlib.Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    records = []
    for sample, pred, score in zip(samples, predictions, scores):
        records.append({
            "id" : sample.id,
            "label" : sample.label,
            "predicted_label": int(pred),
            "score" : float(score),
            "method" : method,
            "split" : sample.split,
            "language" : sample.language,
        })

    df = pd.DataFrame(records)
    csv_path = output_dir / f"{method}_predictions.csv"
    df.to_csv(csv_path, index=False)

    jsonl_path = output_dir / f"{method}_predictions.jsonl"
    with open(jsonl_path, "w") as f:
        for record in records:
            f.write(json.dumps(record) + "\n")

    print(f"Saved predictions → {csv_path}")
    return str(csv_path)


def save_metrics(
    metrics : Dict[str, float],
    method : str,
    threshold : float,
    config : Dict,
    output_dir : str = "outputs/metrics",
) -> str:
    #Save evaluation metrics to JSON.
    output_dir = pathlib.Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    record = {
        "method" : method,
        "threshold": threshold,
        "metrics" : metrics,
        "config" : config,
    }

    path = output_dir / f"{method}_metrics.json"
    with open(path, "w") as f:
        json.dump(record, f, indent=2)

    print(f"Saved metrics → {path}")
    return str(path)