from __future__ import annotations
import logging
from typing import List, Optional, Tuple
import numpy as np

from src.statistical.scorer import BaseScorer
from src.statistical.perturbation import PerturbationGenerator, MockPerturbationGenerator

logger = logging.getLogger(__name__)

class CurvatureDetector:

    def __init__(
            self,
            scorer: BaseScorer,
            perturber: PerturbationGenerator,
            min_tokens: int = 10,
    ):
        self.scorer = scorer
        self.perturber = perturber
        self.min_tokens = min_tokens
        self.threshold = None
        self._val_scores = None

    def score_one(
        self,
        text : str,
        text_id : Optional[str] = None,
    ) -> Optional[float]:

        #Compute the perturbation discrepancy d(x) for a single text.

        #d(x) = log_p(x) - mean(log_p(x_tilde_j) for j in 1..k)

        # A large positive d(x) means the original text sits higher than its perturbations — consistent with machine-generated text.

        #Returns None if the text is too short to score reliably.

        try:
            # score the original text
            original_lps = self.scorer.log_probabilities(text)
            if len(original_lps) < self.min_tokens:
                logger.warning(
                    f"Text too short ({len(original_lps)} tokens). "
                    f"Returning None."
                )
                return None

            original_score = sum(original_lps)   # total log-prob, not normalised
            # note: we use total log-prob here, not length-normalised
            # this matches the original DetectGPT paper
            # length normalisation would change the curvature signal

            # generate perturbations
            perturbations = self.perturber.perturb(text, text_id=text_id)

            # score each perturbation
            perturb_scores = []
            for p_text in perturbations:
                try:
                    p_lps = self.scorer.log_probabilities(p_text)
                    if len(p_lps) > 0:
                        perturb_scores.append(sum(p_lps))
                except Exception as e:
                    logger.warning(f"Failed to score perturbation: {e}")

            if not perturb_scores:
                logger.warning("No perturbations could be scored. Returning None.")
                return None

            # compute discrepancy, normalised by the std of perturbation
            # scores — this matches the original DetectGPT formula:
            # d(x) = (log p(x) - mean(log p(x_tilde))) / std(log p(x_tilde))
            # Without this normalisation, texts whose perturbations happen to
            # vary a lot in score get a noisier, less reliable discrepancy
            # value, which degrades detection AUROC.
            mean_perturb_score = float(np.mean(perturb_scores))
            std_perturb_score = float(np.std(perturb_scores))

            if std_perturb_score < 1e-6:
                # avoid division by ~zero on the rare sample where all
                # perturbations scored nearly identically
                logger.warning("Near-zero perturbation std — returning "
                                "unnormalised discrepancy for this sample.")
                return original_score - mean_perturb_score

            discrepancy = (original_score - mean_perturb_score) / std_perturb_score

            return discrepancy

        except Exception as e:
            logger.error(f"Curvature scoring failed: {e}")
            return None

    def score_texts(
        self,
        texts : List[str],
        ids : Optional[List[str]] = None,
        verbose : bool = True,
    ) -> np.ndarray:
        
        #Score a list of texts.
        #Returns an array of perturbation discrepancy scores.
        #ids is an optional list of IDs for cache keying and logging

    
        if ids is None:
            ids = [None] * len(texts)

        scores = []
        failed = 0

        for i, (text, text_id) in enumerate(zip(texts, ids)):
            if verbose and (i + 1) % 10 == 0:
                print(f"  Scored {i+1}/{len(texts)} texts...")

            s = self.score_one(text, text_id=text_id)
            scores.append(s)
            if s is None:
                failed += 1

        if failed > 0:
            logger.warning(f"{failed} texts could not be scored.")

        valid= [s for s in scores if s is not None]
        mean_s = float(np.mean(valid)) if valid else 0.0
        scores = [s if s is not None else mean_s for s in scores]

        return np.array(scores, dtype=np.float64)

    def calibrate(
        self,
        val_texts : List[str],
        val_labels : List[int],
        val_ids : Optional[List[str]] = None,
        strategy : str = "youden_j",
    ) -> float:
        
        #we Select detection threshold on validation data only.
        #Identical threshold strategy to the log-likelihood detector.
        #we NEVER call with test data to avid wrong predictions.
        
        assert strategy in ("youden_j", "val_f1"), \
            f"Unknown strategy: {strategy}"

        print(f"Calibrating curvature threshold on {len(val_texts)} "
              f"validation samples using strategy: {strategy}")

        val_scores = self.score_texts(val_texts, ids=val_ids, verbose=True)
        self._val_scores = val_scores
        labels = np.array(val_labels)
        candidates = np.unique(val_scores)

        best_threshold = candidates[0]
        best_metric = -np.inf

        for theta in candidates:
            preds = (val_scores >= theta).astype(int)
            tp = np.sum((preds == 1) & (labels == 1))
            fp = np.sum((preds == 1) & (labels == 0))
            tn = np.sum((preds == 0) & (labels == 0))
            fn = np.sum((preds == 0) & (labels == 1))

            if strategy == "youden_j":
                sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
                specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
                metric= sensitivity + specificity - 1
            else:
                precision = tp / (tp + fp) if (tp + fp) > 0 else 0
                recall = tp / (tp + fn) if (tp + fn) > 0 else 0
                metric = (2 * precision * recall / (precision + recall)
                             if (precision + recall) > 0 else 0)

            if metric > best_metric:
                best_metric = metric
                best_threshold = theta

        self.threshold = float(best_threshold)
        print(f"Selected threshold : {self.threshold:.4f}")
        print(f"Best {strategy} : {best_metric:.4f}")
        return self.threshold

    def predict(
        self,
        texts : List[str],
        ids : Optional[List[str]] = None,
        scores : Optional[np.ndarray] = None,
    ) -> Tuple[np.ndarray, np.ndarray]:
        
        #Predict labels for a list of texts.
        #Must call calibrate() before predict().
        
        assert self.threshold is not None, \
            "Call calibrate() before predict(). Threshold not set."

        if scores is None:
            scores = self.score_texts(texts, ids=ids)

        predictions = (scores >= self.threshold).astype(int)
        return predictions, scores