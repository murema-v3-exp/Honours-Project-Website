

#Implements the average per-token log-likelihood detector.

#score(x) = (1/n) * sum(log P(t_i | t_{<i}))



from __future__ import annotations
import logging
from typing import List, Optional, Tuple
import numpy as np

from src.statistical.scorer import BaseScorer

logger = logging.getLogger(__name__)

class LogLikelihoodDetector:


    def __init__(self, scorer: BaseScorer, min_tokens: int = 10):
        self.scorer = scorer
        self.min_tokens = min_tokens
        self.threshold = None
        self._val_scores = None

    def score_one(self, text: str) -> Optional[float]:
        #Score a single text.
        #Returns None if the text is too short to score reliably.

        try:
            lps = self.scorer.log_probabilities(text)
            if len(lps) < self.min_tokens:
                logger.warning(
                    f"Text too short ({len(lps)} tokens < {self.min_tokens}). "
                    f"Returning None. Preview: '{text[:60]}'"
                )
                return None
            return sum(lps) / len(lps)
        except Exception as e:
            logger.error(f"Scoring failed: {e}. Text: '{text[:60]}'")
            return None


    def score_texts(
        self,
        texts : List[str],
        verbose : bool = True,
    ) -> np.ndarray:


        scores = []
        failed = 0

        for i, text in enumerate(texts):
            if verbose and (i + 1) % 50 == 0:
                print(f"  Scored {i + 1}/{len(texts)} texts...")

            s = self.score_one(text)
            scores.append(s)
            if s is None:
                failed += 1

        if failed > 0:
            logger.warning(f"{failed} texts could not be scored.")

        # convert to numpy, replace None with mean of valid scores
        valid = [s for s in scores if s is not None]
        mean_s = float(np.mean(valid)) if valid else 0.0
        scores = [s if s is not None else mean_s for s in scores]

        return np.array(scores, dtype=np.float64)


    def calibrate(
            self,
            val_texts: List[str],
            val_labels: List[int],
            strategy: str = "youden_j",
    ) -> float:
    #We select the detection threshold using validation data only.
    #We never call this with test data to avoid data leakage.

    #youden_j : maximises sensitivity + specificity - 1 (Youden's J statistic — standard in medical diagnostics)
    #val_f1 : maximises F1 score on validation set



        assert strategy in ("youden_j", "val_f1"), \
            f"Unknown strategy: {strategy}"

        print(f"Calibrating threshold on {len(val_texts)} validation samples "
              f"using strategy: {strategy}")

        val_scores = self.score_texts(val_texts, verbose=False)
        self._val_scores = val_scores
        labels = np.array(val_labels)

        # evaluate all candidate thresholds
        # use every unique score as a candidate — no binning
        candidates = np.unique(val_scores)
        best_threshold = candidates[0]
        best_metric = -np.inf

        for theta in candidates:
            preds = (val_scores >= theta).astype(int)
            tp = np.sum((preds == 1) & (labels == 1))
            fp = np.sum((preds == 1) & (labels == 0))
            tn = np.sum((preds == 0) & (labels == 0))
            fn = np.sum((preds == 0) & (labels == 1))

            if strategy == "youden_j":
                sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
                specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
                metric = sensitivity + specificity - 1

            elif strategy == "val_f1":
                precision = tp / (tp + fp) if (tp + fp) > 0 else 0
                recall = tp / (tp + fn) if (tp + fn) > 0 else 0
                metric = (2 * precision * recall / (precision + recall)
                          if (precision + recall) > 0 else 0)

            if metric > best_metric:
                best_metric = metric
                best_threshold = theta

        self.threshold = float(best_threshold)
        print(f"Selected threshold: {self.threshold:.4f} "
              f"({strategy} = {best_metric:.4f})")

        return self.threshold

    def predict(
            self,
            texts: List[str],
            scores: Optional[np.ndarray] = None,
    ) -> Tuple[np.ndarray, np.ndarray]:



        assert self.threshold is not None, \
            "Must call calibrate() before predict(). " \
            "Threshold has not been set."

        if scores is None:
            scores = self.score_texts(texts)

        predictions = (scores >= self.threshold).astype(int)
        return predictions, scores