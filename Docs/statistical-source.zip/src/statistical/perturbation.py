from __future__ import annotations
import hashlib
import json
import logging
import pathlib
import random
from typing import List, Optional

logger = logging.getLogger(__name__)


def _text_hash(text: str) -> str:
    #Short deterministic hash of a text for use as a cache key.
    return hashlib.md5(text.encode("utf-8")).hexdigest()[:16]

def _cache_path(
    cache_dir : pathlib.Path,
    text : str,
    k : int,
    model_id : str,
    mask_ratio : float,
    seed : int,
) -> pathlib.Path:
    #Returns the path where perturbations for this text are cached.
    key = f"{_text_hash(text)}_k{k}_r{mask_ratio}_s{seed}_{model_id.replace('/', '_')}"
    return cache_dir / f"{key}.json"


class PerturbationGenerator:
    def __init__(
            self,
            model_id: str = "t5-large",
            device: str = "auto",
            k: int = 25,
            mask_ratio: float = 0.15,
            seed: int = 42,
            cache_dir: str = "outputs/perturbation_cache",
    ):
        import torch
        from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

        self.k = k
        self.mask_ratio = mask_ratio
        self.seed = seed
        self.cache_dir = pathlib.Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.model_id = model_id
        self._rng = random.Random(seed)

        # resolve device
        if device == "auto":
            if torch.cuda.is_available():
                device = "cuda"
            else:
                device = "cpu"

        self.device = device

        logger.info(f"Loading T5 tokenizer: {model_id}")
        self.tokenizer = AutoTokenizer.from_pretrained(model_id)

        logger.info(f"Loading T5 model: {model_id} on {device}")
        self.model = AutoModelForSeq2SeqLM.from_pretrained(
            model_id,
            device_map=device,
        )
        self.model.eval()
        logger.info("T5 perturbation model ready.")

    def _mask_text(self, text: str) -> str:

        #Randomly masks spans in the text with T5 sentinel tokens.
        # Returns the masked string ready to be fed to T5.

        words = text.split()
        n_words = len(words)
        n_to_mask = max(1, int(n_words * self.mask_ratio))

        # randomly select positions to mask
        mask_positions = sorted(
            self._rng.sample(range(n_words), min(n_to_mask, n_words))
        )

        # group consecutive positions into spans
        spans = []
        current = [mask_positions[0]]
        for pos in mask_positions[1:]:
            if pos == current[-1] + 1:
                current.append(pos)
            else:
                spans.append(current)
                current = [pos]
        spans.append(current)

        # replace each span with a sentinel token
        masked_words = words.copy()
        sentinel_id = 0
        offset = 0
        for span in spans:
            start = span[0] - offset
            end = span[-1] - offset + 1
            masked_words[start:end] = [f"<extra_id_{sentinel_id}>"]
            offset += len(span) - 1
            sentinel_id += 1

        return " ".join(masked_words)

    def _fill_masks(self, masked_text: str) -> str:
        #Asks T5 to fill in the masked spans
        # Returns the reconstructed text with T5's fillings.

        import torch

        inputs = self.tokenizer(
            masked_text,
            return_tensors="pt",
            truncation=True,
            max_length=512,
        ).to(self.device)

        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=128,
                do_sample=True,
                temperature=1.0,
                top_p=0.95,
            )

        decoded = self.tokenizer.decode(outputs[0], skip_special_tokens=False)

        # parse T5's output it returns sentinel-delimited fillings
        # reconstruct the original text structure with T5's words
        original_words = masked_text.split()
        result_words = []

        # extract fillings from decoded output
        fillings = {}
        parts = decoded.split("<extra_id_")
        for part in parts[1:]:
            if ">" in part:
                idx_end = part.index(">")
                try:
                    sentinel_idx = int(part[:idx_end])
                    content = part[idx_end + 1:]
                    # stop at next sentinel
                    if "<extra_id_" in content:
                        content = content[:content.index("<extra_id_")]
                    fillings[sentinel_idx] = content.strip()
                except ValueError:
                    pass

        # rebuild text replacing sentinels with fillings
        sentinel_counter = 0
        for word in original_words:
            if word.startswith("<extra_id_"):
                filling = fillings.get(sentinel_counter, "")
                if filling:
                    result_words.append(filling)
                sentinel_counter += 1
            else:
                result_words.append(word)

        return " ".join(result_words)

    # the objective of this function is to generate k perturbations of the input text.
    # and also loads from cache if available, otherwise generates and caches.
    def perturb(self, text: str, text_id: Optional[str] = None) -> List[str]:

        cache_file = _cache_path(
            self.cache_dir,
            text,
            self.k,
            self.model_id,
            self.mask_ratio,
            self.seed,
        )

        # load from cache if exists
        if cache_file.exists():
            with open(cache_file) as f:
                cached = json.load(f)
            logger.debug(f"Loaded {len(cached)} perturbations from cache.")
            return cached

        # generate perturbations
        label = text_id or _text_hash(text)
        logger.info(f"Generating {self.k} perturbations for {label}...")

        perturbations = []
        for i in range(self.k):
            try:
                masked = self._mask_text(text)
                filled = self._fill_masks(masked)
                perturbations.append(filled)
            except Exception as e:
                logger.warning(f"Perturbation {i} failed: {e}. Using original.")
                perturbations.append(text)

        # cache to disk immediately
        with open(cache_file, "w") as f:
            json.dump(perturbations, f)

        return perturbations



class MockPerturbationGenerator:

    # This is the deterministic mock perturbation generator for unit tests.
    # it does not actually load T5 but returns slightly modified versions of the input.


    def __init__(self, k: int = 5, seed: int = 42):
        self.k = k
        self._rng = random.Random(seed)

    def perturb(self, text: str, text_id: Optional[str] = None) -> List[str]:
        #this method returns k versions of the text with random word swaps.
        words = text.split()
        perturbations = []
        for _ in range(self.k):
            perturbed = words.copy()
            if len(perturbed) > 3:
                i = self._rng.randint(0, len(perturbed) - 1)
                perturbed[i] = self._rng.choice(
                    ["the", "a", "this", "that", "its", "their"]
                )
            perturbations.append(" ".join(perturbed))
        return perturbations
