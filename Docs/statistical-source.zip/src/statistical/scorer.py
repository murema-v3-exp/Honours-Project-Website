#comments regarding the file and its use


# Loads Llama and computes per-token log-probabilities for input texts
# This is the shared scoring backbone for both detectors:
# LogLikelihoodDetector uses scorer.score()
# CurvatureDetector uses scorer.log_probability() on original + perturbed texts

# the required imports
from __future__ import annotations
import logging
import random
from abc import ABC, abstractmethod
from typing import List, Optional
import torch


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# implementing the class that will contain the methods
# that calculate the per token log-probabilities
# ----------------------------------- abstract interface -----------------------------------
class BaseScorer(ABC):
    @abstractmethod
    def log_probabilities(self, text: str) -> List[float]:
        return

    # Given a text, it should return a list of log-probabilities
    #Each value is log P(token_i | token_1, ..., token_{i-1}).
    # Values are always negative (log of a probability < 1).
    # Length equals the number of tokens in the text minus one
    # (cannot score the first token with no context).

    def score(self, text: str) -> float:

        # this computes the length-normalised average log-likelihood
        #it is the primary detection score for the log-likelihood detector
        # Formula: (1/n) * sum(log P(t_i | t_{<i}))

        lps = self.log_probabilities(text)
        if len(lps) == 0:
            raise ValueError(f"Empty log-prob sequence for text: '{text[:50]}...'")
        return sum(lps) / len(lps)



    def log_probability(self, text: str) -> float:

        #this computes the total unnormalised log-probability of the text
        # Used by the curvature detector alongside the score()
        return sum(self.log_probabilities(text))


#----- Designing the Mock scorer for testing -----------

class MockScorer(BaseScorer):

        # Deterministic mock scorer for unit tests and CI.
         #Does not load any model — runs on CPU with no dependencies.

        # We use this when:
        # Writing tests
        # Developing the pipeline without GPU access
        # Running CI checks


    # Words commonly overrepresented in LLM-generated text
    MACHINE_KEYWORDS = {
        "comprehensive", "optimal", "multifaceted", "systematic",
        "integrated", "facilitates", "stakeholders", "dimensions",
        "furthermore", "additionally", "notably", "importantly",
        "crucially", "ultimately", "holistic", "robust",
    }

    def __init__(self, seed: int = 42):
        self._rng = random.Random(seed)


    def log_probabilities(self, text: str) -> List[float]:
        words = text.lower().split()
        n_tokens = max(len(words), 1)
        machine_like = any(w in self.MACHINE_KEYWORDS for w in words)
        # machine-like text gets higher (less negative) base score
        base = -1.5 if machine_like else -3.0
        return [base + self._rng.gauss(0, 0.4) for _ in range(n_tokens)]




#------------ Real LLama scorer --


class LlamaScorer(BaseScorer):
    # computes the token log-probabilities using Llama

    def __init__(
            self,
            model_id="meta-llama/Llama-3.2-3B",
            device="auto",
            dtype="float16",
    ):
        self.dtype = dtype

        import torch
        from transformers import AutoTokenizer, AutoModelForCausalLM


    # resolving device
        if device == "auto":
            if torch.backends.mps.is_available():
                device = "mps"
                logger.info("Apple Silicon detected — using MPS backend")
            elif torch.cuda.is_available():
                device = "cuda"
                logger.info("NVIDIA GPU detected — using CUDA backend")
            else:
                device = "cpu"
                logger.info("No GPU detected — using CPU (will be slow)")

        self.device = device

        # ── Resolve dtype ─────────────────────────────────────────────────────
        dtype_map = {
            "float16": torch.float16,
            "float32": torch.float32,
            "bfloat16": torch.bfloat16,
        }

        torch_dtype = dtype_map.get(dtype, torch.float32)

        # ── Load tokenizer ──────────────
        logger.info(f"Loading tokenizer: {model_id}")
        self.tokenizer = AutoTokenizer.from_pretrained(model_id)

        # ── Load model ─────────────
        logger.info(f"Loading model: {model_id} → {device} ({dtype})")
        self.model = AutoModelForCausalLM.from_pretrained(
            model_id,
            torch_dtype=torch_dtype,
            device_map=device,
        )
        self.model.eval()

        n_params = sum(p.numel() for p in self.model.parameters())
        logger.info(f"Model loaded: {n_params / 1e9:.2f}B parameters on {device}")

    def log_probabilities(self, text: str) -> List[float]:
        #Tokenises the text and computes per-token log-probabilities.

        #Implementation detail:
        #We shift the logits and input_ids by one position so that
        #logit[i] predicts token[i+1]. This is standard causal LM scoring.
        #The first token has no context so we drop it — we score tokens 1..n given tokens 0..n-1.

        import torch
        import torch.nn.functional as F

        #we tokenise — add_special_tokens=True adds BOS token
        inputs = self.tokenizer(text,
                                return_tensors = "pt",
                                truncation = True,
                                max_length= 1024,
                                add_special_tokens = True).to(self.device)
        input_ids = inputs["input_ids"] # shape: (1, seq_len)

        if input_ids.shape[1] < 2: # we cannot score the first token
            raise ValueError(
                f"Text too short to score: '{text[:50]}'"
            )

        with torch.no_grad():
            outputs = self.model(**inputs)
            logits = outputs.logits # shape: (1, seq_len, vocab_size)

            #we then convert the logits into log-probbilities
            log_probs_all = F.log_softmax(logits, dim=-1)

            # for each position i, get the log-prob of the actual token at i+1
            # logits[0, i, :] predicts token at position i+1
            token_log_probs = log_probs_all[0, :-1, :].gather(
                dim=1,
                index=input_ids[0, 1:].unsqueeze(1)
            ).squeeze(1)  # shape: (seq_len - 1,)

            return token_log_probs.cpu().tolist()





#------- Factory function --------------------------

def get_scorer(config: dict) -> BaseScorer:

    if config.get("use_mock", True):
        return MockScorer(seed=config.get("seed", 42))

    return LlamaScorer(
        model_id=config.get("model_id", "meta-llama/Llama-3.2-8B"),
        device=config.get("device", "auto"),
        dtype=config.get("dtype", "float16"),
    )


