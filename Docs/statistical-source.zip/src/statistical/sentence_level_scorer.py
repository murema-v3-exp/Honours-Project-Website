#Sentence-level scoring: reuses the existing document-level detectors (log_likelihood.py, curvature.py) but calls them per-sentence instead of per-document, then aggregates.

from dataclasses import dataclass
from typing import List, Callable
import re
import numpy as np


def split_into_sentences(document_text: str) -> List[str]:
    #Lightweight sentence splitter we can use for nltk/spacy for
    # better handling of abbreviations, decimals, etc.
    # Good enough for XSum-style news text used elsewhere in this project.

    raw_sentences = re.split(r'(?<=[.!?])\s+', document_text.strip())
    return [s for s in raw_sentences if len(s.split()) > 2]  # drop fragments


@dataclass
class SentenceLevelResult:
    sentence_scores: List[float]
    mean_score: float
    std_score: float
    min_score: float
    max_score: float


def score_document_by_sentence(
        document_text: str, score_fn: Callable[[str], float]
) -> SentenceLevelResult:


    #score_fn: the .score() method of an existing detector, e.g.
    #LogLikelihoodScorer.score or CurvatureScorer.score.

    #Falls back to scoring the whole document as one unit if sentence
    #splitting yields nothing usable (e.g. very short text).

    sentences = split_into_sentences(document_text)
    if not sentences:
        whole_doc_score = score_fn(document_text)
        return SentenceLevelResult(
            [whole_doc_score], whole_doc_score, 0.0, whole_doc_score, whole_doc_score
        )

    sentence_scores = [score_fn(sentence) for sentence in sentences]
    scores_array = np.array(sentence_scores)
    return SentenceLevelResult(
        sentence_scores=sentence_scores,
        mean_score=float(scores_array.mean()),
        std_score=float(scores_array.std()),
        min_score=float(scores_array.min()),
        max_score=float(scores_array.max()),
    )


def add_sentence_level_features(
        samples: List[dict],
        log_likelihood_scorer,
        curvature_scorer,
        text_field: str = "text",
) -> List[dict]:

    #Adds sentence-level aggregate features alongside the existing document-level loglik_score / curvature_score fields already on each sample.
    # New keys added in place are loglik_sentence_mean, loglik_sentence_std, curvature_sentence_mean, curvature_sentence_std

    #These slot directly into ensemble_classifier.py's feature extraction if we widen FEATURE_KEYS to include them.

    for sample in samples:
        loglik_result = score_document_by_sentence(
            sample[text_field], log_likelihood_scorer.score
        )
        curvature_result = score_document_by_sentence(
            sample[text_field], curvature_scorer.score
        )
        sample["loglik_sentence_mean"] = loglik_result.mean_score
        sample["loglik_sentence_std"] = loglik_result.std_score
        sample["curvature_sentence_mean"] = curvature_result.mean_score
        sample["curvature_sentence_std"] = curvature_result.std_score
    return samples



#FEATURE_KEYS = ["loglik_score", "curvature_score", "loglik_sent_std", "curvature_sent_std"]
#def _extract_features(samples):
#       return np.array([[s[k] for k in FEATURE_KEYS] for s in samples])

