

#ighlights sentences flagged as machine-generated, built on top of the
#sentence-level scores from sentence_level_scorer.py. Used by
#experiments/demo.py (the Streamlit UI) for qualitative inspection.

#Threshold: reuses whatever threshold was already calibrated via Youden's J
#for the document-level detector. Sentence scores are noisier than document
#scores (less text per estimate),

from dataclasses import dataclass
from typing import List, Callable
from src.statistical.sentence_level_scorer import split_into_sentences


@dataclass
class HighlightedSentence:
    sentence_text: str
    score: float
    is_flagged: bool  # True if scored as machine-generated


def build_highlighted_sentences(
        document_text: str, score_fn: Callable[[str], float], decision_threshold: float
) -> List[HighlightedSentence]:


    sentences = split_into_sentences(document_text)
    highlighted = []
    for sentence in sentences:
        score = score_fn(sentence)
        highlighted.append(
            HighlightedSentence(sentence, score, is_flagged=score >= decision_threshold)
        )
    return highlighted


def render_highlighted_html(
        document_text: str,
        score_fn: Callable[[str], float],
        decision_threshold: float,
        highlight_color: str = "#ffcccc",
) -> str:
    #Returns HTML with flagged sentences wrapped in <mark>. Unflagged sentences pass through unchanged.
    # we sse in Streamlit via: st.markdown(render_highlighted_html(...), unsafe_allow_html=True)

    highlighted_sentences = build_highlighted_sentences(
        document_text, score_fn, decision_threshold
    )
    html_parts = []
    for item in highlighted_sentences:
        if item.is_flagged:
            html_parts.append(
                f'<mark style="background-color:{highlight_color}" '
                f'title="score={item.score:.3f}">{item.sentence_text}</mark>'
            )
        else:
            html_parts.append(item.sentence_text)
    return " ".join(html_parts)

# --- experiments/demo.py integration sketch ---
#
# import streamlit as st
# from src.utils.sentence_highlighter import render_highlighted_html
#
# selected_text = st.session_state.selected_sample["text"]
# st.markdown(
#     render_highlighted_html(selected_text, log_likelihood_scorer.score, calibrated_threshold),
#     unsafe_allow_html=True,
# )
# st.caption("Highlighted sentences scored above the calibrated Youden's J threshold.")
#
# Optional: add a toggle so a reviewer can switch which detector drives the
# highlight (log-likelihood vs curvature vs ensemble) on the same document —
# useful for the qualitative error-analysis section of the report.
