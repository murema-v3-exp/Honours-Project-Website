#Unit tests for the ensemble classifier

import numpy as np
import pytest
from src.ensemble.ensemble_classifier import (
    split_dataset_for_ensemble,
    fit_ensemble_classifier,
    predict_ensemble_probabilities,
    FEATURE_KEYS,
)


def make_samples(n_human=10, n_machine=10, seed=42):
    #Builds synthetic scored samples, machine samples get higher loglik_score/curvature_score, mirroring the real detectors' direction.
    rng = np.random.default_rng(seed)
    samples = []
    for i in range(n_human):
        samples.append({
            "id": f"human_{i}", "label": 0,
            "loglik_score": float(rng.normal(-3.0, 0.3)),
            "curvature_score": float(rng.normal(-1.0, 0.3)),
        })
    for i in range(n_machine):
        samples.append({
            "id": f"machine_{i}", "label": 1,
            "loglik_score": float(rng.normal(-1.5, 0.3)),
            "curvature_score": float(rng.normal(1.0, 0.3)),
        })
    return samples


def test_split_preserves_total_count():
    samples = make_samples()
    fit_samples, eval_samples = split_dataset_for_ensemble(samples, fit_fraction=0.5)
    assert len(fit_samples) + len(eval_samples) == len(samples)


def test_split_stratifies_labels():
    samples = make_samples(n_human=20, n_machine=20)
    fit_samples, eval_samples = split_dataset_for_ensemble(samples, fit_fraction=0.5)
    fit_machine_frac = sum(s["label"] for s in fit_samples) / len(fit_samples)
    eval_machine_frac = sum(s["label"] for s in eval_samples) / len(eval_samples)
    assert abs(fit_machine_frac - 0.5) < 0.15
    assert abs(eval_machine_frac - 0.5) < 0.15


def test_split_is_disjoint():
    samples = make_samples()
    fit_samples, eval_samples = split_dataset_for_ensemble(samples)
    fit_ids = {s["id"] for s in fit_samples}
    eval_ids = {s["id"] for s in eval_samples}
    assert fit_ids.isdisjoint(eval_ids)


def test_fit_returns_classifier_with_expected_feature_keys():
    samples = make_samples()
    fit_samples, _ = split_dataset_for_ensemble(samples)
    classifier = fit_ensemble_classifier(fit_samples)
    assert classifier.feature_keys == FEATURE_KEYS


def test_fit_produces_feature_weights_for_each_key():
    samples = make_samples()
    fit_samples, _ = split_dataset_for_ensemble(samples)
    classifier = fit_ensemble_classifier(fit_samples)
    for key in FEATURE_KEYS:
        assert key in classifier.feature_weights
        assert isinstance(classifier.feature_weights[key], float)


def test_predict_returns_probabilities_in_range():
    samples = make_samples()
    fit_samples, eval_samples = split_dataset_for_ensemble(samples)
    classifier = fit_ensemble_classifier(fit_samples)
    probabilities = predict_ensemble_probabilities(classifier, eval_samples)
    assert isinstance(probabilities, np.ndarray)
    assert len(probabilities) == len(eval_samples)
    assert np.all((probabilities >= 0.0) & (probabilities <= 1.0))


def test_ensemble_separates_human_and_machine_well():
    #With clearly separated synthetic features, the ensemble should achieve near-perfect AUROC
    #a sanity check that fit/predict are wired correctly, not a claim about real-world detector performance.
    from sklearn.metrics import roc_auc_score

    samples = make_samples(n_human=50, n_machine=50)
    fit_samples, eval_samples = split_dataset_for_ensemble(samples)
    classifier = fit_ensemble_classifier(fit_samples)
    probabilities = predict_ensemble_probabilities(classifier, eval_samples)
    labels = [s["label"] for s in eval_samples]
    auroc = roc_auc_score(labels, probabilities)
    assert auroc > 0.9


def test_custom_feature_keys_are_respected():
    samples = make_samples()
    for s in samples:
        s["extra_feature"] = float(np.random.default_rng(0).normal())
    fit_samples, eval_samples = split_dataset_for_ensemble(samples)
    custom_keys = ["loglik_score", "curvature_score", "extra_feature"]
    classifier = fit_ensemble_classifier(fit_samples, feature_keys=custom_keys)
    assert classifier.feature_keys == custom_keys
    probabilities = predict_ensemble_probabilities(classifier, eval_samples)
    assert len(probabilities) == len(eval_samples)
