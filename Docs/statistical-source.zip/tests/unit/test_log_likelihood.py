import numpy as np
import pytest
from src.statistical.scorer import MockScorer
from src.statistical.log_likelihood import LogLikelihoodDetector



HUMAN_TEXTS = [
    "The committee met on Tuesday to discuss the proposed amendments to the framework.",
    "Researchers found a correlation between sleep patterns and cognitive performance.",
    "Local farmers are adapting their practices in response to changing rainfall.",
    "The annual report highlighted significant changes in the renewable energy sector.",
    "Students staged a peaceful protest outside the administration building yesterday.",
]
MACHINE_TEXTS = [
    "The comprehensive analysis reveals multifaceted implications for all stakeholders.",
    "This document provides a systematic overview of the optimal considerations involved.",
    "The integrated framework facilitates enhanced understanding across all dimensions.",
    "Drawing upon extensive research the following conclusions can be robustly established.",
    "The holistic approach ensures comprehensive outcomes for all parties involved.",
]

@pytest.fixture
def detector():
    scorer = MockScorer(seed=42)
    return LogLikelihoodDetector(scorer, min_tokens=3)

def test_init_sets_attributes(detector):
    assert detector.scorer is not None
    assert detector.min_tokens == 3
    assert detector.threshold is None

def test_score_one_returns_float(detector):
    score = detector.score_one(HUMAN_TEXTS[0])
    assert isinstance(score, float)
    assert score < 0

def test_score_texts_returns_array(detector):
    scores = detector.score_texts(HUMAN_TEXTS + MACHINE_TEXTS, verbose=False)
    assert isinstance(scores, np.ndarray)
    assert len(scores) == len(HUMAN_TEXTS + MACHINE_TEXTS)

def test_calibrate_sets_threshold(detector):
    val_texts= HUMAN_TEXTS + MACHINE_TEXTS
    val_labels = [0]*5 + [1]*5
    threshold= detector.calibrate(val_texts, val_labels)
    assert detector.threshold is not None
    assert isinstance(threshold, float)

def test_predict_requires_calibration():
    scorer = MockScorer(seed=42)
    detector = LogLikelihoodDetector(scorer)
    with pytest.raises(AssertionError):
        detector.predict(HUMAN_TEXTS)

def test_predict_returns_binary(detector):
    val_texts= HUMAN_TEXTS + MACHINE_TEXTS
    val_labels = [0]*5 + [1]*5
    detector.calibrate(val_texts, val_labels)
    preds, scores = detector.predict(HUMAN_TEXTS + MACHINE_TEXTS)
    assert set(np.unique(preds)).issubset({0, 1})
    assert len(preds) == 10

def test_predict_score_length_matches(detector):
    val_texts= HUMAN_TEXTS + MACHINE_TEXTS
    val_labels = [0]*5 + [1]*5
    detector.calibrate(val_texts, val_labels)
    preds, scores = detector.predict(HUMAN_TEXTS)
    assert len(preds) == len(scores) == len(HUMAN_TEXTS)