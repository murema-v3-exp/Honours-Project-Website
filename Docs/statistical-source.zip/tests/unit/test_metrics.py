import numpy as np
from src.evaluation.metrics import (
    compute_auroc,
    compute_classification_metrics,
    bootstrap_ci,
    full_evaluation,
)

LABELS_PERFECT = np.array([0,0,0,0,0,1,1,1,1,1])
SCORES_PERFECT = np.array([-3.0,-2.8,-2.9,-3.1,-2.7,-1.5,-1.3,-1.6,-1.4,-1.2])
LABELS_RANDOM = np.array([0,1,0,1,0,1,0,1,0,1])
SCORES_RANDOM = np.array([-2.0,-2.1,-1.9,-2.0,-2.1,-2.0,-1.9,-2.1,-2.0,-1.9])

def test_auroc_perfect():
    assert compute_auroc(LABELS_PERFECT, SCORES_PERFECT) == 1.0

def test_auroc_range():
    auroc = compute_auroc(LABELS_RANDOM, SCORES_RANDOM)
    assert 0.0 <= auroc <= 1.0

def test_bootstrap_ci_lower_leq_upper():
    lower, upper = bootstrap_ci(LABELS_PERFECT, SCORES_PERFECT, n=100, seed=42)
    assert lower <= upper

def test_bootstrap_ci_in_range():
    lower, upper = bootstrap_ci(LABELS_PERFECT, SCORES_PERFECT, n=100, seed=42)
    assert 0.0 <= lower <= 1.0
    assert 0.0 <= upper <= 1.0

def test_bootstrap_ci_reproducible():
    ci1 = bootstrap_ci(LABELS_PERFECT, SCORES_PERFECT, n=100, seed=42)
    ci2 = bootstrap_ci(LABELS_PERFECT, SCORES_PERFECT, n=100, seed=42)
    assert ci1 == ci2

def test_full_evaluation_has_all_keys():
    preds = (SCORES_PERFECT >= -2.0).astype(int)
    metrics = full_evaluation(LABELS_PERFECT, preds, SCORES_PERFECT, bootstrap_n=50)
    for key in ["auroc","f1","precision","recall","accuracy",
                "auroc_ci_lower","auroc_ci_upper"]:
        assert key in metrics, f"Missing key: {key}"