import pytest
from src.attacks.paraphrase_attack import (
    ParaphraseAttackConfig,
    build_paraphrase_attacked_dataset,
    detect_device,
)


class MockAttacker:


    def paraphrase_text(self, source_text: str) -> str:
        return f"[PARAPHRASED] {source_text}"


SAMPLES = [
    {"id": "h1", "text": "The committee met on Tuesday.", "label": 0},
    {"id": "m1", "text": "The comprehensive analysis reveals multifaceted implications.", "label": 1},
    {"id": "m2", "text": "This document provides a systematic overview.", "label": 1},
]


def test_detect_device_returns_valid_string():
    device = detect_device()
    assert device in ("mps", "cuda", "cpu")


def test_config_defaults():
    config = ParaphraseAttackConfig()
    assert config.num_beams == 5
    assert config.max_length == 256
    assert config.device in ("mps", "cuda", "cpu")


def test_config_respects_explicit_device():
    config = ParaphraseAttackConfig(device="cpu")
    assert config.device == "cpu"


def test_build_attacked_dataset_adds_paraphrased_text_field():
    attacker = MockAttacker()
    attacked = build_paraphrase_attacked_dataset(SAMPLES, attacker)
    for sample in attacked:
        assert "paraphrased_text" in sample


def test_build_attacked_dataset_only_paraphrases_machine_samples():
    attacker = MockAttacker()
    attacked = build_paraphrase_attacked_dataset(SAMPLES, attacker)
    human_sample = next(s for s in attacked if s["label"] == 0)
    machine_sample = next(s for s in attacked if s["label"] == 1)

    # human text passes through unchanged
    assert human_sample["paraphrased_text"] == human_sample["text"]
    # machine text gets the paraphrase applied
    assert machine_sample["paraphrased_text"] == f"[PARAPHRASED] {machine_sample['text']}"


def test_build_attacked_dataset_preserves_sample_count():
    attacker = MockAttacker()
    attacked = build_paraphrase_attacked_dataset(SAMPLES, attacker)
    assert len(attacked) == len(SAMPLES)


def test_build_attacked_dataset_does_not_mutate_original_samples():
    attacker = MockAttacker()
    original_copy = [dict(s) for s in SAMPLES]
    build_paraphrase_attacked_dataset(SAMPLES, attacker)
    assert SAMPLES == original_copy


@pytest.mark.slow
def test_real_attacker_paraphrases_text():
    #Loads the actual T5 paraphrase model — slow, needs internet/GPU.
    # we run  with: pytest -m slow"""
    from src.attacks.paraphrase_attack import ParaphraseAttacker

    attacker = ParaphraseAttacker(ParaphraseAttackConfig(device="cpu"))
    result = attacker.paraphrase_text("The committee met on Tuesday to vote.")
    assert isinstance(result, str)
    assert len(result) > 0
