import pytest
from src.statistical.scorer import MockScorer, get_scorer, BaseScorer

def test_mock_scorer_returns_list():
    scorer = MockScorer(seed=42)
    lps = scorer.log_probabilities("The committee met on Tuesday.")
    assert isinstance(lps, list)
    assert len(lps) > 0

def test_mock_scorer_all_negative():
    scorer = MockScorer(seed=42)
    lps = scorer.log_probabilities("The committee met on Tuesday.")
    assert all(v < 0 for v in lps), "Log-probs must be negative"

def test_mock_scorer_score_is_negative():
    scorer = MockScorer(seed=42)
    score = scorer.score("The committee met on Tuesday.")
    assert score < 0

def test_mock_scorer_deterministic():
    s1 = MockScorer(seed=42).score("Hello world this is a test.")
    s2 = MockScorer(seed=42).score("Hello world this is a test.")
    assert s1 == s2

def test_mock_scorer_machine_higher_than_human():
    scorer = MockScorer(seed=42)
    human = scorer.score("The committee met on Tuesday to discuss amendments.")
    machine = scorer.score("The comprehensive optimal multifaceted systematic framework.")
    assert machine > human

def test_get_scorer_returns_mock():
    scorer = get_scorer({"use_mock": True, "seed": 42})
    assert isinstance(scorer, MockScorer)

def test_get_scorer_is_base_scorer():
    scorer = get_scorer({"use_mock": True})
    assert isinstance(scorer, BaseScorer)