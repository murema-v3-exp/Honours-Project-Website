#Unit tests for sentence-level scoring

import numpy as np
import pytest
from src.statistical.scorer import MockScorer
from src.statistical.sentence_level_scorer import (
    split_into_sentences,
    score_document_by_sentence,
    add_sentence_level_features,
)


MULTI_SENTENCE_TEXT = (
    "The committee met on Tuesday. They discussed the proposed amendments. "
    "A vote is expected next week."
)
SINGLE_WORD_TEXT = "Hello"


@pytest.fixture
def loglik_scorer():
    return MockScorer(seed=42)


def test_split_into_sentences_returns_list():
    sentences = split_into_sentences(MULTI_SENTENCE_TEXT)
    assert isinstance(sentences, list)
    assert len(sentences) == 3


def test_split_into_sentences_drops_short_fragments():
    text = "Yes. The committee met on Tuesday to discuss matters."
    sentences = split_into_sentences(text)
    # "Yes." is 1 word, should be dropped as a fragment
    assert all(len(s.split()) > 2 for s in sentences)


def test_split_into_sentences_empty_text():
    assert split_into_sentences("") == []


def test_score_document_by_sentence_returns_result(loglik_scorer):
    result = score_document_by_sentence(MULTI_SENTENCE_TEXT, loglik_scorer.score)
    assert len(result.sentence_scores) == 3
    assert isinstance(result.mean_score, float)
    assert isinstance(result.std_score, float)


def test_score_document_by_sentence_falls_back_for_no_sentences(loglik_scorer):
    #A document with no sentences passing the split filter should still
    # return a usable result via the whole-document fallback.
    result = score_document_by_sentence(SINGLE_WORD_TEXT, loglik_scorer.score)
    assert len(result.sentence_scores) == 1
    assert result.std_score == 0.0
    assert result.min_score == result.max_score == result.mean_score


def test_score_document_by_sentence_stats_consistent(loglik_scorer):
    result = score_document_by_sentence(MULTI_SENTENCE_TEXT, loglik_scorer.score)
    scores = np.array(result.sentence_scores)
    assert result.mean_score == pytest.approx(scores.mean())
    assert result.min_score == scores.min()
    assert result.max_score == scores.max()


def test_add_sentence_level_features_adds_expected_keys(loglik_scorer):
    samples = [
        {"id": "s1", "text": MULTI_SENTENCE_TEXT, "label": 0},
        {"id": "s2", "text": MULTI_SENTENCE_TEXT, "label": 1},
    ]
    add_sentence_level_features(samples, loglik_scorer, loglik_scorer)
    for sample in samples:
        assert "loglik_sentence_mean" in sample
        assert "loglik_sentence_std" in sample
        assert "curvature_sentence_mean" in sample
        assert "curvature_sentence_std" in sample


def test_add_sentence_level_features_preserves_existing_keys(loglik_scorer):
    samples = [{"id": "s1", "text": MULTI_SENTENCE_TEXT, "label": 0, "loglik_score": -2.5}]
    add_sentence_level_features(samples, loglik_scorer, loglik_scorer)
    assert samples[0]["loglik_score"] == -2.5  # untouched
    assert "loglik_sentence_mean" in samples[0]  # new field added
